<?php
//-----------------------------------------------------------------------------------------
//位置：店铺运费
//作者：让时光流逝
//时间：2018年11月7日
//-----------------------------------------------------------------------------------------

namespace App\Http\Controllers\Newstore;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;

class FreightController extends Controller
{
    public function index(){
    	if(Input::get('id') === '0' || Input::get('id') == null){
    		return json_encode(['code'=>'-1', 'data'=>'', 'message'=>"模板编号不能为空"]);
    	}else{
            $data = DB::table('delivery')->where('id', '=', Input::get('id'))->first();
			$data->title = iconv('GBK','UTF-8',$data->title);
            $freightdesc = DB::table('delivery_desc')->where('pid','=',Input::get('id'))->get();
			foreach($freightdesc as $key => $val){			
				$freightdesc[$key]->region_names = iconv('GBK','UTF-8',$val->region_names);
			}
            $delivery_desc = '';
            $region_names = '';
            $desc = '';
            foreach ($freightdesc as $key => $value) {
                if($value->is_default == '1'){
                    $delivery_desc = $value->start_num.'件内'.$value->start_money.'元，每增加'.$value->plus_num.'件，加'.$value->plus_money.'元';
                }else{
                    $region_names = iconv('GBK','UTF-8',$value->region_names);
                    $desc = $value->start_num.'件内'.$value->start_money.'元，每增加'.$value->plus_num.'件，加'.$value->plus_money.'元';
                }
            }
            $selfdata = DB::table('sunny_area')->where('id', '=', $data->region_code)->first();
			//$selfdata->name = iconv('GBK','UTF-8',$selfdata->name);
            $pdata = DB::table('sunny_area')->where('id', '=', $selfdata->pid)->first();
			//$pdata->name = iconv('GBK','UTF-8',$pdata->name);
            $ppdata = DB::table('sunny_area')->where('id', '=', $pdata->pid)->first();
			//$ppdata->name = iconv('GBK','UTF-8',$ppdata->name);

            $data->region_names =  iconv('GBK','UTF-8',$ppdata->name)."&nbsp;". iconv('GBK','UTF-8',$pdata->name)."&nbsp;". iconv('GBK','UTF-8',$selfdata->name);
            $data->region_codes = $ppdata->id."&nbsp;".$pdata->id."&nbsp;".$selfdata->id;
            
			$returndata = [
                'code' => '0',
                'data' => [
                    'freight' => $data,
                    'default_desc' => $delivery_desc,
                    'region_names' => $region_names,
                    'desc' => $desc,
                ],
                'message' => ''
            ];
            return json_encode($returndata);
        }
    }
    public function catlist(){
    	$format = Input::get('format')??0;
    	$deep = Input::get('deep')??0;
    	$catelist = DB::select(
			'SELECT	id,category,ParentID FROM category ORDER BY categoryorder DESC');
		foreach($catelist as $key => $val){			
			$catelist[$key]->category = iconv('GBK','UTF-8',$val->category);
		}
    	$rescate = [];
    	foreach($catelist as $key =>$value){
            //判断等级
            $level = '1';
            if($value->ParentID != '0'){
                $level = $level+1;
                $parent = DB::table('category')->where('id','=',$value->ParentID)->first();
                if($parent && $parent->ParentID !='0'){
                    $level = $level+1;
                    $pparent = DB::table('category')->where('id','=',$parent->ParentID)->first();
                    if($pparent && $pparent->ParentID!='0'){
                        $level = $level+1;
                    }
                }
            }

    		$rescate[$key]['cat_id'] = $value->id;
    		$rescate[$key]['name'] = $value->category;
    		$rescate[$key]['parent_id'] = $value->ParentID;
    		$rescate[$key]['isParent'] = $value->ParentID=='0'?1:0;
    		$rescate[$key]['cat_level'] = $level;
    		$rescate[$key]['keywords'] = $value->category;
    	}
    	return json_encode(['code'=>'0','data'=>$rescate,'message'=>'']);
    }
    public function storecate(){
    	$format = Input::get('format')??0;
    	$deep = Input::get('deep')??0;
    	$catelist = DB::select(
			'SELECT	id,cate_name,pid,path FROM store_cate where store_id='.session('loginstore')->id.' ORDER BY sort,publish_time DESC');
		foreach($catelist as $key => $val){			
			$catelist[$key]->cate_name = iconv('GBK','UTF-8',$val->cate_name);
		}
    	$rescate = [];
    	if(!$catelist){
    		return json_encode(['code'=>'0','data'=>'','message'=>'']);
    	}
    	foreach($catelist as $key =>$value){
    		$rescate[$key]['cat_id'] = $value->id;
    		$rescate[$key]['name'] = $value->cate_name;
    		$rescate[$key]['parent_id'] = $value->pid;
    		$rescate[$key]['isParent'] = $value->pid=='0'?1:0;
    		$rescate[$key]['cat_level'] = count(explode('-',$value->path))-1;
    		$rescate[$key]['keywords'] = $value->cate_name;
    	}
    	return json_encode(['code'=>'0','data'=>$rescate,'message'=>'']);
    }
    public function reloadgoodsunit(){
    	$unit = DB::table('goods_unit')->get();
		foreach($unit as $key => $val){			
			$unit[$key]->unit = iconv('GBK','UTF-8',$val->unit);
		}
    	if(!$unit){
    		return json_encode(['code'=>'0', 'data'=>['0'=>'--请选择--'], 'message'=>'']);
    		die();
    	}
    	$resunit = ['0'=>'--请选择--'];
    	foreach ($unit as $key => $value) {
    		$resunit[$value->id] = $value->unit;
    	}
    	return json_encode(['code'=>'0', 'data'=>$resunit, 'message'=>'']);
    }
    public function doadd(){
    	print_r(Input::getContent());
    }
}
