<?php
//-----------------------------------------------------------------------------------------
//位置：前台店铺
//作者：让时光流逝
//时间：2018年10月31日
//-----------------------------------------------------------------------------------------
namespace App\Http\Controllers\User;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;

class StoreController extends Controller
{
	public function index(){
		return view("storelogin");
	}
	public function checklogin(){
		$request = Input::all();
		$res = DB::table('member')
		       ->join('store','store.user_id','=','member.id')
		       ->where('member.telephone','=',$request['username'])
		       ->first();
		//$res = DB::table('storeuser')->where('username','=',$request['username'])->first();
		if($res == null){
			return back()->with('msg','用户不存在');
		}else{
			if(md5($request['password']) !== $res->password){
				return back()->with('msg','密码错误');
			}else{
				session(['loginstore'=>$res]);
				$Request = new Request();
				$storedata = [
					'last_login' => $Request->ip(),
					'last_time' => time(),
				];
                DB::table('store')->where('user_id','=',$res->user_id)->update($storedata);
				return redirect("store");
			}
		}
	}

    public function logout(){
        session(['loginstore'=>null]);
        if(session('loginstore')){
            return redirect("store");
        }else{
            return redirect("user/login");
        }
    }
}