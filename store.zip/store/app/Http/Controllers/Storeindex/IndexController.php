<?php
//-----------------------------------------------------------------------------------------
//位置：店铺商品列表
//作者：让时光流逝
//时间：2018年11月7日
//-----------------------------------------------------------------------------------------

namespace App\Http\Controllers\Storeindex;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;

class IndexController extends Controller
{
    public function index($id){
    	$userinfo = session('loginstore')??0;
    	//添加storeid where('store_id', '=', $id)->
    	$storeinfo = DB::table('store')
					->join('member','store.user_id','=','member.id')
					->where('store.id', '=', $id)
					->first();

    	//获取一级分类
    	$category = DB::table('store_cate')->where('pid', '=', '0')->where('store_id','=',$id)->get();
    	foreach($category as $key => $val){
			$category[$key]->cate_name = iconv('GBK','UTF-8',$val->cate_name);
    		$category[$key]->children = DB::table('store_cate')->where('pid', '=', $val->id)->get();
			foreach($category[$key]->children as $a => $b){
				$category[$key]->children[$a]->cate_name = iconv('GBK','UTF-8',$b->cate_name);
			}
    	}

    	return view('storeindex.index')->with('shop_id',$id)->with(compact('storeinfo','storeinfo'))->with(compact('category','category'))->with('userinfo', $userinfo);
    }
    public function list(){
    	$userinfo = session('loginstore')??0;
    	
    	$shop_id = Input::get('shop_id');
    	$cate_id = Input::get('cate_id')===null??0;
    	//添加storeid where('store_id', '=', $id)->
    	$storeinfo = DB::table('store')
					->join('member','store.user_id','=','member.id')
					->where('store.id', '=', $shop_id)
					->first();

    	//获取一级分类
    	$category = DB::table('store_cate')->where('pid', '=', '0')->where('store_id','=',$shop_id)->get();

    	foreach($category as $key => $val){
			$category[$key]->cate_name = iconv('GBK','UTF-8',$val->cate_name);
    		$category[$key]->children = DB::table('store_cate')->where('pid', '=', $val->id)->get();
			foreach($category[$key]->children as $a => $b){
				$category[$key]->children[$a]->cate_name = iconv('GBK','UTF-8',$b->cate_name);
			}
    	}
    	return view('storeindex.list')->with('shop_id', $shop_id)->with(compact('storeinfo','storeinfo'))->with(compact('category','category'))->with('userinfo', $userinfo)->with('cat_id', $cate_id);
    }
    //ajax请求
    function user(){
    	if(session('loginstore')){
    		$data = [
    			"code" => 0,
			    "data" => [
			        "csrf_token" => csrf_token(),
			        "cart" => [
			            "goods_count" => 0
			        ],
			        "message" => [
			            "internal_count" => "31"
			        ],
			        "default_keywords" => [
			            [
			                "keyword" => "连衣裙",
			                "url" => "search.html?keyword=连衣裙"
			            ],
			            [
			                "keyword" => "电脑",
			                "url" => "search.html?keyword=电脑"
			            ],
			            [
			                "keyword" => "女装",
			                "url" => "search.html?keyword=女装"
			            ],
			            [
			                "keyword" => "户外",
			                "url" => "search.html?keyword=户外"
			            ],
			            [
			                "keyword" => "智能",
			                "url" => "search.html?keyword=智能"
			            ],
			            [
			                "keyword" => "大家电",
			                "url" => "search.html?keyword=大家电"
			            ]
			        ],
			        "hot_keywords" => [],
			        "search_records" => [],
			        "show_keywords" => [
			            "keyword" => "",
			            "show_words" => ""
			        ],
			        "site_id" => 2,
			        "region_code" => "11,01",
			        "site_change" => "<!--站点 start-->\n<div class=\"SZY-SUBSITE\">\n\t\n\t\n\t\t<ul class=\"fl\">\n\t\t<li class=\"dorpdown\" id=\"city-choice\">\n\t\t\t<dt class=\"sc-icon\">\n\t\t\t\t<div class=\"sc-choie\">\n\t\t\t\t\t<i class=\"iconfont color\">&#xe6a7;</i>\n\t\t\t\t\t<span class=\"ui-areamini-text\" data-id=\"2\" title=\"\">北京站&nbsp;&nbsp;&nbsp;</span>\n\t\t\t\t</div>\n                <div class=\"dd-spacer\"></div>\n\t\t\t</dt>\n\t\t\t<dd class=\"dorpdown-layer\">\n\t\t\t\t<div class=\"ui-areamini-content-wrap\" id=\"ui-content-wrap\">\n\t\t\t\t\t<!--当站点少的活，以dl下展示形式展示，如果展示多的话，以ul下的li展示形式展示-->\n\t\t\t\t\t\n\t\t\t\t\t<dl>\n\t\t\t\t\t\t<dt>站点</dt>\n\t\t\t\t\t\t\n\t\t\t\t\t\t\n\t\t\t\t\t\t<dd>\n\t\t\t\t\t\t\t<a href=\"/subsite/index.html?site_id=2\">北京站</a>\n\t\t\t\t\t\t</dd>\n\t\t\t\t\t\t\n\t\t\t\t\t\t\n\t\t\t\t\t\t\n\t\t\t\t\t\t<dd>\n\t\t\t\t\t\t\t<a href=\"/subsite/index.html?site_id=1\">秦皇岛站</a>\n\t\t\t\t\t\t</dd>\n\t\t\t\t\t\t\n\t\t\t\t\t\t\n\t\t\t\t\t\t\n\t\t\t\t\t\t<dd>\n\t\t\t\t\t\t\t<a href=\"/subsite/index.html?site_id=13\">上海站</a>\n\t\t\t\t\t\t</dd>\n\t\t\t\t\t\t\n\t\t\t\t\t\t\n\t\t\t\t\t\t\n\t\t\t\t\t\t<dd>\n\t\t\t\t\t\t\t<a href=\"/subsite/index.html?site_id=3\">天津站</a>\n\t\t\t\t\t\t</dd>\n\t\t\t\t\t\t\n\t\t\t\t\t\t\n\t\t\t\t\t\t\n\t\t\t\t\t\t<dd>\n\t\t\t\t\t\t\t<a href=\"/subsite/index.html?site_id=6\">张家口站</a>\n\t\t\t\t\t\t</dd>\n\t\t\t\t\t\t\n\t\t\t\t\t\t\n\t\t\t\t\t</dl>\n\t\t\t\t\t\n\t\t\t\t</div>\n\t\t\t</dd>\n\t\t</li>\n\t</ul>\n\t\t\n</div>\n<!--站点 end-->",
			        "user_name" => session('loginstore')->username,
			        "headimg" => session('loginstore')->username,
			        "last_time" => 1541492210,
			        "last_ip" => "121.69.28.58",
			        "last_region_code" => null,
			        "user_rank" => [
			            "rank_id" => "1",
			            "rank_name" => "注册会员",
			            "rank_img" => "http://68dsw.oss-cn-beijing.aliyuncs.com/images/user/rank/2016/09/17/14741183217266.jpg",
			            "min_points" => "0",
			            "max_points" => "1",
			            "type" => "0",
			            "is_special" => "0"
			        ],
			        "last_time_format" => "2018-11-06 16:16:50"
			    ],
			    "message" => ""
			];
    	}else{
    		$data = [
			    "code" => 0,
			    "data" => [
			        "csrf_token" => csrf_token(),
			        "cart" => [
			            "goods_count" => 0
			        ],
			        "message" => [
			            "internal_count" => "0"
			        ],
			        "default_keywords" => [
			             [
			                "keyword" => "连衣裙",
			                "url" => "search.html?keyword=连衣裙"
			            ],
			            [
			                "keyword" => "电脑",
			                "url" => "search.html?keyword=电脑"
			            ],
			            [
			                "keyword" => "女装",
			                "url" => "search.html?keyword=女装"
			            ],
			            [
			                "keyword" => "户外",
			                "url" => "search.html?keyword=户外"
			            ],
			            [
			                "keyword" => "智能",
			                "url" => "search.html?keyword=智能"
			            ],
			            [
			                "keyword" => "大家电",
			                "url" => "search.html?keyword=大家电"
			            ]
			        ],
			        "hot_keywords" => [
			            [
			                "id" => "2",
			                "keyword" => "全身镜",
			                "show_words" => "魔镜魔镜谁最美",
			                "url" => "search.html?keyword=全身镜"
			            ],
			            [
			                "id" => "3",
			                "keyword" => "躺椅折叠午休",
			                "show_words" => "办公室神器",
			                "url" => "search.html?keyword=躺椅折叠午休"
			            ],
			            [
			                "id" => "4",
			                "keyword" => "榨汁机",
			                "show_words" => "榨出营养,喝出健康",
			                "url" => "search.html?keyword=榨汁机"
			            ],
			            [
			                "id" => "5",
			                "keyword" => "科11",
			                "show_words" => "科比退役穿的鞋子",
			                "url" => "search.html?keyword=科11"
			            ],
			            [
			                "id" => "6",
			                "keyword" => "凉鞋",
			                "show_words" => "夏季欢乐购,凉鞋八折起",
			                "url" => "search.html?keyword=凉鞋"
			            ],
			            [
			                "id" => "8",
			                "keyword" => "雀巢",
			                "show_words" => "雀巢超级品牌日",
			                "url" => "search.html?keyword=雀巢"
			            ],
			            [
			                "id" => "7",
			                "keyword" => "连衣裙",
			                "show_words" => "女神节,女装5折狂甩",
			                "url" => "search.html?keyword=连衣裙"
			            ],
			            [
			                "id" => "9",
			                "keyword" => "洁面乳",
			                "show_words" => "好用的洁面乳",
			                "url" => "search.html?keyword=洁面乳"
			            ],
			            [
			                "id" => "10",
			                "keyword" => "彩妆",
			                "show_words" => "完美的自己",
			                "url" => "search.html?keyword=彩妆"
			            ]
			        ],
			        "search_records" => [],
			        "show_keywords" => [
			            "id" => "6",
			            "keyword" => "凉鞋",
			            "show_words" => "夏季欢乐购,凉鞋八折起",
			            "url" => "search.html?keyword=凉鞋"
			        ]
			    ],
			    "message" => ""
			];
		}
    	return json_encode($data);
    }
    public function boxgoodslist(){
    	$data = [
		    "code" => 0,
		    "data" => [
		        '<!-- 购物车为空 -->
		        <div class="cart-type">
		        	<i class="cart-type-icon"></i>
		        	<div class="cart-type-text">
		        		您的购物车里什么都没有哦
		        		<br />
		        		<a class="color" href="http://www.68dsw.com" title="再去看看吧" target="_blank">再去看看吧</a>
		        	</div>
		        </div>',
		        '<div class="cart-panel-main">
		        	<div class="cart-panel-content">
			        	<!-- 没有商品的展示形式 _start -->
			        	<div class="tip-box">
			        		<img src="/static/storeindex/images/noresult.png" class="tip-icon" />
			        		<div class="tip-text">
			        			您的购物车里什么都没有哦
			        			<br />
			        			<a class="color" href="http://www.68dsw.com" title="再去看看吧" target="_blank">再去看看吧</a>
			        		</div>
			        	</div>
			        	<!-- 没有商品的展示形式 _end-->
			        </div>
			    </div>'
		    ],
		    "message" => "",
		    "count" => 0,
		    "amount" => 0
		];
		return json_encode($data);
    }
    public function info(){
    	$shop_id = Input::get('shop_id');
    	$data = [
		    "code" => 0,
		    "data" => [
		        "shop_id" => $shop_id,
		        "shop_info" => [
		            "shop" => [
		                "shop_id" => "309",
		                "user_id" => "1717",
		                "site_id" => "13",
		                "shop_name" => "三只松鼠旗舰店",
		                "shop_image"=> "/shop/309/images/2017/05/03/14937788962061.jpg",
		                "shop_logo" => "/shop/309/images/2017/05/03/14937788991187.jpg",
		                "shop_poster" => "/shop/309/images/2017/05/03/14937790163982.jpg",
		                "shop_sign" => "/shop/309/images/2017/05/03/14937792780987.jpg",
		                "shop_type" => "1",
		                "is_supply" => "0",
		                "cat_id" => "0",
		                "credit" => "23",
		                "desc_score" => "4.00",
		                "service_score" => "5.00",
		                "send_score" => "5.00",
		                "logistics_score" => "5.00",
		                "region_code" => "31,01",
		                "address" => "嘉定区江桥镇曹安公路2038号华拓大厦",
		                "shop_lng" => "121.349068",
		                "shop_lat" => "31.258927",
		                "opening_hour" => "a:5:{s:4:\"week\";a:7:{i:0;s:1:\"0\";i:1;s:1:\"1\";i:2;s:1:\"2\";i:3;s:1:\"3\";i:4;s:1:\"4\";i:5;s:1:\"5\";i:6;s:1:\"6\";}s:10:\"begin_hour\";a:1:{i:0;s:1:\"0\";}s:12:\"begin_minute\";a:1:{i:0;s:1:\"0\";}s:8:\"end_hour\";a:1:{i:0;s:2:\"23\";}s:10:\"end_minute\";a:1:{i:0;s:2:\"59\";}}",
		                "close_tips" => null,
		                "add_time" => "1493778333",
		                "pass_time" => "1493778333",
		                "duration" => "1",
		                "unit" => "0",
		                "clearing_cycle" => "0",
		                "open_time" => "1493740800",
		                "end_time" => "1610294153",
		                "system_fee" => "1000.00",
		                "insure_fee" => "1000.00",
		                "goods_status" => "0",
		                "shop_status" => "1",
		                "close_info" => "",
		                "shop_sort" => "255",
		                "shop_audit" => "1",
		                "fail_info" => null,
		                "simply_introduce" => null,
		                "shop_keywords" => "",
		                "shop_description" => "",
		                "detail_introduce" => "",
		                "service_tel" => "2342342",
		                "service_hours" => "",
		                "shop_sign_m" => "",
		                "take_rate" => "5.00",
		                "qrcode_take_rate" => "5.00",
		                "collect_allow_number" => "100",
		                "collected_number" => "67",
		                "store_allow_number" => "100",
		                "store_number" => "1",
		                "comment_allow_number" => "10",
		                "comment_number" => "1",
		                "login_status" => "1",
		                "show_credit" => "1",
		                "show_in_street" => "1",
		                "goods_is_show" => "1",
		                "control_price" => "1",
		                "show_price" => "1",
		                "show_content" => "隐藏",
		                "button_content" => "面议",
		                "button_url" => null,
		                "start_price" => "0.00",
		                "shop_sn" => "",
		                "rebate_enable" => "0",
		                "rebate_days" => "0",
		                "rebate_setting" => null,
		                "rebate_begin_time" => "0",
		                "region_name" => "上海市 上海市"
		            ],
		            "user" => [
		                "user_id" => "1717",
		                "user_name" => "三只松鼠旗舰店店长",
		                "mobile" => "18103332528",
		                "email" => null,
		                "nickname" => "",
		                "headimg" => null
		            ],
		            "credit" => [
		                "credit_id" => "2",
		                "credit_name" => "二星",
		                "credit_img" => "/system/credit/2016/12/26/14827402454984.gif",
		                "min_point" => "11",
		                "max_point" => "40",
		                "remark" => ""
		            ],
		            "address" => [
		                [
		                    "address_id" => "26",
		                    "consignee" => "松鼠",
		                    "region_code" => "13,04,24",
		                    "address_detail" => "桥头村",
		                    "mobile" => "13326612732",
		                    "tel" => "",
		                    "email" => "",
		                    "is_default" => "1",
		                    "shop_id" => "309"
		                ]
		            ],
		            "customer_main" => false,
		            "aliim_enable" => "",
		            "customer" => null
		        ],
		        "region_name" => "上海市 上海市",
		        "duration_time" => "1年 6个月 7天",
		        "is_collect" => false,
		        "collect_count" => "10",
		        "goods_count" => 121,
		        "bonus_count" => "0",
		        "im_enable" => "1",
		        "position" => "info",
		        "show_collect_count" => "1"
		    ],
		    "message" => ""
		];
		return json_encode($data);
    }
}
