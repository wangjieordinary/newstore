<?php
//-----------------------------------------------------------------------------------------
//位置：店铺订单
//作者：让时光流逝
//时间：2018年11月11日
//-----------------------------------------------------------------------------------------

namespace App\Http\Controllers\Order;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;

class DeliveryController extends Controller
{
    public function index(){

    	//等待发货 0 已发货 1
    	$orderinfo = DB::table('dingdan')
               ->join('gouwuche',function($join){
                    $join->on('dingdan.uid','=','gouwuche.uid')
                         ->on('dingdan.ddh','=','gouwuche.ddh');
               })
               ->leftJoin('product','gouwuche.pid','=','product.id')
               ->selectRaw('dingdan.*')
               ->where('product.store_id','=',session('loginstore')->id)
               ->whereNull('product.status')
               ->get();
		foreach($orderinfo as $key => $val){			
			$orderinfo[$key]->sname = iconv('GBK','UTF-8',$val->sname);
			$orderinfo[$key]->sadd = iconv('GBK','UTF-8',$val->sadd);
			$orderinfo[$key]->wlmc = iconv('GBK','UTF-8',$val->wlmc);
			$orderinfo[$key]->sname = iconv('GBK','UTF-8',$val->sname);
		}
    	return view('delivery.index')->with('position','order-index');
    }
    public function batchdelivery(){
    	return;
    }
    public function toshipping(){
    	if(Input::get('id') == null){
    		return back()->withErrors(['没有此订单！']);
    	}
    	//$orderinfo = DB::table('dingdan')->where('id','=',Input::get('id'))->first();

    	$orderinfo = DB::table('dingdan')
               ->join('gouwuche',function($join){
                    $join->on('dingdan.uid','=','gouwuche.uid')
                         ->on('dingdan.ddh','=','gouwuche.ddh');
               })
               ->leftJoin('product','gouwuche.pid','=','product.id')
               ->selectRaw('dingdan.*')
               ->where('product.store_id','=',session('loginstore')->id)
               ->where('dingdan.id','=',Input::get('id'))
               ->first();
		foreach($orderinfo as $key => $val){			
			$orderinfo->$key = iconv('GBK','UTF-8',$val);
		}
        if($orderinfo == null){
    		return back()->withErrors(['没有此订单！']);
    	}

    	$orderinfo->userinfo = DB::table('member')->where('id','=',$orderinfo->uid)->first();
    	$orderinfo->goodslist = DB::table('gouwuche')
    							->join('product','product.id','=','gouwuche.pid')
    	                        ->where('gouwuche.ddh','=',$orderinfo->ddh)
    	                        ->where('gouwuche.uid',$orderinfo->uid)
    	                        ->where('product.store_id','=', session('loginstore')->id)
    	                        ->get();
		foreach($orderinfo->goodslist as $key => $val){			
			$orderinfo->goodslist[$key] = iconv('GBK','UTF-8',$val->name);
		}
    	$orderinfo->goodscount = count($orderinfo->goodslist);

        //第三方物流
        $express = DB::table('express')->get();
    	return view('order.toshipping')->with('orderinfo',$orderinfo)->with(compact('express','express'))->with('position','order-index');
    }

    public function dotoshipping(){
        $input = Input::all();
        $ship = DB::table('express')->where('id','=',$input['shipping_id'])->pluck('txtexpressname');
        $shipname = $ship[0];
        $sqldata = [
            'wlmc' => iconv('UTF-8','GBK',$shipname),
            'kddh' => $input['express_sn'],
            'zt' => '3'
        ];
        $res = DB::table('dingdan')->where('id','=',$input['id'])->update($sqldata);
        if($res){
            return json_encode(['code'=>'0','data'=> '','message'=>'发货成功']);
        }else{
            return json_encode(['code'=>'-1','data'=> '','message'=>'发货失败']);
        }
    }

    public function getordercounts(){
    	$input = Input::all();
    	//所有订单
    	$all = DB::table('dingdan')
    		   ->join('gouwuche',function($join){
    		   		$join->on('dingdan.uid','=','gouwuche.uid')
    		   			 ->on('dingdan.ddh','=','gouwuche.ddh');
    		   })
    		   ->leftJoin('product','gouwuche.pid','=','product.id')
    		   ->selectRaw('count(dingdan.id) as count')
    		   ->where('product.store_id','=',session('loginstore')->id)
    		   ->first();
    	$all = $all->count;

    	//待支付订单
    	$unpayed = DB::table('dingdan')
    		   ->join('gouwuche',function($join){
    		   		$join->on('dingdan.uid','=','gouwuche.uid')
    		   			 ->on('dingdan.ddh','=','gouwuche.ddh');
    		   })
    		   ->leftJoin('product','gouwuche.pid','=','product.id')
    		   ->selectRaw('count(dingdan.id) as count')
    		   ->where('product.store_id','=',session('loginstore')->id)
    		   ->where('dingdan.zt','=','1')
    		   ->first();
    	$unpayed = $unpayed->count;

    	//已发货
    	$shipped = DB::table('dingdan')
    		   ->join('gouwuche',function($join){
    		   		$join->on('dingdan.uid','=','gouwuche.uid')
    		   			 ->on('dingdan.ddh','=','gouwuche.ddh');
    		   })
    		   ->leftJoin('product','gouwuche.pid','=','product.id')
    		   ->selectRaw('count(dingdan.id) as count')
    		   ->where('product.store_id','=',session('loginstore')->id)
    		   ->where('dingdan.zt','=','3')
    		   ->first();
    	$shipped = $shipped->count;

    	//已完成
    	$finished = DB::table('dingdan')
    		   ->join('gouwuche',function($join){
    		   		$join->on('dingdan.uid','=','gouwuche.uid')
    		   			 ->on('dingdan.ddh','=','gouwuche.ddh');
    		   })
    		   ->leftJoin('product','gouwuche.pid','=','product.id')
    		   ->selectRaw('count(dingdan.id) as count')
    		   ->where('product.store_id','=',session('loginstore')->id)
    		   ->whereNotNull('dingdan.etime')
    		   ->first();
    	$finished = $finished->count;


    	$returndata = [
    		'all' => $all,
    		'unpayed' => $unpayed,
    		'unshipped' => '0',
    		'assign' => '0',
    		'shipped' => $shipped,
    		'finished' => $finished,
    		'closed' => '0',
    		'backing' => '0',
    		'cancel' => '0',
    		'pending' => '0'
    	];
    	return json_encode($returndata);
    }
}
