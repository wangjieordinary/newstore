<?php
//-----------------------------------------------------------------------------------------
//位置：店铺订单
//作者：让时光流逝
//时间：2018年11月7日
//-----------------------------------------------------------------------------------------

namespace App\Http\Controllers\Order;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    public function index(){
        $input = Input::all();
        $order_status = Input::get('order_status');
        if($order_status == '' || $order_status==null){
            $count = DB::table('dingdan')
                   ->join('gouwuche',function($join){
                        $join->on('dingdan.uid','=','gouwuche.uid')
                             ->on('dingdan.ddh','=','gouwuche.ddh');
                   })
                   ->leftJoin('product','gouwuche.pid','=','product.id')
                   ->selectRaw('count(dingdan.id) as count')
                   ->where('product.store_id','=',session('loginstore')->id)
                   ->first();
            $count = $count->count;
            $orderlist = DB::table('dingdan')
                   ->join('gouwuche',function($join){
                        $join->on('dingdan.uid','=','gouwuche.uid')
                             ->on('dingdan.ddh','=','gouwuche.ddh');
                   })
                   ->leftJoin('product','gouwuche.pid','=','product.id')
                   ->selectRaw('dingdan.*')
                   ->where('product.store_id','=',session('loginstore')->id)
                   ->paginate(10);
          	foreach($orderlist as $key => $val){
				$orderinfo[$key]->sname = iconv('GBK','UTF-8',$val->sname);
				$orderinfo[$key]->sadd = iconv('GBK','UTF-8',$val->sadd);
				$orderinfo[$key]->wlmc = iconv('GBK','UTF-8',$val->wlmc);
				$orderinfo[$key]->sname = iconv('GBK','UTF-8',$val->sname);
				
          		$orderlist[$key]->userinfo = DB::table('member')->where('id','=',$val->uid)->first();
          		$orderlist[$key]->goodslist = DB::table('gouwuche')->where('ddh','=',$val->ddh)->where('uid',$val->uid)->get();
          		$orderlist[$key]->goodscount = count($orderlist[$key]->goodslist);
          		foreach($orderlist[$key]->goodslist as $a=>$b){
					
					
					$orderlist[$key]->goodslist[$a]->goodsinfo = DB::table('product')->where('id','=',$b->pid)->first();
              		$orderlist[$key]->cost = $orderlist[$key]->cost??0+$b->zcb;
          		}
          	}
          	return view('order.index',compact('orderlist', 'orderlist'))->with('count',$count)->with('position','order-index');
        }
        else if($order_status=='all')
        {
            $count = DB::table('dingdan')
                   ->join('gouwuche',function($join){
                        $join->on('dingdan.uid','=','gouwuche.uid')
                             ->on('dingdan.ddh','=','gouwuche.ddh');
                   })
                   ->leftJoin('product','gouwuche.pid','=','product.id')
                   ->selectRaw('count(dingdan.id) as count')
                   ->where('product.store_id','=',session('loginstore')->id)
                   ->first();
            $count = $count->count;
            $orderlist = DB::table('dingdan')
                   ->join('gouwuche',function($join){
                        $join->on('dingdan.uid','=','gouwuche.uid')
                             ->on('dingdan.ddh','=','gouwuche.ddh');
                   })
                   ->leftJoin('product','gouwuche.pid','=','product.id')
                   ->selectRaw('dingdan.*')
                   ->where('product.store_id','=',session('loginstore')->id)
                   ->paginate(10);
            foreach($orderlist as $key => $val){
                $orderlist[$key]->userinfo = DB::table('member')->where('id','=',$val->uid)->first();
                $orderlist[$key]->goodslist = DB::table('gouwuche')->where('ddh','=',$val->ddh)->where('uid',$val->uid)->get();
                $orderlist[$key]->goodscount = count($orderlist[$key]->goodslist);
                foreach($orderlist[$key]->goodslist as $a=>$b){
                    $orderlist[$key]->goodslist[$a]->goodsinfo = DB::table('product')->where('id','=',$b->pid)->first();
                    $orderlist[$key]->cost = $orderlist[$key]->cost??0+$b->zcb;
                }
            }
            $html = view('order.list')->with(compact('orderlist','orderlist'))->with('order_status',$order_status)->render();
            return json_encode(['code'=>'0','data'=>$html,'message'=>'']);
        }
        else if($order_status == 'unpayed'){
            //待付款
            $count = DB::table('dingdan')
                   ->join('gouwuche',function($join){
                        $join->on('dingdan.uid','=','gouwuche.uid')
                             ->on('dingdan.ddh','=','gouwuche.ddh');
                   })
                   ->leftJoin('product','gouwuche.pid','=','product.id')
                   ->selectRaw('count(dingdan.id) as count')
                   ->where('product.store_id','=',session('loginstore')->id)
                   ->where('dingdan.zt','=','1')
                   ->first();
            $count = $count->count;
            $orderlist = DB::table('dingdan')
                   ->join('gouwuche',function($join){
                        $join->on('dingdan.uid','=','gouwuche.uid')
                             ->on('dingdan.ddh','=','gouwuche.ddh');
                   })
                   ->leftJoin('product','gouwuche.pid','=','product.id')
                   ->selectRaw('dingdan.*')
                   ->where('product.store_id','=',session('loginstore')->id)
                   ->where('dingdan.zt','=','1')
                   ->paginate(10);

            //$orderlist = DB::table('dingdan')->paginate(10);
            foreach($orderlist as $key => $val){
                $orderlist[$key]->userinfo = DB::table('member')->where('id','=',$val->uid)->first();
                $orderlist[$key]->goodslist = DB::table('gouwuche')->where('ddh','=',$val->ddh)->where('uid',$val->uid)->get();
                $orderlist[$key]->goodscount = count($orderlist[$key]->goodslist);
                foreach($orderlist[$key]->goodslist as $a=>$b){
                    $orderlist[$key]->goodslist[$a]->goodsinfo = DB::table('product')->where('id','=',$b->pid)->first();
                    $orderlist[$key]->cost = $orderlist[$key]->cost??0+$b->zcb;
                }
            }
            $html = view('order.list')->with(compact('orderlist','orderlist'))->with('order_status',$order_status)->render();
            return json_encode(['code'=>'0','data'=>$html,'message'=>'']);
        }else if($order_status == 'shipped'){
          //已发货
          $count = DB::table('dingdan')
                   ->join('gouwuche',function($join){
                        $join->on('dingdan.uid','=','gouwuche.uid')
                             ->on('dingdan.ddh','=','gouwuche.ddh');
                   })
                   ->leftJoin('product','gouwuche.pid','=','product.id')
                   ->selectRaw('count(dingdan.id) as count')
                   ->where('product.store_id','=',session('loginstore')->id)
                   ->where('dingdan.zt','=','3')
                   ->first();
            $count = $count->count;
            $orderlist = DB::table('dingdan')
                   ->join('gouwuche',function($join){
                        $join->on('dingdan.uid','=','gouwuche.uid')
                             ->on('dingdan.ddh','=','gouwuche.ddh');
                   })
                   ->leftJoin('product','gouwuche.pid','=','product.id')
                   ->selectRaw('dingdan.*')
                   ->where('product.store_id','=',session('loginstore')->id)
                   ->where('dingdan.zt','=','3')
                   ->paginate(10);

          //$orderlist = DB::table('dingdan')->paginate(10);
          foreach($orderlist as $key => $val){
            $orderlist[$key]->userinfo = DB::table('member')->where('id','=',$val->uid)->first();
            $orderlist[$key]->goodslist = DB::table('gouwuche')->where('ddh','=',$val->ddh)->where('uid',$val->uid)->get();
            $orderlist[$key]->goodscount = count($orderlist[$key]->goodslist);
            foreach($orderlist[$key]->goodslist as $a=>$b){
              $orderlist[$key]->goodslist[$a]->goodsinfo = DB::table('product')->where('id','=',$b->pid)->first();
              $orderlist[$key]->cost = $orderlist[$key]->cost??0+$b->zcb;
            }
          }
          $html = view('order.list')->with(compact('orderlist','orderlist'))->with('order_status',$order_status)->render();
          return json_encode(['code'=>'0','data'=>$html,'message'=>'']);
        }else{
          //已完成
          $count = DB::table('dingdan')
                   ->join('gouwuche',function($join){
                        $join->on('dingdan.uid','=','gouwuche.uid')
                             ->on('dingdan.ddh','=','gouwuche.ddh');
                   })
                   ->leftJoin('product','gouwuche.pid','=','product.id')
                   ->selectRaw('count(dingdan.id) as count')
                   ->where('product.store_id','=',session('loginstore')->id)
                   ->whereNotNull('dingdan.etime')
                   ->first();
            $count = $count->count;
            $orderlist = DB::table('dingdan')
                   ->join('gouwuche',function($join){
                        $join->on('dingdan.uid','=','gouwuche.uid')
                             ->on('dingdan.ddh','=','gouwuche.ddh');
                   })
                   ->leftJoin('product','gouwuche.pid','=','product.id')
                   ->selectRaw('dingdan.*')
                   ->where('product.store_id','=',session('loginstore')->id)
                   ->whereNotNull('dingdan.etime')
                   ->paginate(10);

          //$orderlist = DB::table('dingdan')->paginate(10);
          foreach($orderlist as $key => $val){
            $orderlist[$key]->userinfo = DB::table('member')->where('id','=',$val->uid)->first();
            $orderlist[$key]->goodslist = DB::table('gouwuche')->where('ddh','=',$val->ddh)->where('uid',$val->uid)->get();
            $orderlist[$key]->goodscount = count($orderlist[$key]->goodslist);
            foreach($orderlist[$key]->goodslist as $a=>$b){
              $orderlist[$key]->goodslist[$a]->goodsinfo = DB::table('product')->where('id','=',$b->pid)->first();
              $orderlist[$key]->cost = $orderlist[$key]->cost??0+$b->zcb;
            }
          }
          $html = view('order.list')->with(compact('orderlist','orderlist'))->with('order_status',$order_status)->render();
          return json_encode(['code'=>'0','data'=>$html,'message'=>'']);
        }
    }

    public function info(){
      	if(Input::get('id') == null){
      		return back()->withErrors(['没有此订单！']);
      	}
        $orderinfo = DB::table('dingdan')
               ->join('gouwuche',function($join){
                    $join->on('dingdan.uid','=','gouwuche.uid')
                         ->on('dingdan.ddh','=','gouwuche.ddh');
               })
               ->leftJoin('product','gouwuche.pid','=','product.id')
               ->selectRaw('dingdan.*')
               ->where('product.store_id','=',session('loginstore')->id)
               ->first();
        if($orderinfo == null){
            return back()->withErrors(['没有此订单！']);
        }
    	//$orderinfo = DB::table('dingdan')->where('id','=',Input::get('id'))->first();
    	$orderinfo->userinfo = DB::table('member')->where('id','=',$orderinfo->uid)->first();
    	$orderinfo->goodslist = DB::table('gouwuche')
    							->join('product','product.id','=','gouwuche.pid')
    	                        ->where('gouwuche.ddh','=',$orderinfo->ddh)
    	                        ->where('gouwuche.uid',$orderinfo->uid)
                                //->where('product.store_id','=', session('loginstore'))
    	                        ->get();
    	$orderinfo->goodscount = count($orderinfo->goodslist);
    	return view('order.info')->with('orderinfo', $orderinfo)->with('storeinfo',session('loginstore'))->with('position','order-index');
    }
}
