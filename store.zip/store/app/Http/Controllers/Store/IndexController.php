<?php
//-----------------------------------------------------------------------------------------
//位置：前台店铺
//作者：让时光流逝
//时间：2018年10月31日
//-----------------------------------------------------------------------------------------
namespace App\Http\Controllers\Store;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;

class IndexController extends Controller
{
    public function index(){
        $store = DB::table('member')
               ->join('store','store.user_id','=','member.id')
               ->where('member.telephone','=',session('loginstore')->telephone)
               ->first();
        $store = compact('store', 'store');
        
        return view("store.index", $store)->with('position','index-index');
    }

    //ajax统计
    public function ajaxcount(){
        //出售中的商品
        $sellcount = DB::table('product')
                        ->where('product.status', '=', '6')
                        ->where('product.store_id', '=', session("loginstore")->id)
                        ->count();
        $data['onsale_goods_count'] = $sellcount;

        $offsale_goods_count = DB::table('product')
                        ->where('product.store_id', '=', session("loginstore")->id)
                        ->count();
        //仓库中的商品
        $data['offsale_goods_count'] = $offsale_goods_count?$offsale_goods_count:'0';
        //等待审核的商品
        $data['wait_audit_goods_count'] = '0';
        //违规下架的商品
        $data['illegal_goods_count'] = '0';
        //待付款订单
        $unpayed_order_count = DB::table('dingdan')
                   ->join('gouwuche',function($join){
                        $join->on('dingdan.uid','=','gouwuche.uid')
                             ->on('dingdan.ddh','=','gouwuche.ddh');
                   })
                   ->leftJoin('product','gouwuche.pid','=','product.id')
                   ->selectRaw('count(dingdan.id) as count')
                   ->where('product.store_id','=',session('loginstore')->id)
                   ->where('dingdan.zt','=','1')
                   ->first();
        $unpayed_order_count = $unpayed_order_count->count;
        $data['unpayed_order_count'] = $unpayed_order_count??'0';
        //待发货订单
        $unshipping_order_count = DB::table('dingdan')
                   ->join('gouwuche',function($join){
                        $join->on('dingdan.uid','=','gouwuche.uid')
                             ->on('dingdan.ddh','=','gouwuche.ddh');
                   })
                   ->leftJoin('product','gouwuche.pid','=','product.id')
                   ->selectRaw('count(dingdan.id) as count')
                   ->where('product.store_id','=',session('loginstore')->id)
                   ->whereNotNull('dingdan.stime')
                   ->first();
        $unshipping_order_count = $unshipping_order_count->count;
        $data['unshipping_order_count'] = $unshipping_order_count??'0';
        //待评价订单
        $data['unevaluate_order_count'] = '0';
        //退款中订单
        $data['backing_order_count'] = '0';
        //售后退款订单
        $data['after_sale_order_count'] = '0';
        //换货维修订单
        $data['exchange_order_count'] = '0';
        //待处理的投诉
        $data['wait_complaint_count'] = '0';
        //平台介入的投诉
        $data['involve_complaint_count'] = '0';
        //今日收益
        $today_gains = DB::table('dingdan')
                   ->join('gouwuche',function($join){
                        $join->on('dingdan.uid','=','gouwuche.uid')
                             ->on('dingdan.ddh','=','gouwuche.ddh');
                   })
                   ->leftJoin('product','gouwuche.pid','=','product.id')
                   ->selectRaw('dingdan.jine as jine')
                   ->where('product.store_id','=',session('loginstore')->id)
                   ->whereBetween('dingdan.ptime',[date('Y-m-d 00:00:00'),date('Y-m-d 23:59:59')])
                   ->get();
        $today_gainsaa = '';
        if(count($today_gains)>0){
           foreach($today_gains as $key => $val){
                $today_gainsaa += $val->jine;
            } 
        }
        
        $data['today_gains'] = $today_gainsaa?$today_gainsaa:'0.00';
        //今日订单
        $today_order_count = DB::table('dingdan')
                   ->join('gouwuche',function($join){
                        $join->on('dingdan.uid','=','gouwuche.uid')
                             ->on('dingdan.ddh','=','gouwuche.ddh');
                   })
                   ->leftJoin('product','gouwuche.pid','=','product.id')
                   ->selectRaw('count(dingdan.id) as count')
                   ->where('product.store_id','=',session('loginstore')->id)
                   ->whereBetween('dingdan.ptime',[date('Y-m-d 00:00:00'),date('Y-m-d 23:59:59')])
                   ->first();
        $today_order_count = $today_order_count->count;
        $data['today_order_count'] = $today_order_count??'0';
        //今日添加会员
        $data['today_users_count'] = '0';

        return response()->json($data);
        //return json_encode($data);
    }

    public function showmessage(){
        $data = [
            'code' => 0,
            'data' => 1,
            'message' => ''
        ];
        return json_encode($data);
    }

    public function expirationreminding(){
        $data = [
            'code' => '-1',
            'data' => null,
            'message' => ''
        ];
        return json_encode($data);
    }
}
