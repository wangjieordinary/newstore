<?php
//-----------------------------------------------------------------------------------------
//位置：店铺商品列表
//作者：让时光流逝
//时间：2018年10月31日
//-----------------------------------------------------------------------------------------
namespace App\Http\Controllers\Store;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use LaravelQRCode\Facades\QRCode;

class GoodsController extends Controller
{
	public function index(){
		$count = DB::table('product')
						->where('status', '=', '6')
						->where('store_id', '=', session("loginstore")->id)
						->count();
		$productlist = DB::table('product')
						->orderBy('addtime', 'desc')
						->where('status', '=', '6')
						->where('store_id', '=', session("loginstore")->id)
						->paginate('10');
		foreach($productlist as $k => $v){
			$productlist[$k]->name = iconv('GBK','UTF-8',$v->name);
		}
		
		return view('store.productlist', compact('productlist', 'productlist'))->with('procount',$count)->with('position','goods-index');
	}

	//发布商品
	public function publish(){
		//列出一级导航
		//$oneparent = DB::select('select * from category where [ParentID] in(1,2) and hide');
		$oneparent = DB::table('category')
		            ->select('id','category')
		            ->whereIn('ParentID',['1','2'])
		            ->where('hide','=','0')
		            ->get();
		//转编码		
		foreach($oneparent as $key => $val){			
			$oneparent[$key]->category = iconv('GBK','UTF-8',$val->category);
		}

		return view('store.addproduct',compact('oneparent','oneparent'))->with('position','goods-publish');
	}

	//添加商品下一步
	public function nextpublish(){
		$id = Input::all()['cat_id'];
		$category = DB::table('category')->where('id','=',$id)->first();
		$pcategory = DB::table('category')->where('id','=',$category->ParentID)->first();
		$ppcategory = DB::table('category')->where('id','=',$pcategory->ParentID)->first();
		$categorynamestr = [
			'cat_id' => $id,
			'category' => iconv('GBK','UTF-8',$category->category),
			'pcategory' => iconv('GBK','UTF-8',$pcategory->category),
			'ppcategory' => iconv('GBK','UTF-8',$ppcategory->category)
		];
		//规格
		$goodsspec = DB::table('goods_spec')->get();
		foreach($goodsspec as $k=>$v){
			$goodsspec[$k]->spec_name = iconv('GBK','UTF-8',$v->spec_name);
			$goodsspec[$k]->spec_value = iconv('GBK','UTF-8',$v->spec_value);
			
			$goodsspec[$k]->spec_value = (object)explode(',', $v->spec_value);
		}

		//运费
		$freight = DB::table('delivery')->get();
		foreach($freight as $key => $val){			
			$freight[$key]->title = iconv('GBK','UTF-8',$val->title);
		}

		// 品牌
		$brandidlist = 
		
		$brand = DB::table('brand')->where('catid','=',$id)->get();
		$brandone = DB::table('brand')->where('catidlist','like','%|'.$id.'|%')->get();
		$brand = $brand->merge($brandone);
		$brandtwo = DB::table('brand')->where('catidlist','like','%|'.$category->id.'|%')->get();
		$brand = $brand->merge($brandtwo);
		$brandthree = DB::table('brand')->where('catidlist','like','%|'.$category->ParentID.'|%')->get();
		$brand = $brand->merge($brandtwo);
		$brandfour = DB::table('brand')->where('catidlist','like','%|'.$pcategory->ParentID.'|%')->get();
		$brand = $brand->merge($brandfour);
		$brand = $brand->toArray();
		foreach($brand as $key => $val){
			if($key>0 && $brand[($key-1)]->id == $val->id){
				unset($brand[($key-1)]);
			}
		}
		$brand = array_values($brand);
		foreach($brand as $a => $b){
			$brand[$a]->brand = iconv('GBK','UTF-8',$b->brand);
		}

		//单位
		$goods_unit = DB::table('goods_unit')->get();
		foreach($goods_unit as $key => $val){			
			$goods_unit[$key]->unit = iconv('GBK','UTF-8',$val->unit);
		}
		
		//店铺分类
		//$store_cate = DB::table('store_cate')->get();

		return view('store.nextpropublish',compact('goodsspec','goodsspec'))->with('categorynamestr', $categorynamestr)->with(compact('freight', 'freight'))->with(compact('brand','brand'))->with(compact('goods_unit','goods_unit'))->with('position','goods-publish');
	}
	//执行发布商品
	public function dopublish(){
		$input = Input::getContent();
		$input = json_decode($input);

		//商品表所需字段
		$category = DB::table('category')->where('id','=',$input->cat_id)->first();
		$pcategory = DB::table('category')->where('id','=',$category->ParentID)->first();
		//$ppcategory = DB::table('category')->where('id','=',$pcategory->ParentID)->first();
		
		$catidlist = '|'.$pcategory->ParentID.'|'.$category->ParentID.'|'.$input->cat_id.'|$';
		//$data['cate_name'] = iconv('UTF-8','GBK',$data['cate_name']);
		

		if($input->goods_image!==null && strpos($input->goods_image,env('APP_URL'))!==false){
			$input->goods_image = $input->goods_image;
		}else{
			$input->goods_image = env('APP_URL').$input->goods_image;
		}
		$goods_data = [
			'store_id' => session("loginstore")->id??0,
			'catid' => $input->cat_id??0,
			'czy' => session("loginstore")->user_id??0,
			'huohao' => $input->goods_sn?$input->goods_sn:date('Ymd') . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT),
			//'goods_qrcode' => base64_encode(QRCode::text("https://www.baidu.com")->png()),
			'pic1' => $input->goods_image??0,
			'name' => iconv('UTF-8','GBK',$input->GoodsModel->goods_name)??0,
			'content' => iconv('UTF-8','GBK',$input->GoodsModel->pc_desc)??0,
			'price1' => $input->market_price??0,
			'price2' => $input->goods_price??0,
			'price3' => $input->cost_price??0,
			'kucun' => $input->goods_number??0,
			'Descriptions' => iconv('UTF-8','GBK',$input->goods_subname),
			'status' => '6',
			'shop_cat_ids' => $input->shop_cat_ids??0,
			'weight' => $input->goods_weight??0,
			'volume_weight' => $input->goods_volume??0,
			'invoice_type' =>  $input->GoodsModel->invoice_type??0,
			'pricing_mode' => $input->pricing_mode??0,
			'sales_model' => $input->sales_model??0,
			'freight_id' => $input->freight_id??0,
			'goods_moq' => $input->GoodsModel->goods_moq,
			'Keywords' => iconv('UTF-8','GBK',$input->keywords),
			'publish_time' => time(),
			'onsale' => $input->GoodsModel->is_show==1?0:1,
			'ontime' => date("Y-m-d H:i:s"),
			'viewnum' => '0',
			'goods_unit' => $input->GoodsModel->goods_unit,
			'goods_barcode' => $input->goods_barcode??0,
		];
		$sql = "INSERT INTO [product] ([store_id],[catid],[czy],[huohao],[pic1],[name],[content],[price1],[price2],[price3],[kucun],[Descriptions],[status],[shop_cat_ids],[weight],[volume_weight],[invoice_type],[pricing_mode],[sales_model],[freight_id],[goods_moq],[Keywords],[publish_time],[onsale],[ontime],[viewnum],[goods_unit],[siteid],[brandid],[catidlist],[goods_barcode]) VALUES('".$goods_data['store_id']."','".$goods_data['catid']."','".$goods_data['czy']."','".$goods_data['huohao']."','".$goods_data['pic1']."','".$goods_data['name']."','".$goods_data['content']."',convert(money,'".$goods_data['price1']."'),convert(money,'".$goods_data['price2']."'),convert(money,'".$goods_data['price3']."'),'".$goods_data['kucun']."','".$goods_data['Descriptions']."','".$goods_data['status']."','".$goods_data['shop_cat_ids']."',convert(money,'".$goods_data['weight']."'),convert(money,'".$goods_data['volume_weight']."'),'".$goods_data['invoice_type']."','".$goods_data['pricing_mode']."','".$goods_data['sales_model']."','".$goods_data['freight_id']."','".$goods_data['goods_moq']."','".$goods_data['Keywords']."','".$goods_data['publish_time']."','".$goods_data['onsale']."','".$goods_data['ontime']."','".$goods_data['viewnum']."','".$goods_data['goods_unit']."','1','".$input->brand_id."','".$catidlist."','".$goods_data['goods_barcode']."')";
		$goodsres = DB::insert($sql);
		$goods_id = DB::select("select top 1 id from product where store_id='".session("loginstore")->id."' order by publish_time desc");
		if(!$goodsres){
			$returndata = [
				'code' => 1,
				'data' => '',
				'msg' => '添加商品失败'
			];
			return json_encode($returndata);
			die();
		}


		foreach($input->sku_list as $k=>$v){
			$spec_id = '';
			$spec_value ='';
			foreach($v->specs as $a => $b){
				$spec_id .= $b->attr_id.",";
				$spec_value .= $b->attr_vname.",";
			}
			$data = [
				'goods_id' => $goods_id[0]->id,
				'spec_id' => substr($spec_id, 0, strlen($spec_id)-1),
				'spec_value' => iconv('UTF-8','GBK',substr($spec_value, 0, strlen($spec_value)-1)),
				'spec_marketprice' => $v->market_price,
				'spec_storeprice' => $v->goods_price,
				'spec_stock' => $v->goods_number,
				'spec_sn' => isset($v->goods_sn)?$v->goods_sn:"LV".date('Ymd') . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT),
				'goods_barcode' => isset($v->goods_barcode)??0,
				'warn_number' => $v->warn_number??0
			];
			$specres = DB::table('goods_spec_value')->insert($data);
			if(!$goodsres){
				$returndata = [
					'code' => 1,
					'data' => '',
					'msg' => '添加商品规格失败',
				];
				return json_encode($returndata);
				die();
			}
		}
		$returndata = [
			'code' => 0,
			'data' => $goods_id[0]->id,
			'msg' => '添加商品成功'
		];
		return json_encode($returndata);
		die();

	}

	//修改商品
	public function edit($id){
		$goods = DB::table('product')->where('id', '=', $id)->first();
		foreach($goods as $i => $o){
			$goods->$i = iconv('GBK','UTF-8',$o);
		}
		$category = DB::table('category')->where('id','=',$goods->catid)->first();
		$pcategory = DB::table('category')->where('id','=',$category->ParentID)->first();
		$ppcategory = DB::table('category')->where('id','=',$pcategory->ParentID)->first();
		$categorynamestr = [
			'id' => $id,
			'cat_id' => $goods->catid,
			'category' => iconv('GBK','UTF-8',$category->category),
			'pcategory' => iconv('GBK','UTF-8',$pcategory->category),
			'ppcategory' => iconv('GBK','UTF-8',$ppcategory->category)
		];
		//规格
		$goodsspec = DB::table('goods_spec')->get();
		foreach($goodsspec as $k=>$v){
			$goodsspec[$k]->spec_name = iconv('GBK','UTF-8',$v->spec_name);
			$goodsspec[$k]->spec_value = iconv('GBK','UTF-8',$v->spec_value);
			$goodsspec[$k]->attr_remark = iconv('GBK','UTF-8',$v->attr_remark);
			$goodsspec[$k]->spec_value = (object)explode(',', $v->spec_value);
		}

		//选中规格
		$goods_spec_value = DB::table('goods_spec_value')->where('goods_id','=',$goods->id)->get();
		foreach($goods_spec_value as $a => $b){
			$goods_spec_value[$a]->spec_value = iconv('GBK','UTF-8',$b->spec_value);
		}
		$speccheck = [];

		$specvalche = [];
		foreach($goods_spec_value as $ke=>$va){
			array_push($speccheck, explode(',', $va->spec_id));
			array_push($specvalche, explode(',', $va->spec_value));
		}

		foreach($goodsspec as $key => $val){
			$goodsspec[$key]->is_select = '';
			foreach($speccheck as $ka => $ve){
				if(in_array($val->id,$ve)){
					$goodsspec[$key]->is_select = '1';
				}else{
					$goodsspec[$key]->is_select = '0';
				}
			}
			foreach($specvalche as $kq => $vq){
				$aa = array_intersect_assoc((array)$val->spec_value,$vq);
				$goodsspec[$key]->checkval = $aa;
			}
			$goodsspec[$key]->newspec_value = [];
			
			foreach($val->spec_value as $d => $f){
				if(count($specvalche)>0){
					foreach($specvalche as $u => $i){
						if(in_array($f,$i)){
							array_push($goodsspec[$key]->newspec_value, ['name'=>$f,'check'=>'1']);
						}else{
							array_push($goodsspec[$key]->newspec_value, ['name'=>$f,'check'=>'0']);
						}
					}
				}else{
					array_push($goodsspec[$key]->newspec_value, ['name'=>$f,'check'=>'0']);
					//$goodsspec[$key]->newspec_value = $val->spec_value
				}
			}
		}

		//运费
		$freight = DB::table('delivery')->get();
		foreach($freight as $a => $b){
			$freight[$a]->title = iconv('GBK','UTF-8',$b->title);
		}
		//规格
		$newguige = [];
		foreach($goods_spec_value as $p => $l){
			$hh = [
				'checked' => 'true',
				'goods_barcode' => $l->goods_barcode,
				'goods_number' => $l->spec_stock,
				'goods_price' => $l->spec_storeprice,
				'goods_sn' => $l->spec_sn,
				'market_price' => $l->spec_marketprice,
				'mobile_price' => '0.00',
				'warn_number' => '1',
				'goods_stockcode' => '',
				'goods_weight' => '',
				'goods_volume' => ''
			];
			$keystr = str_replace(',', '|', $l->spec_value);
			$newguige[$keystr] = $hh;
		}
		//单位
		$goods_unit = DB::table('goods_unit')->get();
		foreach($goods_unit as $a => $b){
			$goods_unit[$a]->unit = iconv('GBK','UTF-8',$b->unit);
		}
		// 品牌
		//$brand = DB::table('brand')->where('catid','=',$id)->get();
		$brand = DB::table('brand')->where('catid','=',$id)->get();
		$brandone = DB::table('brand')->where('catidlist','like','%|'.$id.'|%')->get();
		$brand = $brand->merge($brandone);
		$brandtwo = DB::table('brand')->where('catidlist','like','%|'.$category->id.'|%')->get();
		$brand = $brand->merge($brandtwo);
		$brandthree = DB::table('brand')->where('catidlist','like','%|'.$category->ParentID.'|%')->get();
		$brand = $brand->merge($brandtwo);
		$brandfour = DB::table('brand')->where('catidlist','like','%|'.$pcategory->ParentID.'|%')->get();
		$brand = $brand->merge($brandfour);
		$brand = $brand->toArray();
		foreach($brand as $key => $val){
			if($key>0 && $brand[($key-1)]->id == $val->id){
				unset($brand[($key-1)]);
			}
		}
		$brand = array_values($brand);
		foreach($brand as $a => $b){
			$brand[$a]->brand = iconv('GBK','UTF-8',$b->brand);
		}
		foreach ($goodsspec as $key => $value) {
			if($value->is_select == 1){
				$goods->goods_sn_status = 1;
			}else{
				$goods->goods_sn_status = 0;
			}
		}

		return view('goods.edit',compact('goodsspec','goodsspec'))->with('categorynamestr', $categorynamestr)->with(compact('freight', 'freight'))->with('goods', $goods)->with('goods_spec_value', $goods_spec_value)->with('jsonstr', json_encode($newguige))->with(compact('goods_unit','goods_unit'))->with(compact('brand','brand'))->with('position','goods_edit');
	}

	public function doedit(){
		$id = Input::get('id');
		if($id==null){
			return view('error.404');
		}
		$input = Input::getContent();
		$input = json_decode($input);
		//商品表所需字段
		if($input->goods_image!==null && strpos($input->goods_image,env('APP_URL'))!==false){
			$input->goods_image = $input->goods_image;
		}else{
			$input->goods_image = env('APP_URL').$input->goods_image;
		}
		$goods_data = [
			'store_id' => session("loginstore")->id??0,
			'catid' => $input->cat_id??0,
			'czy' => session("loginstore")->user_id??0,
			'huohao' => $input->goods_sn==null??date('Ymd') . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT),
			//'goods_qrcode' => base64_encode(QRCode::text("https://www.baidu.com")->png()),
			'pic1' => $input->goods_image??0,
			'name' => iconv('UTF-8','GBK',$input->GoodsModel->goods_name)??0,
			'content' => iconv('UTF-8','GBK',$input->GoodsModel->pc_desc)??0,
			'price1' => $input->market_price??0,
			'price2' => $input->goods_price??0,
			'price3' => $input->cost_price??0,
			'kucun' => $input->goods_number??0,
			'Descriptions' => iconv('UTF-8','GBK',$input->goods_subname),
			'status' => '6',
			'shop_cat_ids' => $input->shop_cat_ids??0,
			'weight' => $input->goods_weight??0,
			'volume_weight' => $input->goods_volume??0,
			'invoice_type' =>  $input->GoodsModel->invoice_type??0,
			'pricing_mode' => $input->pricing_mode??0,
			'sales_model' => $input->sales_model??0,
			'freight_id' => $input->freight_id??0,
			'goods_moq' => $input->GoodsModel->goods_moq,
			'Keywords' => iconv('UTF-8','GBK',$input->keywords),
			'publish_time' => time(),
			'onsale' => $input->GoodsModel->is_show==1?0:1,
			'goods_unit' => $input->GoodsModel->goods_unit,
			'goods_barcode' => $input->goods_barcode??0
		];
		
		$sql ="UPDATE [product] SET [store_id] = '".$goods_data['store_id']."',[catid] = '".$goods_data['catid']."',[czy] = '".$goods_data['czy']."',[huohao] = '".$goods_data['huohao']."',[pic1] = '".$goods_data['pic1']."',[name] = '".$goods_data['name']."',[content] = '".$goods_data['content']."',[price1] = convert(money,'".$goods_data['price1']."'),[price2] = convert(money,'".$goods_data['price2']."'),[price3] = convert(money,'".$goods_data['price3']."'),[kucun] = '".$goods_data['kucun']."',[Descriptions] = '".$goods_data['Descriptions']."',[status] = '".$goods_data['status']."',[shop_cat_ids] = '".$goods_data['shop_cat_ids']."',[weight] = convert(money,'".$goods_data['weight']."'),[volume_weight] =convert(money,'".$goods_data['volume_weight']."'),[invoice_type] = '".$goods_data['invoice_type']."',[pricing_mode] = '".$goods_data['pricing_mode']."',[sales_model] = '".$goods_data['sales_model']."',[freight_id] = '".$goods_data['freight_id']."',[goods_moq] = '".$goods_data['goods_moq']."',[Keywords] = '".$goods_data['Keywords']."',[publish_time] = '".$goods_data['publish_time']."',[onsale] = '".$goods_data['onsale']."',[goods_unit] = '".$goods_data['goods_unit']."',[goods_barcode]='".$goods_data['goods_barcode']."',[brandid]='".$input->brand_id."' WHERE [id]=".$id;
		$goodsres = DB::update($sql);

		//$goodsres = DB::table('product')->where('id','=',$id)->update($goods_data);
		if(!$goodsres){
			$returndata = [
				'code' => 1,
				'data' => '',
				'msg' => '修改商品失败'
			];
			return json_encode($returndata);
			die();
		}
		if(count($input->sku_list)>0){
			DB::table('goods_spec_value')->where('goods_id', '=', $id)->delete();
			foreach($input->sku_list as $k=>$v){
				$spec_id = '';
				$spec_value ='';
				foreach($v->specs as $a => $b){
					$spec_id .= $b->attr_id.",";
					$spec_value .= $b->attr_vname.",";
				}
				$data = [
					'goods_id' => $id,
					'spec_id' => substr($spec_id, 0, strlen($spec_id)-1),
					'spec_value' => iconv('UTF-8','GBK',substr($spec_value, 0, strlen($spec_value)-1)),
					'spec_marketprice' => $v->market_price,
					'spec_storeprice' => $v->goods_price,
					'spec_stock' => $v->goods_number,
					'spec_sn' => isset($v->goods_sn)??"LV".date('Ymd') . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT),
					'goods_barcode' => isset($v->goods_barcode)??0,
					'warn_number' => $v->warn_number??0

				];
				$specres = DB::table('goods_spec_value')->insert($data);
				if(!$goodsres){
					$returndata = [
						'code' => 1,
						'data' => '',
						'msg' => '修改商品规格失败',
					];
					return json_encode($returndata);
					die();
				}
			}
		}
		$returndata = [
			'code' => 0,
			'data' => $goodsres,
			'msg' => '修改商品成功'
		];
		return json_encode($returndata);
		die();
	}

	//删除商品
	public function delete(){
		$ids = Input::all()['ids'];
		$res = DB::table('product')->where('id', '=', $ids)->update(['status'=>'0','onsale'=>'1']);
		$res2 = DB::table('goods_spec_value')->where('goods_id', '=', $ids)->delete();
		if($res && $res2){
			return json_encode(['code'=>'0', 'data'=>'', 'message'=>'删除成功']);
		}else{
			return json_encode(['code'=>'0', 'data'=>'', 'message'=>'删除失败']);
		}
	}
	
	public function addimages(){
		$goods_id = Input::get('id');
		return view('goods.addimages')->with('id',$goods_id)->with('position','goods-publish');
	}

	public function editimages(){
		$goodsimg = '';
		$goodsimgarr = Input::post('goods_images')['default'];
		foreach($goodsimgarr as $a => $b){
			$goodsimg .= $b['path'].",";
		}
		$images = substr($goodsimg, 0 ,strlen($goodsimg)-1);
		$count = count($goodsimgarr);
		$sqldata = [];
		for($i=0;$i<$count;$i++){
			$sqldata['pic'.($i+2)] = env('APP_URL').$goodsimgarr[$i]['path'];
		}
		$goods_id = Input::get('id');
		$res = DB::update("UPDATE [product]
SET [pic2] = '".$sqldata['pic2']."',
 [pic3] = '".$sqldata['pic3']."',
 [pic4] = '".$sqldata['pic4']."',
 [pic5] = '".$sqldata['pic5']."',
 [pic6] = '".$sqldata['pic6']."'
WHERE [id]=".$goods_id);
		//$res = DB::table('product')->where('id','=',$goods_id)->update($sqldata);
		if($res){
			return json_encode(['code'=>0,'message'=>'修改商品图片成功']);
		}else{
			return json_encode(['code'=>1,'message'=>'修改商品图片失败']);
		}
	}

	//ajax 获取下级导航
	public function catelist(){
		$id = Input::all()['id'];
		$children = DB::table('category')
		            ->select('id','category','ParentID')
		            ->where('ParentID','=',$id)
		            ->get();
		//转编码		
		foreach($children as $key => $val){			
			$children[$key]->category = iconv('GBK','UTF-8',$val->category);
		}
		if(count($children)<=0){
			return json_encode(['code'=>'-1','data'=>'','message'=>'没有下级导航了，请联系管理员添加']);
			//return '没有下级导航了';
		}
		$str = '';
		//判断等级
		$level = '1';
		if($children[0]->ParentID != '0'){
			$level = $level+1;
			$parent = DB::table('category')->where('id','=',$children[0]->ParentID)->first();
			if($parent->ParentID !='0'){
				$level = $level+1;
				$pparent = DB::table('category')->where('id','=',$parent->ParentID)->first();
				if($pparent->ParentID!='0'){
					$level = $level+1;
				}
			}
		}
		$level = $level-1;
		if($level == '3'){
			$bb = '0';
		}else{
			$bb = '1';
		}
		foreach ($children as $key => $value) {
			$str .= '<li><ul class=""><li><a href="javascript:void(0);" class="category-name" data-id="'.$value->id.'" data-type="'.$level.'" data-is-parent="'.$bb.'" data-search="'.$value->category.'" data-level="'.$level.'"><i class="fa fa-angle-right"></i>'.$value->category.'</a></li></ul></li>';
		}
		return $str;
	}
	public function newimageselector(){

		$page = Input::get('page')['cur_page']??1;
		$size = Input::get('size')??1;


		//
		$count = DB::table('imageslist')->count();
		$imageslist = DB::select('select top 10 * from imageslist where id not in(select top '.(($page-1)*10).' id from imageslist) order by add_time desc');
		//$imageslist = DB::table('imageslist')->offset(($page-1)*10)->orderBy('add_time','desc')->limit(10)->get();
		//$imageslistsql = DB::table('imageslist')->offset(($page-1)*10)->orderBy('add_time','desc')->limit(10)->toSql();
		//print_r($imageslistsql);
		$pagestr = $count/10;
		if($count%10 > 0){
			$pagestr = $pagestr+1;
		}
		$offset = (($page-1)*10);
		
		if(Input::get('output')==='0'){
			$html = view('goods.images')->with('page',$page)->with('size', $size)->with(compact('imageslist', 'imageslist'))->with('offset', $offset)->with('pagestr', $pagestr)->with('count', $count)->render();
		}else{
			$html  = view('goods.imagesone')->with('page',$page)->with('size', $size)->with(compact('imageslist', 'imageslist'))->with('offset', $offset)->with('pagestr', $pagestr)->with('count', $count)->render();
		}
		
		return json_encode(['code'=>0,'data'=>$html,'message'=>'']);
	}

	
	public function imagegallery(){
		$input = Input::file();
		if($input == null){
			return json_encode(['code'=>'1','data'=>'','message'=>'没有选取文件']);
		}

		$images = [];
		foreach($input as $key => $val){
			foreach($val as $a=>$b){
				$ext = $b->getClientOriginalExtension();

				$realPath = $b->getRealPath();
				

				$filename = date('YmdHis') . '-' . uniqid() . '.' . $ext;
				$bool = Storage::put($filename, file_get_contents($realPath));
				$images[$a] = Storage::url($filename);

				$exif = getimagesize(env('APP_URL').$images[$a]);
				

				if(!$exif){
					return json_encode(['code'=>1,'data'=>'','message'=>'文件不受支持']);
				}
				$sqldata = [
					'image_url' => $images[$a],
					'add_time' => time(),
					'size' => $exif['bits'],
					'width' => $exif['0'],
					'height' => $exif['1'],
					'type' => $exif['mime'],
					'title' => explode('.', $filename)[0],
					'dir_id' => '135'
				];
				$sqlres = DB::table('imageslist')->insert($sqldata);
				if(!$sqlres){
					return json_encode(['code'=>1, 'message'=>'添加数据库失败']);
				}
				
				
			}
		}
		for($a=0;$a<count($images);$a++){
			$returndata[$a] = [
				'dir_id' => '135',
				'height' => '80',
				'width' => '80',
				'size' => '1781',
				'name' => session("loginstore")->id,
				'extension' => explode('.',$images[$a])[1],
				'sort' => '255',
				'add_time' => time(),
				'path' => $images[$a],
				'file_name' => explode('.',$images[$a])[0],
				'dirname' => '/strong/',
				'img_id' => '1',
				'host' => env("APP_URL"),
				'url' => env("APP_URL").$images[$a],
			];
		}

		$data = [
			'code' => '0',
			'data' => $returndata,
			'message' => '上传图片成功'
		];
		return json_encode($data);
	}

	//添加商品成功
	public function success(){
		$goods_id = Input::get('id');
		return view('goods.success')->with('goods_id',$goods_id)->with('position','goods_edit');
	}

	//添加规格
	public function addspec(){
		$data = [
			'code' => '0',
			'data' => file_get_contents(env('APP_URL').'/static/html/addspec.html').'<input type="hidden" name="_csrf" value="'.csrf_token().'"',
			'message'=>''
		];
		return json_encode($data);
	}
	public function doaddspec(){
		$input = Input::getContent();
		$input = json_decode($input);

		$insertdata = [
			'spec_name' => iconv('UTF-8','GBK',$input->attr_name),
			'spec_value' => iconv('UTF-8','GBK',substr($input->attr_vname, 0, strlen($input->attr_vname)-1)),
			'sort' => $input->attr_sort
		];
		//值列表
		$listres = explode(',', $insertdata['spec_value']);


		$res = DB::table('goods_spec')->insert($insertdata);
		$html = '<div class="simple-form-field goods-spec-item drop-item" data-spec-id="'.$res.'">
					<input type="hidden" name="spec_alias[#key#][attr_id]" value="'.$res.'" />
					<div class="form-group spec-id-'.$res.'" data-spec-id="'.$res.'" data-spec-name="'.$input->attr_name.'">
						<!-- 规格名称 -->
						<label class="col-sm-2 control-label spec-name cur-p" data-spec-id="'.$res.'">
						<input type="text" id="spec_name_'.$res.'" name="spec_alias[#key#][attr_name]" class="form-control form-control-xs text-r w70 spec-name" value="'.$input->attr_name.'" data-spec-id="'.$res.'" data-rule-required="true" data-msg="规格名称不能为空!">：
						</label>
						<!-- 规格值列表 -->
						<div class="col-sm-9 spec-values" data-spec-id="'.$res.'">';
	

		for($i=0;$i<count($listres);$i++){

			$html .= '<label class="control-label text-l cur-p w100" title="'.$input->attr_name.'">';
			$html .= '<input type="checkbox" value="'.$listres[$i].'" data-attr-id="'.$res.'" data-vid="'.$listres[$i].'" data-vname="'.$listres[$i].'" class="spec-value">'.$listres[$i].'&nbsp; &nbsp;';
			$html .= '</label>';
			
		}
	/*<label class="control-label cur-p">
	<input type="checkbox" value="1" class="spec-value spec-other-value" data-attr-id="1159">
	<input type="text" name="other_spec[]" value="" placeholder="其他" maxlength="15" class="form-control form-control-xs w80 spec-other-text" data-rule-uniqueOtherSpecName="true">
	</label>*/



	$html .= '</div></div></div>';

		if($res){
			$data = [
				'attr_id' => $res,
				'attr_name' => $input->attr_name,
				'code' => '0',
				'data' => $html,
				'message' => '操作成功'
			];
		}else{
			$data = [];
		}
		return response()->json($data);
	}
}