<?php
//-----------------------------------------------------------------------------------------
//位置：店铺分类列表
//作者：让时光流逝
//时间：2018年10月31日
//-----------------------------------------------------------------------------------------
namespace App\Http\Controllers\Store;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;

class CategoryController extends Controller
{
	public function index(){
		$count = DB::table('store_cate')
						->count();
		/*$catelist = DB::select(
			'SELECT	category.id,category.cate_name,category.pid,category.is_effect,category.sort,(SELECT count(*) FROM product goods	WHERE category.id in(goods.shop_cat_ids)) as count FROM	store_cate category ORDER BY category.sort DESC,category.publish_time DESC');*/
		$catelist = DB::select(
			"SELECT	category.id,category.cate_name,category.pid,category.is_effect,category.sort,(SELECT count(*)	FROM product goods	WHERE category.id in(goods.shop_cat_ids)) as count,CAST(category.path as VARCHAR(10)) + '-' + CAST(category.id as VARCHAR(10)) as path FROM	store_cate category where category.store_id='".session('loginstore')->id."' ORDER BY path,category.sort DESC,category.publish_time DESC");
		foreach($catelist as $key => $val){			
			$catelist[$key]->cate_name = iconv('GBK','UTF-8',$val->cate_name);
		}
		return view('store.catelist',compact('catelist','catelist'))->with('count',$count)->with('position','goods-cate');
	}

	//发布商品分类
	public function publish(){
		//列出所有分类
		$catelist = DB::select(
			'SELECT	id,cate_name,pid,is_effect,sort FROM store_cate where store_id='.session('loginstore')->id.'	ORDER BY sort DESC,publish_time DESC');
		foreach($catelist as $key => $val){			
			$catelist[$key]->cate_name = iconv('GBK','UTF-8',$val->cate_name);
		}
		return view('store.cateadd',compact('catelist','catelist'))->with('position','goods-cate');
	}
	public function dopublish(){
		$input = Input::all();
		//$input['cate_name'] = iconv('GBK','UTF-8',$input['cate_name']);
		$encoding = mb_detect_encoding($input['cate_name'], mb_detect_order(), false);
		
	
		$parent = DB::table('store_cate')->select('path')->where('id','=',$input['parent_id'])->first();
				
		$data = [
			'cate_name' => $input['cate_name'],
			'pid' => $input['parent_id'],
			'is_effect' => 1,
			'sort' => $input['cat_sort'],
			'publish_time' => time(),
			'store_id'=>session('loginstore')->id			
		];
		$data['cate_name'] = iconv('UTF-8','GBK',$data['cate_name']);
		
		if($parent == null){
			$data['path'] = '0-'.$input['parent_id'];
			if($input['parent_id']=='0'){
				$data['path'] = '0';
			}
		}else{
			$data['path'] = $parent->path.'-'.$input['parent_id'];
		}
		$res = DB::table('store_cate')->insert($data);
		if($res){
			$msg = [
			'code' => '0',
			'data' => '0',
			'message' => '1',
			];
			return json_encode($msg);
		}
	}
	//修改分类
	//发布商品分类
	public function edit($id){
		//列出所有分类
		//$id = Input::get('id');
		$cateinfo = DB::table('store_cate')->where('id','=',$id)->first();
		$catelist = DB::select(
			"SELECT	id,cate_name,pid,is_effect,sort FROM store_cate where store_id='".session('loginstore')->id."' ORDER BY sort DESC,publish_time DESC");
		foreach($catelist as $key => $val){			
			$catelist[$key]->cate_name = iconv('GBK','UTF-8',$val->cate_name);
		}
		return view('store.cateedit',compact('cateinfo','cateinfo'))->with(compact('catelist', 'catelist'))->with('position','goods-cate')->with('position','goods-cate');
	}
	public function doedit(){
		$input = Input::all();

		$data = [
			'cate_name' => $input['cate_name'],
			'pid' => $input['parent_id'],
			'is_effect' => $input['is_show'],
			'sort' => $input['cat_sort'],
			'update_time' => time(),
			
		];
		if($input['parent_id']==='0'){
			$data['path'] = '0';
		}else{
			$parent = DB::table('store_cate')->select('path')->where('id','=',$input['parent_id'])->first();
			$data['path'] = $parent->path.'-'.$input['parent_id'];
		}
		$data['cate_name'] = iconv('UTF-8','GBK',$data['cate_name']);
		$res = DB::table('store_cate')->where('id', '=', $input['cat_id'])->update($data);


		if($res){
			$msg = [
				'code' => '0',
				'data' => '0',
				'message' => '修改成功',
			];
			return json_encode($msg);
		}else{
			$msg = [
			'code' => '1',
			'data' => '0',
			'message' => '修改失败',
			];
			return json_encode($msg);
		}
	}

	public function del(){
		$id = Input::all();
		$id = $id['id'];
		//查询自己所有数据
		$our = DB::table('store_cate')->select('path')->where('id', '=', $id)->first();
		//查询三级分类
		$threechil = DB::table('store_cate')->select('id')->where('pid', '=', $id)->first();
		//其它所有子类
		$children = DB::select("SELECT id from store_cate where path LIKE '".$our->path."-".$id."-%'");

		$childrenstr = [];
		array_push($childrenstr, $id);
		if($threechil){
			array_push($childrenstr, $threechil->id);
		}
		if($children){
			foreach($children as $k => $v){
				array_push($childrenstr, $v->id);
			}
		}
		
		if(is_array($childrenstr)){
			$res = DB::table('store_cate')->whereIn('id', $childrenstr)->delete();
		}else{
			$res = DB::table('store_cate')->where('id', $childrenstr)->delete();
		}
		
		if($res){
			return json_encode(['code'=>'0','message'=>'删除成功']);
		}else{
			return json_encode(['code'=>'1','message'=>'删除失败']);
		}
	}

	public function setisshow(){
		$id = Input::all()['id'];
		$cate = DB::table('store_cate')->where('id', '=', $id)->first();
		$arr = [];
		if($cate->is_effect == 0){
			$arr['is_effect'] = 1;
		}else{
			$arr['is_effect'] = 0;
		}
		DB::table('store_cate')->where('id', '=', $id)->update($arr);

		$data = [
			'code' => '0',
			'data' => '0',
			'message' => '1',
			'cat_ids' => [
				$id
			]
		];

		return json_encode($data);
	}
}