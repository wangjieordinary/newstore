<?php
//-----------------------------------------------------------------------------------------
//位置：规格管理列表
//作者：让时光流逝
//时间：2018年11月5日
//-----------------------------------------------------------------------------------------

namespace App\Http\Controllers\Store;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;

class SpecController extends Controller
{
	//规格列表
    public function index(){
    	$speccount = DB::table('goods_spec')->count();
    	$speclist = DB::table("goods_spec")->paginate(10);
		foreach($speclist as $a=>$b){
			$speclist[$a]->spec_name = iconv('GBK','UTF-8',$b->spec_name);
			$speclist[$a]->spec_value = iconv('GBK','UTF-8',$b->spec_value);
			$speclist[$a]->attr_remark = iconv('GBK','UTF-8',$b->attr_remark);
		}
    	return view('spec.index', compact('speclist', 'speclist'))->with('count', $speccount)->with('position','goods-spec');
    }
    //添加规格
    public function add(){
    	return view('spec.add')->with('position','goods-spec');
    }
    public function doadd(){
    	$input = Input::all();
    	$data = json_decode($input['data']);
    	$spec_value = '';
    	foreach($data->attr_values as $k => $v){
    		$spec_value .= $v->attr_vname.",";
    	}
    	$sqldata = [
    		'spec_name' => iconv('UTF-8','GBK',$data->Attribute->attr_name),
    		'spec_value' => iconv('UTF-8','GBK',substr($spec_value, 0, strlen($spec_value)-1)),
    		'attr_remark' => iconv('UTF-8','GBK',$data->Attribute->attr_remark),
    		'sort' => $data->Attribute->attr_sort
    	];
    	$res = DB::table('goods_spec')->insert($sqldata);
    	if($res){
    		return json_encode(['code'=>0, 'data' => url('store/spec/list'), 'message'=>"添加规格成功"]);
    	}else{
    		return json_encode(['code'=>1, 'message'=>"添加规格失败"]);
    	}
    }
    //修改规格
    public function edit(){
    	$id = Input::get('id');
    	$editres = DB::table('goods_spec')->where('id', '=', $id)->first();
		
		$editres->spec_name = iconv('GBK','UTF-8',$editres->spec_name);
		$editres->spec_value = iconv('GBK','UTF-8',$editres->spec_value);
		$editres->attr_remark = iconv('GBK','UTF-8',$editres->attr_remark);

    	$editres->spec_value = explode(',', $editres->spec_value);

    	return view('spec.edit')->with('editres', $editres)->with('position','goods-spec');
    }
    public function doedit(){
    	$input = Input::all();
    	$data = json_decode($input['data']);
    	$spec_value = '';
    	foreach($data->attr_values as $k => $v){
    		$spec_value .= $v->attr_vname.",";
    	}
    	$sqldata = [
    		'spec_name' => iconv('UTF-8','GBK',$data->Attribute->attr_name),
    		'spec_value' => iconv('UTF-8','GBK',substr($spec_value, 0, strlen($spec_value)-1)),
    		'attr_remark' => iconv('UTF-8','GBK',$data->Attribute->attr_remark),
    		'sort' => $data->Attribute->attr_sort
    	];
    	$res = DB::table('goods_spec')->where('id', '=', $data->Attribute->attr_id)->update($sqldata);
    	if($res){
    		return json_encode(['code'=>0, 'data' => url('store/spec/list'), 'message'=>"添加规格成功"]);
    	}else{
    		return json_encode(['code'=>1, 'message'=>"添加规格失败"]);
    	}
    }
    public function del(){
    	$id = Input::all();
		$id = $id['id'];

		$res = DB::table('goods_spec')->where('id','=',$id)->delete();
		if($res){
			return json_encode(['code'=>'0','message'=>'删除成功']);
		}else{
			return json_encode(['code'=>'1','message'=>'删除失败']);
		}
    }
}
