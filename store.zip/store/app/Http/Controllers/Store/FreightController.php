<?php
//-----------------------------------------------------------------------------------------
//位置：快递方式
//作者：让时光流逝
//时间：2018年11月7日
//-----------------------------------------------------------------------------------------

namespace App\Http\Controllers\Store;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;

class FreightController extends Controller
{
    public function index(){
        $count = DB::table('delivery')->count();
    	$data = DB::table('delivery')->paginate(10);
    	foreach($data as $key => $val){
			$data[$key]->title = iconv('GBK','UTF-8',$val->title);
    		$data[$key]->record = DB::table('delivery_desc')->where('pid', '=', $val->id)->get();
			foreach($data[$key]->record as $a => $b){
				$data[$key]->record[$a]->region_names = iconv('GBK','UTF-8',$b->region_names);
			}
    		/*foreach($data[$key]->record as $a => $b){
    			$selfdata = DB::table('sunny_area')->where('id', '=', $val->region_code)->first();
			    $pdata = DB::table('sunny_area')->where('id', '=', $selfdata->pid)->first();
			    $ppdata = DB::table('sunny_area')->where('id', '=', $pdata->pid)->first();
			    if($b->region_codes == null || $b->region_names == null){
			    	($data[$key]->record[$a]->region_codes = 
			    }
			    print_r($b);
			    exit;
    		}*/
    	}

    	return view('freight.index',compact('data', 'data'))->with('count',$count)->with('position','goods-freight');
    }
    public function add(){
    	return view('freight.add')->with('position','goods-freight');
    }
    public function doadd(){
   		$input = Input::all();
   		DB::beginTransaction();
	   	$sqldata = [
	   		'title' => iconv('UTF-8','GBK',$input['freight']['title'])??0,
	   		'region_code' => $input['freight']['region_code']??0,
	   		'is_free' => $input['freight']['is_free']??0,
	   		'valuation' => $input['freight']['valuation']??0,
	   		'limit_sale' => $input['freight']['limit_sale']??0,
	   		'free_set' => $input['freight']['free_set']??0,
	   		'update_time' => time(),
	   		'shop_id' => session('loginstore')->id
	   	];
	   	$freightres = DB::table('delivery')->insert($sqldata);
		$pid = DB::select("select top 1 id from delivery where shop_id='".session('loginstore')->id."' order by update_time desc");
	   	$pid = $pid[0]->id;
		if($freightres){
	   		if(count($input['records'])>0){
	   			foreach($input['records'] as $k => $v){
					
		   			$freightdesc = [
		   				'is_default' => $v['is_default']??0,
		   				'start_num' => $v['start_num']??0,
		   				'start_money' => $v['start_money']??0,
		   				'plus_num' => $v['plus_num']??0,
		   				'plus_money' => $v['plus_money']??0,
		   				'is_cash' => $v['is_cash']??0,
		   				'cash_more' => $v['cash_more']??0,
		   				'region_codes' => $v['region_codes']??0,
		   				'region_names' => isset($v['region_names'])?iconv('UTF-8','GBK',$v['region_names']):'0',
		   				'pid' => $pid
		   			];
		   			$descres = DB::table('delivery_desc')->insert($freightdesc);
		   			if(!$descres){
		   				DB::rollBack();
		   				return json_encode(['code'=>'-1', 'data'=>'', 'message' => "插入规格模板失败"]);
		   			}
		   		}
	   		}
	   		DB::commit();
	   		return json_encode(['code'=>'0', 'data'=>$pid, 'message' => "插入规格模板成功"]);
	   	}else{
	   		DB::rollBack();
	   		return json_encode(['code'=>'-1', 'data'=>'', 'message' => "插入规格模板失败"]);
	   	}
    }

    //修改快递
    public function edit(){
    	$id = Input::get('id');
    	$data = DB::table('delivery')->where('id', '=', $id)->first();
		if($data == null){
			return back()->withErrors(['操作有误！']);
		}
		$data->title = iconv('GBK','UTF-8',$data->title);

    	$data->record = DB::table('delivery_desc')->where('pid', '=', $id)->get();
    	$data->default = [];
    	foreach ($data->record as $key => $value) {
			$data->record[$key]->region_names = iconv('GBK','UTF-8',$data->record[$key]->region_names);
    		if($value->is_default == '1'){
    			$data->default = $value;
    			unset($data->record[$key]);
    		}
    	}

    	return view('freight.edit',compact('data','data'))->with('position','goods-freight');
    }
    public function doedit(){
    	$input = Input::all();
    	$id = Input::get('id');
   		DB::beginTransaction();
	   	$sqldata = [
	   		'title' => iconv('UTF-8','GBK',$input['freight']['title'])??0,
	   		'region_code' => $input['freight']['region_code']??0,
	   		'is_free' => $input['freight']['is_free']??0,
	   		'valuation' => $input['freight']['valuation']??0,
	   		'limit_sale' => $input['freight']['limit_sale']??0,
	   		'free_set' => $input['freight']['free_set']??0,
	   		'update_time' => time(),
	   		'shop_id' => session('loginstore')->id
	   	];
	   	$freightres = DB::table('delivery')->where('id', '=', $id)->update($sqldata);
	   	if($freightres){
	   		if($input['records']){
		   		DB::table('delivery_desc')->where('pid', '=', $id)->delete();
	   			foreach($input['records'] as $k => $v){
		   			$freightdesc = [
		   				'is_default' => $v['is_default']??0,
		   				'start_num' => $v['start_num']??0,
		   				'start_money' => $v['start_money']??0,
		   				'plus_num' => $v['plus_num']??0,
		   				'plus_money' => $v['plus_money']??0,
		   				'is_cash' => $v['is_cash']??0,
		   				'cash_more' => $v['cash_more']??0,
		   				'region_codes' => $v['region_codes']??0,
		   				'region_names' => isset($v['region_names'])?iconv('UTF-8','GBK',$v['region_names']):'0',
		   				'pid' => $id,
		   			];
		   			$descres = DB::table('delivery_desc')->insert($freightdesc);
		   			if(!$descres){
		   				DB::rollBack();
		   				return json_encode(['code'=>'-1', 'data'=>'', 'message' => "修改失败"]);
		   			}
		   		}
	   		}
	   		DB::commit();
	   		return json_encode(['code'=>'0', 'data'=>$id, 'message' => "修改成功"]);
	   	}else{
	   		DB::rollBack();
	   		return json_encode(['code'=>'-1', 'data'=>'', 'message' => "修改失败"]);
	   	}
    }

    //店铺统一运费
    public function default(){
    	return view('freight.default')->with('position','goods-fregith');
    }

    //获取地区
    public function regionlist(){
    	if(Input::get('parent_code') == null){
    		$data = DB::table('sunny_area')->where('level','=','1')->get();
    	}else{
    		$data = DB::table('sunny_area')->where('pid', '=', Input::get('parent_code'))->get();
    	}
    	$region = [];
    	foreach($data as $key => $val){
    		$region[0][$key]['region_id'] = $val->id;
    		$region[0][$key]['region_name'] = iconv('GBK','UTF-8',$val->name);
    		$region[0][$key]['region_code'] = $val->id;
    		$region[0][$key]['parent_code'] = '0';
    		$region[0][$key]['region_type'] = '';
    		$region[0][$key]['center'] = '';
    		$region[0][$key]['city_code'] = '';
    		$region[0][$key]['sort'] = '255';
    		$region[0][$key]['level'] = $val->level;
    		$region[0][$key]['is_enable'] = '1';
    		$region[0][$key]['is_scope'] = '1';
    	}
    	$region[0][0]['is_scope'] = '0';
    	$level_names = [
    		'','省','市','区/县', '镇'
    	];
    	if(Input::get('region_code')!==null){
    		$selfdata = DB::table('sunny_area')->where('id', '=', Input::get('region_code'))->first();
    		$pdata = DB::table('sunny_area')->where('id', '=', $selfdata->pid)->first();
    		$ppdata = DB::table('sunny_area')->where('id', '=', $pdata->pid)->first();

    		$region[1][0]['region_id'] = $pdata->id;
    		$region[1][0]['region_name'] = iconv('GBK','UTF-8',$pdata->name);
    		$region[1][0]['region_code'] = $pdata->id;
    		$region[1][0]['parent_code'] = '0';
    		$region[1][0]['region_type'] = '';
    		$region[1][0]['center'] = '';
    		$region[1][0]['city_code'] = '';
    		$region[1][0]['sort'] = '255';
    		$region[1][0]['level'] = $pdata->level;
    		$region[1][0]['is_enable'] = '1';
    		$region[1][0]['is_scope'] = '1';
    		$region[1][0]['is_scope'] = '0';

    		$data = DB::table('sunny_area')->where('pid','=',$pdata->id)->get();
    		foreach($data as $key => $val){
	    		$region[2][$key]['region_id'] = $val->id;
	    		$region[2][$key]['region_name'] = iconv('GBK','UTF-8',$val->name);
	    		$region[2][$key]['region_code'] = $val->id;
	    		$region[2][$key]['parent_code'] = '0';
	    		$region[2][$key]['region_type'] = '';
	    		$region[2][$key]['center'] = '';
	    		$region[2][$key]['city_code'] = '';
	    		$region[2][$key]['sort'] = '255';
	    		$region[2][$key]['level'] = $val->level;
	    		$region[2][$key]['is_enable'] = '1';
	    		$region[2][$key]['is_scope'] = '1';
    			$region[2][$key]['is_scope'] = '0';
	    	}


			
    		$region_names = [
    			$selfdata->id => iconv('GBK','UTF-8',$selfdata->name),
    			$pdata->id => iconv('GBK','UTF-8',$pdata->name),
    		];
			if($ppdata!==null){
				$region_names[$ppdata->id] = iconv('GBK','UTF-8',$ppdata->name);
			}
    		return json_encode(['code'=>'0', 'data' => $region, 'level_names' => $level_names, 'message'=>'', 'region_names'=>$region_names]);
    	}else{
    		return json_encode(['code'=>'0', 'data' => $region, 'level_names' => $level_names, 'message'=>'']);
    	}
    	
    }
    //运送到指定地点
    public function regionpicker(){
    	$html = view('freight.regionpicker')->render();
    	return json_encode(['code'=>'0','data'=>$html,'message'=>'']);
    }
    public function saleregionlist(){
    	if(Input::get('parent_code') == null){
    		$data = DB::table('sunny_area')->where('level','=','1')->get();
    	}else{
    		
    		$data = DB::table('sunny_area')->where('pid', '=', Input::get('parent_code'))->get();
    	}
    	$region = [];
    	foreach($data as $key => $val){
    		$region[0][$key]['region_id'] = $val->id;
    		$region[0][$key]['region_name'] = iconv('GBK','UTF-8',$val->name);
    		$region[0][$key]['region_code'] = $val->id;
    		$region[0][$key]['parent_code'] = '0';
    		$region[0][$key]['region_type'] = '';
    		$region[0][$key]['center'] = '';
    		$region[0][$key]['city_code'] = '';
    		$region[0][$key]['sort'] = '255';
    		$region[0][$key]['level'] = $val->level;
    		$region[0][$key]['is_enable'] = '1';
    		$region[0][$key]['is_scope'] = '1';
    	}
    	$region[0][0]['is_scope'] = '0';
    	$level_names = [
    		'','省','市','区/县', '镇', '街道/村'
    	];
    	return json_encode(['code'=>'0', 'data' => $region, 'level_names' => $level_names, 'message'=>'']);
    }
}
