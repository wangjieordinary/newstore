	<link rel="stylesheet" href="/static/css/styles.css?v=20181020"/>
	<div id="1541574822gC385V" class="plus-album image-selector-container">
		<div class="tab-content">
			<!-- 分组 -->
			<div class="category-list-region pull-left">
				<ul class="category-list dir-list" data-dir_id="135">
					<li id="dir_135" class="category-item selected" data-dir_id="135" title="默认相册">
						默认相册
						<span></span>
					</li>
					<!-- <li id="dir_138" class="category-item " data-dir_id="138" title="默认手机相册">
						默认手机相册
						<span></span>
					</li>
					<li id="dir_137" class="category-item " data-dir_id="137" title="默认广告相册">
						默认广告相册
						<span></span>
					</li>
					<li id="dir_136" class="category-item " data-dir_id="136" title="默认商品详情相册">
						默认商品详情相册
						<span></span>
					</li>
					<li id="dir_134" class="category-item " data-dir_id="134" title="默认商品相册">
						默认商品相册
						<span></span>
					</li> -->
				</ul>
			</div>
			<!-- 图片列表 -->
			<div class="attachment-list-region">
				<div class="search-container">
					<span class="pull-left">
						<select id="sort_name" class="form-control form-control-xs m-l-2 w150">
							<option value="add_time-desc">按上传时间从晚到早</option>
							<option value="add_time-asc">按上传时间从早到晚</option>
							<option value="size-asc">按图片从小到大</option>
							<option value="size-desc">按图片从大到小</option>
							<option value="name-asc">按图片名升序</option>
							<option value="name-desc">按图片名降序</option>
						</select>
					</span>
					<span class="pull-right">
						<input type="text" id="image_name" class="form-control form-control-sm w150"  placeholder="请输入图片名称" />
						<a class="btn btn-primary btn-sm image-search">
							<i class="fa fa-search m-l-0"></i>
							搜索
						</a>
						<a class="btn btn-primary btn-sm image-selector-upload">
							<i class="fa fa-upload m-l-0"></i>
							上传图片
						</a>
					</span>
				</div>
				<div id="tablelist" class="attachment-box">
					<ul class="image-list">
						<?php $__currentLoopData = $imageslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageslist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<!--点击添加selected样式，则为已选中状态-->
						<li class="image-item" title="上传时间：<?php echo e(date('Y-m-d H:i:s', $imageslist->add_time)); ?>" data-id="<?php echo e($imageslist->id); ?>">
							<img class="image-box" src="<?php echo e($imageslist->image_url); ?>" data-path="<?php echo e($imageslist->image_url); ?>" data-url="<?php echo e($imageslist->image_url); ?>" data-width="<?php echo e($imageslist->width); ?>" data-height="<?php echo e($imageslist->height); ?>" />
							<div class="image-meta"><?php echo e($imageslist->width); ?>*<?php echo e($imageslist->height); ?></div>
							<div class="image-title"><?php echo e($imageslist->title); ?></div>
							<div class="attachment-selected">
								<i class="fa fa-check"></i>
							</div>
						</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
					<!--分页-->
					<div class="text-r page-box">
						<div id="pagination">
							<script data-page-json="true" type="text">{"page_key":"page","page_id":"pagination","default_page_size":10,"cur_page":<?php echo e($page); ?>,"page_size":10,"page_size_list":[10,50,500,1000],"record_count":<?php echo e($count); ?>,"page_count":1,"offset":<?php echo e($offset); ?>,"url":null,"sql":null}</script>
							<ul class="pagination">
								<li class="disabled" style="display: none;">
									<a class="fa fa-angle-double-left" data-go-page="1" title="第一页"></a>
								</li>
								<li class="disabled">
									<a class="fa fa-angle-left" title="上一页"></a>
								</li>
								<!--   -->
								<?php for($i=1;$i<=$pagestr;$i++): ?>
									<?php if($page==$i): ?>{
										<li class="active">
											<a data-cur-page="<?php echo e($i); ?>"><?php echo e($i); ?></a>
										</li>
									<?php else: ?>
										<li>
										<a href="javascript:void(0);" data-go-page="<?php echo e($i); ?>"><?php echo e($i); ?></a>
										</li>
									<?php endif; ?>
								<?php endfor; ?>
								<li class="disabled"><a class="fa fa-angle-right" title="下一页"></a></li>
								<li class="disabled" style="display: none;">
									<a class="fa fa-angle-double-right" data-go-page="1" title="最后一页"></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!--已选项-->
			<div class="selected-pic-container">
				<div class="selected-pic-title">
					已选择
					<span class="num">
						<span class="image-selector-number">0</span>/<span>1</span>
					</span>
					张图片（拖动可修改插入顺序）
				</div>
				<div class="mod-selected">
					<ul id="dropzone" class="ui-sortable">
						<li class="drop-item mod-img seat">
							<a href="javascript:void(0);">
								<i class="seat-icon">+</i>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<script src="/static/js/jquery-ui.js?v=20180027"></script>
	<script src="/static/js/jquery.tablelist.js?v=20180027"></script>
	<script id="template_1541574822gC385V" type="text"><li data-id="#id#" class="drop-item mod-img"><a href="javascript:void(0);" title="#title#">#image#<span class="pixel">#width#x#height#</span></a><i class="fa fa-times-circle" data-id="#id#"></i></li></script>
	<!--拖拽-->
	<script type="text/javascript">
	var container = $("#1541574822gC385V");
	$(container).find('#dropzone').droppable({
		activeClass: 'active',
		hoverClass: 'hover',
		accept: ":not(.ui-sortable-helper)",
		// Reject clones generated by 
		sortabledrop: function(e, ui) {
			var $el = $('<div class="drop-item">' + ui.draggable.text() + '</div>');
			$el.append($('<a class="delete-btn"></a><fa class="fa fa-times-circle"></fa>').click(function() {
				$(this).parent().detach();
			}));
			$(this).append($el);}}).sortable({
				items: '.drop-item',
				sort: function() {
					// gets added unintentionally by droppable interacting with sortable
					// using connectWithSortable fixes this, but doesn't allow you to customize active/hoverClass options
					$(this).removeClass("active");
				}
			});
			$(container).find(".category-thumb").click(function(event) {
				$(".category-list").removeClass('selected');
				$(this).addClass('selected');
				$(".pic-container").removeClass('list');
			});
			$(container).find(".category-list").click(function(event) {
				$(".category-thumb").removeClass('selected');
				$(this).addClass('selected');
				$(".pic-container").addClass('list');
			});
			var tablelist = null;
			// 选中的图片编号
			var image_list = {};
			var size = "<?php echo e($size); ?>";
			$().ready(function() {
				$(container).parent().css({"border-top": "1px #C1C1C1 solid"});
				var object = {
					values: function() {
						var values = [];
						$(container).find("#dropzone").find(".drop-item").each(function() {
							var id = $(this).data("id");
							if (image_list[id]) {
								values.push(image_list[id]);
							} else {
								values.push(null);
							}
						});
						return values;
					}};
					// 绑定获取图片列表的事件
					$(container).data("object", object);
					// // // // 设置选择图片的数量
					$(container).find(".image-selector-number").html($(container).find(".drop-item").not(".seat").size());
					function changeImage(id, selected) {
						id = id + "";
						var target = $(container).find(".image-item").filter("[data-id='" + id + "']");
						if (selected == false) {
							// 取消选择
							$(target).removeClass("selected");
							var html = '<li class="drop-item mod-img seat">';
							html += '<a href="javascript:void(0);">';
							html += '<i class="seat-icon">+</i>';
							html += '</a>';
							html += '</li>';
							var drop_target = $(container).find("#dropzone").find(".drop-item").filter("[data-id='" + id + "']");
							$(drop_target).replaceWith(html);
							// 删除
							delete image_list[id];
						} else if (selected == true && $(target).size() > 0) {
							// 选中
							if ($(target).hasClass("selected") == false) {
								$(target).addClass("selected");
							}
							var drop_target = $(container).find("#dropzone").find(".drop-item").filter("[data-id='" + id + "']");
							// 如果已被选中则停止
							if ($(drop_target).size() == 1) {return;}
							// 已达到最大上传数量先移除最后一张
							if ($(container).find(".drop-item").not(".seat").size() == size) {
								var last = $(container).find(".drop-item").not(".seat").last();changeImage($(last).data("id"), false);
							}
							// 添加
							var data = $(target).find("img").data();image_list[id] = data;
							if ($(drop_target).size() == 0) {
								// 放入选中的栏
								var html = $("#template_1541574822gC385V").html();
								html = html.replace(/#title#/, $(target).attr("title"));
								html = html.replace(/#width#/, data.width);
								html = html.replace(/#height#/, data.height);
								html = html.replace(/#id#/, id);
								html = html.replace(/#id#/, id);
								html = html.replace(/#image#/, $(target).find("img").prop("outerHTML"));
								var seat = $(container).find("#dropzone").find(".drop-item").filter(".seat").first();
								if ($(seat).size() > 0) {
									$(seat).replaceWith($($.parseHTML(html)));
								} else {
									$(container).find("#dropzone").append(html);
								}
							}
						}
						// 设置选择图片的数量
						$(container).find(".image-selector-number").html($(container).find(".drop-item").not(".seat").size());
					}
					var dir_id = "135";
					tablelist = $(container).find("#tablelist").tablelist({
						url: "/store/goods/image-selector?output=0&size=<?php echo e($size); ?>",
						dataCallback: function(data) {
							data.dir_id = $(container).find(".dir-list").data("dir_id");data.sort_name = $(container).find("#sort_name").val();data.image_name = $.trim($(container).find("#image_name").val());
							// 切换目录回到第一页
							if (dir_id != data.dir_id) {
								data.page.cur_page = 1;
							}
							return data;
						},
						callback: function() {
							dir_id = $(".dir-list").data("dir_id");$(container).find(".dir-list > li").removeClass("selected");
							$(container).find("#dir_" + dir_id).addClass("selected");
							$(container).find(".image-item").each(function() {
								var id = $(this).data("id") + "";
								if (image_list[id]) {
									changeImage(id, true);
								}
							});
						}
					});
					// 切换分组
					$(container).find(".dir-list > li").click(function() {
						$(container).find(".dir-list").data("dir_id", $(this).data("dir_id"));
						tablelist.load();
					});
					// 排序
					$(container).find("#sort_name").change(function() {
						tablelist.load();
					});
					// 选择图片
					$(container).on("click", ".image-list > .image-item", function() {
						var id = $(this).data("id");
						var selected = $(this).hasClass("selected") ? false : true;
						changeImage(id, selected);
					});
					// 取消选择
					$(container).on("click", ".drop-item i", function() {
						var id = $(this).data("id");
						changeImage(id, false);
					});
					// 上传图片
					$(container).find(".image-selector-upload").click(function() {
						var options = $(container).data("options");
						if ($.isPlainObject(options)) {
							options = $.extend({maxSize: "4194304"}, options);
						} else {
							options = {maxSize: "4194304"};
						}
						$.imageupload({
							url: '<?php echo e(url("store/goods/image-gallery")); ?>',
							data: {
								dir_id: $(container).find(".dir-list").data("dir_id"),},
								// 允许批量上传
								multiple: true,
								options: options,
								callback: function(result) {
									if (result.code == 0) {
										var list = result.data;
										if (!$.isArray(list)) {
											list = [list];
										}
										// 选择
										if (size == 1) {
											// 如果只允许上传1个图片，则把上传的第一个图片替换
											image_list = [];
											image_list[list[0].img_id] = list[0];
										} else if ($(container).find(".drop-item").filter(".seat").size() == 0 && list.length == 1)
										{
											// 如果只上传一个图片并且没有空余的位置
											var id = $(container).find(".drop-item").not(".seat").last().data("id");
											changeImage(id, false);
											image_list[list[0].img_id] = list[0];
										} else {
											var length = Math.min(size - $(container).find(".drop-item").not(".seat").size(), list.length);
											for (var i = 0; i < length; i++) {
												// 添加项
												image_list[list[i].img_id] = list[i];
											}
										}
										// 加载
										tablelist.load();
									} else {
										$.msg(result.message, {time: 5000});
									}
								}
							});
						});
						// 按图片名称搜索
						$(container).on("click", ".image-search", function() {
							var name = $(this).prev(":input").val();
							if ($.trim(name) == "") {
								$.msg("请输入图片名称！");
								$(this).prev(":input").focus();
								return;
							}
							$(container).find(".dir-list").data("dir_id", "");
							$(".dir-list").find(".category-item").filter(".selected").removeClass("selected");
							tablelist.load();
						});
					})
				</script>