<!DOCTYPE html>
<html lang="zh-CN">
<?php echo $__env->make('common.link', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="style-seller">
	
	<?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<!--中间内容-->
	<div class="seller-center">
		<div class="wrapper">
			
			<?php echo $__env->make('common.slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
			<!--右侧内容-->
			<div class="seller-rihgt">
				<div class="seller-page">
					<div class="seller-page-bg"></div>
					<!--在这里调用内容-->
					
<link rel="stylesheet" href="/static/css/styles.css">
<link rel="stylesheet" href="/static/css/jquery.treetable.css">
<link rel="stylesheet" href="/static/css/jquery.treetable.theme.default.css">
<script src="/static/js/bootstrap-editable.js"></script>
<link rel="stylesheet" href="/static/css/bootstrap-editable.css">
<script src="/static/js/jquery.treetable.js"></script>
<div class="page">
	<div class="fixed-bar">
	<div class="item-title">
		<div class="subject">
			<h3>
				<span class="action">店铺商品分类 - 列表</span>
				<!--帮助教程-->
                <!--<a class="help-href" href="javascript:;" data-toggle="tooltip" data-placement="auto bottom" title="点击跳转到该模块教程页面"><i class="help-icon"></i></a>-->
                <!---->
			</h3>
			
			<h5>
				
								
								<span class="action-span">
					
										
					<a href="http://seller.68dsw.com/goods/category/import.html" class="btn btn-warning click-loading">
						<i class="fa fa-cloud-upload"></i>
						导入商品分类
					</a>
				</span>
								<span class="action-span">
					
										
					<a href="<?php echo e(url('store/category/add')); ?>" class="btn btn-warning click-loading">
						<i class="fa fa-plus"></i>
						添加商品分类
					</a>
				</span>
				
			</h5>
			
					</div>
	</div>
</div>
 
	<!-- 温馨提示 -->
	
	<!-- 搜索条件 -->
	<div class="search-term m-b-10">
		<div class="simple-form-field simple-form-search">
			<div class="form-group">
				<label class="control-label">
					<i class="fa fa-search"></i>
				</label>
			</div>
		</div>
		<div class="simple-form-field">
			<div class="form-group">
				<label class="control-label">
					<span>分类名称：</span>
				</label>
				<div class="form-control-wrap">
					<input type="text" id="cat_name" name="cat_name" class="form-control">
				</div>
			</div>
		</div>
		<div class="simple-form-field">
			<input type="button" id="btn_submit" class="btn btn-primary m-r-5" value="搜索">
			
			<input type="button" id="btn_export" class="btn btn-default m-r-5" value="导出">
			
		</div>
	</div>
	

	<!-- 分类列表 -->
	<div id="table_list" class="table-responsive">
		
<div class="common-title">
	<div class="ftitle">
		<h3>商品分类列表</h3>
		
		<h5>
			(&nbsp;共
			<span data-total-record="true"><?php echo e($count); ?></span>
			条记录&nbsp;)
		</h5>
		
	</div>
	<div class="operate m-l-20">
		
		<a class="reload" href="javascript:tablelist.load();" data-toggle="tooltip" data-placement="auto bottom" title="" data-original-title="刷新数据">
			<i class="fa fa-refresh"></i>
		</a>
		
		
		
	</div>
</div>
		<table class="table table-hover treeTable treetable">
			<thead>
				<tr>
					<th class="w350">
						<a href="javascript:void(0);" class="expand-toggle category-all" onclick="expandAll(this)">全部展开/收起</a>
						分类名称
					</th>
					<th class="w120 text-c">商品数量</th>
					<th class="w100 text-c">排序</th>
					<!-- <th class="w120 text-c">是否显示</th> -->
					<th class="handle w300">操作</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $catelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catelist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr id="cat_<?php echo e($catelist->id); ?>" data-tt-id="<?php echo e($catelist->id); ?>" data-tt-parent-id="<?php echo e($catelist->pid); ?>" class="1 branch collapsed" data-id="<?php echo e($catelist->id); ?>" data-parent-id="0" <?php if(strlen($catelist->path)>3): ?> style="display: none;" <?php endif; ?>>
					<td>
						<span class="indenter" style="padding-left: 0px;"></span>
						<a href="#" target="_blank" title="点击进入前台店铺查看分类" class="cat_name"><?php echo e($catelist->cate_name); ?></a>
					</td>
					
					<td class="text-c">
						<a class="f14" href="#" target="_blank" title="点击查看商品列表"><?php echo e($catelist->count); ?></a>
					</td>
					
					<td class="text-c">
						<a href="javascript:void(0);" class="cat_sort f14 editable editable-click" data-id="<?php echo e($catelist->id); ?>"><?php echo e($catelist->sort); ?></a>
					</td>
					<!-- <td class="text-c">
						<span data-action="set-is-show?id=<?php echo e($catelist->id); ?>" data-callback="switch_callback" class="ico-switch open" data-value="[0,1]" data-label="[&quot;\u5426&quot;,&quot;\u662f&quot;]" data-class="[&quot;fa fa-toggle-off&quot;,&quot;fa fa-toggle-on&quot;]"><i class="fa fa-toggle-on"></i>是</span></td> -->
					<td class="handle">
						<a href="<?php echo e(url('store/category/edit',$catelist->id)); ?>">编辑</a>
						<!-- <span>|</span>
						<a href="#">新增下级分类</a> -->
						<span>|</span>
						<a href="javascript:void(0);" object_id="<?php echo e($catelist->id); ?>" class="del border-none">删除</a>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		
<div id="pagination">
	<script data-page-json="true" type="text">
	{"page_key":"page","page_id":"pagination","default_page_size":10,"cur_page":1,"page_size":10,"page_size_list":[10,50,500,1000],"record_count":25,"page_count":0,"offset":0,"url":null,"sql":null}
</script>
	
	</div>
	
</div>
</div>
<script type="text/javascript">
	function expandAll() {
		if ($(this).data("expandAll")) {
			$(".treetable").treetable("collapseAll");
			$(this).data("expandAll", false);
		} else {
			$(".treetable").treetable("expandAll");
			$(this).data("expandAll", true);
		}
	}

	function switch_callback(result, object, value) {
		if (result.code == 0) {
			var cat_ids = result.cat_ids;
			if ($.isArray(cat_ids)) {
				for (var i = 1; i < cat_ids.length; i++) {
					var target = $("#cat_" + cat_ids[i]).find(".ico-switch");
					tablelist.changeSwitch(target, value);
				}
			}
		}
	}

	$(".treetable").treetable({
		expandable: true,
	});

	var tablelist = null;
	$().ready(function() {
		tablelist = $("#table_list").tablelist({
			callback: function() {
				$(".treetable").treetable({
					expandable: true,
				});

				$(".treetable").treetable("expandAll");

				var cat_name = $("#cat_name").val();

				if ($.trim(cat_name) != "") {
					$(".cat_name").each(function() {
						var html = $(this).html();
						html = html.replace(cat_name, "<span style='color: red; margin: 0px; padding: 0px;'>" + cat_name + "</span>");
						$(this).html(html);
					});
				}
			}
		});

		$("#btn_submit").click(function() {
			tablelist.load({
				'cat_name': $("#cat_name").val()
			});
			return false;
		});

		// 删除记录  
		$("body").on('click', '.del', function() {
			var id = $(this).attr("object_id");

			$.confirm('您确定删除这条记录吗？', function() {
				$.post('<?php echo e(url("store/category/del")); ?>', {
					id: id
				}, function(result) {
					if (result.code == 0) {
						$.msg(result.message);
						$.go('<?php echo e(url("store/category/list")); ?>');
					} else {
						$.msg(result.message, {
							time: 5000
						})
					}
				}, "json");
			})

		});

		// 导出
		$("#btn_export").click(function() {
			var url = "/goods/category/export.html";
			url += "?cat_name=" + $("#cat_name").val();
			$.go(url, "_blank", false);
		});
	});
</script>

<script type="text/javascript">
	$().ready(function() {
		$("input[name=cat_name]").focus();
		//条形码扫描触发事件
		$("input[type=text]").bind("keypress", function(event) {
			if (event.keyCode == "13") {
				$("#btn_submit").click();
			}
		});
	})
</script>

<script type="text/javascript">
	$(document).ready(function() {
		// 排序
		$(".cat_sort").editable({
			type: "text",
			url: "/goods/category/edit-cat-info",
			pk: 1,
			ajaxOptions: {
				type: "post"
			},
			params: function(params) {
				params.id = $(this).data("id");
				params.title = "cat_sort";
				return params;
			},
			success: function(response, newValue) {
				var response = eval("(" + response + ")");
				if (response.code == -1) {
					return response.message;
				}
			}
		});
	});
</script>
					
				</div>
			</div>
		</div>
		<!--底部内容-->
		<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<script type="text/javascript">
function toFirst(target){
	var url = $(target).parents("li").find(".sub-list").find("li:first").find("a").attr("href");
	$.go(url);
}
function to(url, target){
	
}

function clearCache(){
	// 缓载
	$.loading.start();
	$.post("/site/clear-cache", {}, function(result){
		if(result.code == 0){
			$.msg(result.message);
		}else{
			$.msg(result.message, {
				time: 5000
			});
		}
	}).always(function(){
		$.loading.stop();
	});
}
// 登录成功关闭弹出框
$.login.success = function(){
	// 关闭并销毁登录窗口
	$.login.close(true);
}
</script>

<script type="text/javascript">
	// setInterval("auto_print()",10000);
	function auto_print(order_id)
	{
		$.ajax({
			type: "GET",
			url: "/site/auto-print",
			dataType: "json",
			data: {
				order_id: order_id
			},
			success: function(result) {
				if(result.code == 0)
				{
					lodop_print_html(result.print_title, result.data,result.printer);
				}
			}
		});
	}
</script>

<!-- 加载消息监听js-->
<script src="/static/newjs/message.js"></script>
<script src="/static/newjs/messageWS.js"></script>
<script type="text/javascript">
//声音监听
WS_AddUser({
	'user_id': 'shop_1717',
	'url': "ws://push.yunmall.68mall.com:7272",
	'type': "add_user"
}); 
//右下角消息提醒弹窗js
function open_message_box(data) {
	if (!data) {    
		data = {};
    }
	
	var src = window.location.href;
	
	// 如果当前框架中的链接地址和弹框的链接地址一致则不弹框
	if(data.auto_refresh == 1 && data.link && src.indexOf(data.link) != -1){
		
		var contentWindow = window;
		
		if(contentWindow.tablelist){
			contentWindow.tablelist.load({
				page: {
					cur_page: 1
				}
			});
		}else{
			contentWindow.location.reload();
		}
		
		return;
	}
	
	$('.message-pop-box').find('#message-pop-text').html(data.content);
	
	if(data.link){
		$('.message-pop-box').find('.message-btn').attr('href', data.link).show();
	}else{
		$('.message-pop-box').find('.message-btn').hide();
	}
	
	if(data.content || data.link){
		$('.message-pop-box').removeClass('down').addClass('up');
	}
	
	try {
		if(refresh_order && typeof(refresh_order) == "function") { 
			refresh_order();
        } 
    } catch(e) {}
}
$('.message-pop-box .close').click(function() {
	$('.message-pop-box').removeClass('up').addClass('down');
});
//用户信息
$(".admin").mouseenter(function() {
	window.focus();
	$("#admin-panel").show();
}).mouseleave(function() {
	$("#admin-panel").hide();
});
</script>
<script type="text/javascript">
	var clipboard = new Clipboard('.btn-copy');
    clipboard.on('success', function(e) {
        $.msg('复制成功');
    });
    clipboard.on('error', function(e) {
    	$.msg('复制失败');
    });
 	// 更新后台主框架消息弹窗
	function update_message() {
		// 是否重新获取数据
		if ($("#message-panel").html().length > 0) {
			// if (parseInt($("#counts_all").val()) != 0) {
			var time_step = 5; // 最小刷新间隔，单位：秒
			var this_time = new Date();
			if ((parseInt($("#counts_time").val()) + parseInt(time_step)) > parseInt(this_time.getTime() / 1000)) {
				return true;
			}
			// }
		}
		$.ajax({
			type: 'GET',
			url: '/site/update-message.html',
			data: {},
			dataType: 'json',
			success: function(result) {
				if (result.code == 0) {
					$("#message-panel").html(result.data);
				} else if (result.code == 1) {
				} else {
					$.msg(result.message);
				}
			}
		});
	}
	// 消息通知
	$("#message-box").mouseenter(function() {
		update_message();
		window.focus();
		$("#message-panel").show();
	}).mouseleave(function() {
		$("#message-panel").hide();
	}).find(".close").click(function() {
		$("#message-panel").hide();
	});
</script>



</body></html>