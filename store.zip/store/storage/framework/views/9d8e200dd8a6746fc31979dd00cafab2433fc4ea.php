
<!DOCTYPE html>
<!--[if IE 8]> <html lang="zh-CN" class="ie8"> <![endif]-->
<html lang="zh-CN">
<?php echo $__env->make('storeindex.common.link', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
	<!-- 引入头部文件 -->
	<!-- 引入头部文件 -->
<script src="/static/storeindex/js/index.js?v=20180027"></script>
<script src="/static/storeindex/js/tabs.js?v=20180027"></script>
<script src="/static/storeindex/js/bubbleup.js?v=20180027"></script>
<script src="/static/storeindex/js/jquery.hiSlider.js?v=20180027"></script>
<script src="/static/storeindex/js/index_tab.js?v=20180027"></script>
<script src="/static/storeindex/js/jump.js?v=20180027"></script>
<script src="/static/storeindex/js/nav.js?v=20180027"></script>
<!-- 站点选择 -->
<?php echo $__env->make('storeindex.common.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="layout"  style="min-height:400px;">
	<!-- 内容 -->
	
<!-- 右侧客服 _start-->
<!-- 右侧客服_end -->

<div class="condition-screen w1210">
	<div class="blank15"></div>
	<div class="content-wrap category-wrap clearfix">
		<div class="fl">
			<div class="store-category">
				<h3 class="left-title">店内分类</h3>
				<div class="left-content tree">
					<ul>
												
												
						<li>
							<span>
								<i class="icon-minus-sign"></i>
							</span>
							<a href="<?php echo e(url('goods/list')); ?>?shop_id=<?php echo e($shop_id); ?>" target="_self" title="全部商品" class="tree-first">全部商品</a>
							<ul>
								
							</ul>
						</li>
						<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li>
							<span>
								<i class="icon-minus-sign"></i>
							</span>
							<a href="<?php echo e(url('goods/list')); ?>?shop_id=<?php echo e($shop_id); ?>&cate_id=<?php echo e($category->id); ?>" target="_self" title="<?php echo e($category->cate_name); ?>" class="tree-first"><?php echo e($category->cate_name); ?></a>
							<ul>
								
								<!-- 当前位置加class curr-->
								<?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li <?php if($children->id === $cat_id): ?> class="curr" <?php endif; ?>>
									<span>
										<i class="arrow"></i>
									</span>
									<a href="<?php echo e(url('goods/list')); ?>?shop_id=<?php echo e($shop_id); ?>&cate_id=<?php echo e($children->id); ?>" target="_self" title="<?php echo e($children->cate_name); ?>"><?php echo e($children->cate_name); ?></a>
								</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
								
							</ul>
						</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</ul>
				</div>
			</div>
		</div>

		<div class="main fr">
			<div class="" id="filter">
				<!--排序-->
				<form method="GET" name="listform" action="category.php">
					<div class="fore1">
						<dl class="order">
							
							<dd class="first curr">
								<a href="javascript:void(0);" data-go="#">
									综合
									
								</a>
							</dd>
							
							<dd class="">
								<a href="javascript:void(0);" data-go="#">
									销量
									
									<i class="iconfont icon-DESC"></i>
									
								</a>
							</dd>
							
							<dd class="">
								<a href="javascript:void(0);" data-go="#">
									新品
									
									<i class="iconfont icon-DESC"></i>
									
								</a>
							</dd>
							
							<dd class="">
								<a href="javascript:void(0);" data-go="#">
									评论
									
									<i class="iconfont icon-DESC"></i>
									
								</a>
							</dd>
							
							<dd class="">
								<a href="javascript:void(0);" data-go="#">
									价格
									
									<i class="iconfont icon-DESC"></i>
									
								</a>
							</dd>
							
							<dd class="">
								<a href="javascript:void(0);" data-go="#">
									人气
									
									<i class="iconfont icon-DESC"></i>
									
								</a>
							</dd>
							
						</dl>
						<div class="pagin">
							<!---->
							<a class="prev disabled">
								<span class="icon prev-disabled"></span>
							</a>
							<!---->
							<span class="text">
								<font class="color">1</font>
								/
								
								1
								
							</span>
							<!-- -->
							<a class="next disabled" href="javascript:;">
								<span class="icon next-disabled"></span>
							</a>
							
						</div>
						<div class="total">
							共
							<span class="color">5</span>
							个商品
						</div>
					</div>
					<div class="fore2">
						<div class="filter-btn">
							
							<a href="javascript:void(0);" data-go="/shop-list-309-290-0-1-0-0-0-4-0-0.html" class="filter-tag ">
								<input class="none" name="fff" onclick="" type="checkbox">
																<i class="iconfont">&#xe715;</i>
																<span class="text">包邮</span>
							</a>
							
							<a href="javascript:void(0);" data-go="/shop-list-309-290-0-0-0-1-0-4-0-0.html" class="filter-tag ">
								<input class="none" name="fff" onclick="" type="checkbox">
																<i class="iconfont">&#xe715;</i>
																<span class="text">仅显示有货</span>
							</a>
							
						</div>
					</div>
				</form>
			</div>
			
			<!--主体商品内容展示-->
			<form name="compareForm" action="compare.php" method="post" onsubmit="">
				<ul class="list-grid clearfix">
					<!-- -->
					<li class="item ">
						<div class="item-con">
							
							
							
							<!--售罄-->
							
							<div class="item-pic">
								<a href="http://bj.68dsw.com/goods-39713.html" title="【三只松鼠_夏威夷果265gx2袋】零食坚果干果奶油味送开口器" target="_blank">
									<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/03/14937921068365.jpg?x-oss-process=image/resize,m_pad,limit_0,h_320,w_320" alt="" />
								</a>
							</div>
							<div class="img-scroll" style="display: none;">
								<a href="javascript:void(0);" class="img-prev">&lt;</a>
								<a href="javascript:void(0);" class="img-next">&gt;</a>
								<div class="img-wrap">
									<ul class="img-main" style="left: 0px;">
										
										<li class="img-item">
											<a href="javascript:;" title="">
												<img class="lazy" width="25" height="25" alt="" src="/static/storeindex/images/common/blank.png" data-original="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/03/14937921068365.jpg?x-oss-process=image/resize,m_pad,limit_0,h_80,w_80" data-src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/03/14937921068365.jpg?x-oss-process=image/resize,m_pad,limit_0,h_320,w_320" />
											</a>
										</li>
										

									</ul>
								</div>
							</div>
							<div class="item-info">
								<div class="item-price">
									<em class="sale-price color">¥95.00元</em>
																		
								</div>
								<div class="item-name">
									<!-- 注意商品名称长度，需考虑包邮、赠品标签 -->
									<a href="http://bj.68dsw.com/goods-39713.html" target="_blank" title="【三只松鼠_夏威夷果265gx2袋】零食坚果干果奶油味送开口器">【三只松鼠_夏威夷果265gx2袋】零食坚果干果奶油味送开口...</a>
									<!-- 包邮、赠品标签  _star -->
									
									
									<i class="free-shipping">包邮</i>
									
									
									
									<!-- 包邮、赠品标签  _end -->
								</div>
								<div class="item-con-info">
									<div class="fl">
										<div class="item-operate">
											
											<a href="javascript:;" onClick="toggleGoods(39713,44093,this)" class="operate-btn collet-btn  ">
												<i class="iconfont">&#xe6b3;</i>
												<span> 收藏 </span>
											</a>
											
											<a href="http://bj.68dsw.com/goods-39713.html#goods_evaluate" target="_blank" class="operate-btn comment-btn">
												<i class="iconfont">&#xe6e4;</i>
												1
											</a>
										</div>

									</div>
									<div class="fr">
										<div class="item-add-cart">
											<!--售罄时，为加入购物车按钮添加sell-out-btn样式-->
											
											
											<a href="javascript:;" data-goods-id="39713" data-image-url="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/03/14937921068365.jpg?x-oss-process=image/resize,m_pad,limit_0,h_80,w_80" class="add-cart" title="加入购物车"></a>
											
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</li>
					<!-- -->
					<li class="item ">
						<div class="item-con">
							
							
							
							<!--售罄-->
							
							<div class="item-pic">
								<a href="http://bj.68dsw.com/goods-39714.html" title="【三只松鼠_夏威夷果265gx3袋】零食坚果炒货干果奶油味送开口器" target="_blank">
									<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/03/14937920811200.jpg?x-oss-process=image/resize,m_pad,limit_0,h_320,w_320" alt="" />
								</a>
							</div>
							<div class="img-scroll" style="display: none;">
								<a href="javascript:void(0);" class="img-prev">&lt;</a>
								<a href="javascript:void(0);" class="img-next">&gt;</a>
								<div class="img-wrap">
									<ul class="img-main" style="left: 0px;">
										
										<li class="img-item">
											<a href="javascript:;" title="">
												<img class="lazy" width="25" height="25" alt="" src="/images/common/blank.png" data-original="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/03/14937920811200.jpg?x-oss-process=image/resize,m_pad,limit_0,h_80,w_80" data-src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/03/14937920811200.jpg?x-oss-process=image/resize,m_pad,limit_0,h_320,w_320" />
											</a>
										</li>
										

									</ul>
								</div>
							</div>
							<div class="item-info">
								<div class="item-price">
									<em class="sale-price color">¥79.90元</em>
																		
								</div>
								<div class="item-name">
									<!-- 注意商品名称长度，需考虑包邮、赠品标签 -->
									<a href="http://bj.68dsw.com/goods-39714.html" target="_blank" title="【三只松鼠_夏威夷果265gx3袋】零食坚果炒货干果奶油味送开口器">【三只松鼠_夏威夷果265gx3袋】零食坚果炒货干果奶油味送...</a>
									<!-- 包邮、赠品标签  _star -->
									
									
									<i class="free-shipping">包邮</i>
									
									
									
									<!-- 包邮、赠品标签  _end -->
								</div>
								<div class="item-con-info">
									<div class="fl">
										<div class="item-operate">
											
											<a href="javascript:;" onClick="toggleGoods(39714,44094,this)" class="operate-btn collet-btn  ">
												<i class="iconfont">&#xe6b3;</i>
												<span> 收藏 </span>
											</a>
											
											<a href="http://bj.68dsw.com/goods-39714.html#goods_evaluate" target="_blank" class="operate-btn comment-btn">
												<i class="iconfont">&#xe6e4;</i>
												1
											</a>
										</div>

									</div>
									<div class="fr">
										<div class="item-add-cart">
											<!--售罄时，为加入购物车按钮添加sell-out-btn样式-->
											
											
											<a href="javascript:;" data-goods-id="39714" data-image-url="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/03/14937920811200.jpg?x-oss-process=image/resize,m_pad,limit_0,h_80,w_80" class="add-cart" title="加入购物车"></a>
											
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</li>
					<!-- -->
					<li class="item ">
						<div class="item-con">
							
							
							
							<!--售罄-->
							
							<div class="item-pic">
								<a href="http://bj.68dsw.com/goods-39715.html" title="【三只松鼠_夏威夷果185gx3袋】零食坚果干果奶油味送开口器" target="_blank">
									<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/03/14937920575737.jpg?x-oss-process=image/resize,m_pad,limit_0,h_320,w_320" alt="" />
								</a>
							</div>
							<div class="img-scroll" style="display: none;">
								<a href="javascript:void(0);" class="img-prev">&lt;</a>
								<a href="javascript:void(0);" class="img-next">&gt;</a>
								<div class="img-wrap">
									<ul class="img-main" style="left: 0px;">
										
										<li class="img-item">
											<a href="javascript:;" title="">
												<img class="lazy" width="25" height="25" alt="" src="/images/common/blank.png" data-original="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/03/14937920575737.jpg?x-oss-process=image/resize,m_pad,limit_0,h_80,w_80" data-src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/03/14937920575737.jpg?x-oss-process=image/resize,m_pad,limit_0,h_320,w_320" />
											</a>
										</li>
										

									</ul>
								</div>
							</div>
							<div class="item-info">
								<div class="item-price">
									<em class="sale-price color">¥59.90元</em>
																		
								</div>
								<div class="item-name">
									<!-- 注意商品名称长度，需考虑包邮、赠品标签 -->
									<a href="http://bj.68dsw.com/goods-39715.html" target="_blank" title="【三只松鼠_夏威夷果185gx3袋】零食坚果干果奶油味送开口器">【三只松鼠_夏威夷果185gx3袋】零食坚果干果奶油味送开口...</a>
									<!-- 包邮、赠品标签  _star -->
									
									
									<i class="free-shipping">包邮</i>
									
									
									
									<!-- 包邮、赠品标签  _end -->
								</div>
								<div class="item-con-info">
									<div class="fl">
										<div class="item-operate">
											
											<a href="javascript:;" onClick="toggleGoods(39715,44095,this)" class="operate-btn collet-btn  ">
												<i class="iconfont">&#xe6b3;</i>
												<span> 收藏 </span>
											</a>
											
											<a href="http://bj.68dsw.com/goods-39715.html#goods_evaluate" target="_blank" class="operate-btn comment-btn">
												<i class="iconfont">&#xe6e4;</i>
												6
											</a>
										</div>

									</div>
									<div class="fr">
										<div class="item-add-cart">
											<!--售罄时，为加入购物车按钮添加sell-out-btn样式-->
											
											
											<a href="javascript:;" data-goods-id="39715" data-image-url="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/03/14937920575737.jpg?x-oss-process=image/resize,m_pad,limit_0,h_80,w_80" class="add-cart" title="加入购物车"></a>
											
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</li>
					<!-- -->
					<li class="item last">
						<div class="item-con">
							
							
							
							<!--售罄-->
							
							<div class="item-pic">
								<a href="http://bj.68dsw.com/goods-39716.html" title="三只松鼠 夏威夷果265g零食坚果炒货干果奶油味开口" target="_blank">
									<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/taobao-yun-images/522886282977/TB1n0gxKpXXXXauXXXXXXXXXXXX_!!0-item_pic.jpg?x-oss-process=image/resize,m_pad,limit_0,h_320,w_320" alt="" />
								</a>
							</div>
							<div class="img-scroll" style="display: none;">
								<a href="javascript:void(0);" class="img-prev">&lt;</a>
								<a href="javascript:void(0);" class="img-next">&gt;</a>
								<div class="img-wrap">
									<ul class="img-main" style="left: 0px;">
										
										<li class="img-item">
											<a href="javascript:;" title="">
												<img class="lazy" width="25" height="25" alt="" src="/images/common/blank.png" data-original="http://68dsw.oss-cn-beijing.aliyuncs.com/images/taobao-yun-images/522886282977/TB1n0gxKpXXXXauXXXXXXXXXXXX_!!0-item_pic.jpg?x-oss-process=image/resize,m_pad,limit_0,h_80,w_80" data-src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/taobao-yun-images/522886282977/TB1n0gxKpXXXXauXXXXXXXXXXXX_!!0-item_pic.jpg?x-oss-process=image/resize,m_pad,limit_0,h_320,w_320" />
											</a>
										</li>
										

									</ul>
								</div>
							</div>
							<div class="item-info">
								<div class="item-price">
									<em class="sale-price color">¥25.90元</em>
																		
								</div>
								<div class="item-name">
									<!-- 注意商品名称长度，需考虑包邮、赠品标签 -->
									<a href="http://bj.68dsw.com/goods-39716.html" target="_blank" title="三只松鼠 夏威夷果265g零食坚果炒货干果奶油味开口">三只松鼠 夏威夷果265g零食坚果炒货干果奶油味开口</a>
									<!-- 包邮、赠品标签  _star -->
									
									
									<i class="free-shipping">包邮</i>
									
									
									
									<!-- 包邮、赠品标签  _end -->
								</div>
								<div class="item-con-info">
									<div class="fl">
										<div class="item-operate">
											
											<a href="javascript:;" onClick="toggleGoods(39716,44096,this)" class="operate-btn collet-btn  ">
												<i class="iconfont">&#xe6b3;</i>
												<span> 收藏 </span>
											</a>
											
											<a href="http://bj.68dsw.com/goods-39716.html#goods_evaluate" target="_blank" class="operate-btn comment-btn">
												<i class="iconfont">&#xe6e4;</i>
												1
											</a>
										</div>

									</div>
									<div class="fr">
										<div class="item-add-cart">
											<!--售罄时，为加入购物车按钮添加sell-out-btn样式-->
											
											
											<a href="javascript:;" data-goods-id="39716" data-image-url="http://68dsw.oss-cn-beijing.aliyuncs.com/images/taobao-yun-images/522886282977/TB1n0gxKpXXXXauXXXXXXXXXXXX_!!0-item_pic.jpg?x-oss-process=image/resize,m_pad,limit_0,h_80,w_80" class="add-cart" title="加入购物车"></a>
											
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</li>
					<!-- -->
					<li class="item ">
						<div class="item-con">
							
							
							
							<!--售罄-->
							
							<div class="item-pic">
								<a href="http://bj.68dsw.com/goods-39711.html" title="三只松鼠 坚果炒货 零食奶油味 夏威夷果" target="_blank">
									<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/03/14937810113954.jpg?x-oss-process=image/resize,m_pad,limit_0,h_320,w_320" alt="" />
								</a>
							</div>
							<div class="img-scroll" style="display: none;">
								<a href="javascript:void(0);" class="img-prev">&lt;</a>
								<a href="javascript:void(0);" class="img-next">&gt;</a>
								<div class="img-wrap">
									<ul class="img-main" style="left: 0px;">
										
										<li class="img-item">
											<a href="javascript:;" title="">
												<img class="lazy" width="25" height="25" alt="" src="/images/common/blank.png" data-original="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/03/14937810113954.jpg?x-oss-process=image/resize,m_pad,limit_0,h_80,w_80" data-src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/03/14937810113954.jpg?x-oss-process=image/resize,m_pad,limit_0,h_320,w_320" />
											</a>
										</li>
										

									</ul>
								</div>
							</div>
							<div class="item-info">
								<div class="item-price">
									<em class="sale-price color">¥25.90元</em>
																		
								</div>
								<div class="item-name">
									<!-- 注意商品名称长度，需考虑包邮、赠品标签 -->
									<a href="http://bj.68dsw.com/goods-39711.html" target="_blank" title="三只松鼠 坚果炒货 零食奶油味 夏威夷果">三只松鼠 坚果炒货 零食奶油味 夏威夷果</a>
									<!-- 包邮、赠品标签  _star -->
									
									
									<i class="free-shipping">包邮</i>
									
									
									
									<!-- 包邮、赠品标签  _end -->
								</div>
								<div class="item-con-info">
									<div class="fl">
										<div class="item-operate">
											
											<a href="javascript:;" onClick="toggleGoods(39711,44091,this)" class="operate-btn collet-btn  ">
												<i class="iconfont">&#xe6b3;</i>
												<span> 收藏 </span>
											</a>
											
											<a href="http://bj.68dsw.com/goods-39711.html#goods_evaluate" target="_blank" class="operate-btn comment-btn">
												<i class="iconfont">&#xe6e4;</i>
												0
											</a>
										</div>

									</div>
									<div class="fr">
										<div class="item-add-cart">
											<!--售罄时，为加入购物车按钮添加sell-out-btn样式-->
											
											
											<a href="javascript:;" data-goods-id="39711" data-image-url="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/03/14937810113954.jpg?x-oss-process=image/resize,m_pad,limit_0,h_80,w_80" class="add-cart" title="加入购物车"></a>
											
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</li>
					
				</ul>
				<!--当没有数据时，显示如下div-->
				
				<!--分页-->
				<div class="pull-right page-box">
					
					
					
<div id="pagination" class="page">
	<script data-page-json="true" type="text">
	{"page_key":"page","page_id":"pagination","default_page_size":10,"cur_page":1,"page_size":20,"page_size_list":[10,50,500,1000],"record_count":5,"page_count":1,"offset":0,"url":null,"sql":null}
</script>
	<div class="page-wrap fr">
		<div class="total">共5条记录
		<!-- 每页显示：
		<select class="select m-r-5" data-page-size="20">
			
			
			<!--<option value="10">10</option>-->
			
			
			
			<!--<option value="50">50</option>-->
			
			
			
			<!--<option value="500">500</option>-->
			
			
			
			<!--<option value="1000">1000</option>-->
			
			
		<!--</select>
		条 -->
		
		</div>
	</div>
	<div class="page-num fr">
		<span class="num prev disabled"class="disabled" style="display: none;">
			<a class="fa fa-angle-double-left" data-go-page="1" title="第一页"></a>
		</span>
		
		<span >
			<a class="num prev disabled " title="上一页">上一页</a>
		</span>
		
		
		
		
		
		
		
		
		<!--   -->
		
		<span class="num curr">
			<a data-cur-page="1">1</a>
		</span>
		
		
		
		
		
		
		
		<span class="disabled" style="display: none;">
			<a class="num " class="fa fa-angle-double-right" data-go-page="1" title="最后一页"></a>
		</span>
		
		<span >
			<a class="num next disabled" title="下一页">下一页</a>
		</span>
		
	</div>
<!-- <div class="pagination-goto">
		<input class="ipt form-control goto-input" type="text">
		<button class="btn btn-default goto-button" title="点击跳转到指定页面">GO</button>
		<a class="goto-link" data-go-page="" style="display: none;"></a>
	</div> -->	
	<script type="text/javascript">
		$().ready(function() {
			$(".pagination-goto > .goto-input").keyup(function(e) {
				$(".pagination-goto > .goto-link").attr("data-go-page", $(this).val());
				if (e.keyCode == 13) {
					$(".pagination-goto > .goto-link").click();
				}
			});
			$(".pagination-goto > .goto-button").click(function() {
				var page = $(".pagination-goto > .goto-link").attr("data-go-page");
				if ($.trim(page) == '') {
					return false;
				}
				$(".pagination-goto > .goto-link").attr("data-go-page", page);
				$(".pagination-goto > .goto-link").click();
				return false;
			});
		});
	</script>
</div>
					
				</div>
			</form>
			
		</div>
	</div>
</div>

<script src="/static/storeindex/js/category.js?v=20180027"></script>
<script src="/static/storeindex/js/jquery.tablelist.js?v=20180027"></script>
<script type="text/javascript">
	$().ready(function() {
		var page_url = "/shop-list-309-290-{0}-0-0-0-0-4-0-0.html";
		page_url = page_url.replace(/&amp;/g, '&');
		
		var tablelist = $("#table_list").tablelist({
			page_mode: 1,
			go: function(page){
				page_url = page_url.replace("{0}", page);
				$.go(page_url);
			}
		});
			
		$(".prev-page").click(function(){
			tablelist.prePage();
		});
		
		$(".next-page").click(function(){
			tablelist.nextPage();
		});
		
		$(".add-cart").click(function(event) {
			var goods_id = $(this).data("goods-id");
			var image_url = $(this).data("image-url");
			var buy_enable = $(this).data("buy-enable");
			if(buy_enable){
				$.msg(buy_enable);
				return false;
			}
			$.cart.add(goods_id, 1, {
				is_sku: false, 
				event: event,
				image_url: image_url,
				callback: function(){
					var attr_list = $('.attr-list').height(); 
					$('.attr-list').css({ 
						"overflow":"hidden" 
					});
					if(attr_list>=200){ 
						$('.attr-list').addClass("attr-list-border");
						$('.attr-list').css({ 
							"overflow-y":"auto" 
						}); 
					}       
				}
			});
			return false;
		});
		
		//规格相册
		sildeImg(0);
		
		// 跳转页面
		$("[data-go]").click(function(){
			$.go($(this).data("go"));
		});
	});
</script>

    </div>
    
	<!--底部footer-->
	
<!-- 右侧边栏 _start -->
<!-- <div class="right-sidebar-con">
	<div class="right-sidebar-main">
		<div class="right-sidebar-panel">
			<div id="quick-links" class="quick-links">
				<ul> -->
					<!-- <li class="quick-area quick-login sidebar-user-trigger"> -->
						<!-- 用户 -->
						<!-- <a href="javascript:void(0);" class="quick-links-a">
							<i class="iconfont">&#xe6cc;</i>
						</a>
						<div class="sidebar-user quick-sidebar">
							<i class="arrow-right"></i>
							<div class="sidebar-user-info">
								没有登录的情况 _start
								<div class="SZY-USER-NOT-LOGIN" style="display: none;">
									<div class="user-pic">
										<div class="user-pic-mask"></div>
										<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/system/config/default_image/default_user_portrait_0.png" />
									</div>
									<br />
									<p>
										你好！请
										<a href="javascript:void(0);" class="quick-login-a color ajax-login">登录</a>
										|
										<a href="http://bj.68dsw.com/register.html" class="color">注册</a>
									</p>
								</div> -->
		<!-- 没有登录的情况 _end -->
		<!-- 有登录的情况 _start -->
		<!-- <div class="SZY-USER-ALREADY-LOGIN" style="display: none;">
			<div class="user-have-login">
				<div class="user-pic">
					<div class="user-pic-mask"></div>
					<img src="" class="SZY-USER-PIC" />
				</div>
				<div class="user-info">
					<p>
						用&nbsp;&nbsp;&nbsp;户：
						<span class="SZY-USER-NAME"></span>
					</p>
					<p class="SZY-USER-RANK" style="display: none;">
						等&nbsp;&nbsp;&nbsp;级：
						<img class="SZY-USER-RANK-IMG" />
						<span class="SZY-USER-RANK-NAME"></span>
					</p>
				</div>
			</div>
			<p class="m-t-10">
				<span class="prev-login">
					上次登录时间：
					<span class="SZY-USER-LAST-LOGIN"></span>
				</span>
				<a href="http://bj.68dsw.com/user.html" class="btn account-btn" target="_blank">个人中心</a>
				<a href="http://bj.68dsw.com/user/order.html" class="btn order-btn" target="_blank">订单中心</a>
			</p>
		</div>
		有登录的情况 _end
			</div>
		</div>
					</li> -->
					<!-- <li class="sidebar-tabs">
						购物车
						<div class="cart-list quick-links-a sidebar-cartbox-trigger">
							<i class="iconfont">&#xe6c5;</i>
							<div class="span">购物车</div>
							<span class="ECS_CARTINFO">
								<span class="cart_num SZY-CART-COUNT">0</span>
								<div class="sidebar-cart-box">
									<h3 class="sidebar-panel-header">
										<a href="javascript:void(0);" class="title">
											<i class="cart-icon"></i>
											<em class="title">购物车</em>
										</a>
										<span class="close-panel"></span>
									</h3>
								</div>
							</span>
						</div>
					</li> -->
					<!-- <li class="sidebar-tabs">
						<a href="javascript:void(0);" class="mpbtn_history quick-links-a sidebar-historybox-trigger">
							<i class="iconfont">&#xe76a;</i>
						</a>
						<div class="popup">
							<font id="mpbtn_histroy">我看过的</font>
							<i class="arrow-right"></i>
						</div>
					</li> -->
					<!-- 如果当前页面有对比功能 则显示对比按钮 _start-->
					<!-- <li class="sidebar-tabs">
						<a href="javascript:void(0);" class="mpbtn-contrast quick-links-a sidebar-comparebox-trigger">
							<i class="iconfont">&#xe8f8;</i>
						</a>
						<div class="popup">
							对比商品
							<i class="arrow-right"></i>
						</div>
					</li> -->
					<!-- 如果当前页面有对比功能 则显示对比按钮 _end-->
					<!-- <li>
						<a href="http://bj.68dsw.com/user/collect/shop.html" target="_blank" class="mpbtn_stores quick-links-a">
							<i class="iconfont">&#xe6c8;</i>
						</a>
						<div class="popup">
							我收藏的店铺
							<i class="arrow-right"></i>
						</div>
					</li>
					<li id="collectGoods">
						<a href="http://bj.68dsw.com/user/collect/goods.html" target="_blank" class="mpbtn_collect quick-links-a">
							<i class="iconfont">&#xe6b3;</i>
						</a>
						<div class="popup">
							我的收藏
							<i class="arrow-right"></i>
						</div>
					</li> -->
				<!-- </ul>
							</div> -->
			<!-- <div class="quick-toggle">
				<ul>
					
					<li class="quick-area">
						<a class="quick-links-a" href="javascript:void(0);">
							<i class="iconfont">&#xe6ad;</i>
						</a>
						<div class="sidebar-service quick-sidebar">
							<i class="arrow-right"></i>
							
							<div class="customer-service">
								<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=1351079047&site=qq&menu=yes">
									<i class="iconfont color">&#xe6cd;</i>
									QQ
								</a>
							</div>
							
							
							<div class="customer-service">
								<a target="_blank" href="http://amos.alicdn.com/getcid.aw?v=2&uid=ll4000785268&site=cntaobao&s=2&groupid=0&charset=utf-8">
									<i class="iconfont color">&#xe6c4;</i>
									旺旺
								</a>
							</div>
							
							
							<div class="customer-service">
								<a href="javascript:void(0);" class="service-online">
									<i class="iconfont color">&#xe6ad;</i>
									在线客服
								</a>
							</div>
							
						</div>
					</li>
					
					
					<li class="quick-area">
						<a class="quick-links-a" href="javascript:void(0);">
							<i class="iconfont qr-code">&#xe6bc;</i>
						</a>
						<div class="sidebar-code quick-sidebar">
							<i class="arrow-right"></i>
							<img src="/static/storeindex/images/mall_wx_qrcode_0.png" />
						</div>
					</li>
					
					<li class="returnTop">
						<a href="javascript:void(0);" class="return_top quick-links-a">
							<i class="iconfont">&#xe6cb;</i>
						</a>
						<div class="popup">
							返回顶部
							<i class="arrow-right"></i>
						</div>
					</li>
				</ul>
			</div>
					</div> -->
		<div class="">
			<!--红包 start-->
			<!--红包 end-->
			<!--购物车 start-->
			
<div class="right-sidebar-panels sidebar-cartbox">
	<div class="sidebar-cart-box">
		<h3 class="sidebar-panel-header">
			<a href="javascript:void(0);" class="title" target="_blank">
				<i class="cart-icon"></i>
				<em class="title">购物车</em>
			</a>
			<span class="close-panel"></span>
		</h3>
		<div class="sidebar-cartbox-goods-list">
			
			<div class="cart-panel-main">
				<div class="cart-panel-content">
					
					<!-- 没有商品的展示形式 _start -->
					<div class="tip-box">
						<img src="/static/storeindex/images/noresult.png" class="tip-icon" />
						<div class="tip-text">
							您的购物车里什么都没有哦
							<br />
							<a class="color" href="#" title="再去看看吧" target="_blank">再去看看吧</a>
						</div>
					</div>
					<!-- 没有商品的展示形式 _end-->
					
				</div>
			</div>
			
			
		</div>
	</div>
</div>
			<!--购物车 end-->
			<!--浏览历史 start-->
			<!---->
<div class="right-sidebar-panels sidebar-historybox">
	<h3 class="sidebar-panel-header">
		<a href="javascript:;" class="title">
			<i></i>
			<em class="title">我的足迹</em>
		</a>
		<span class="close-panel"></span>
	</h3>
	<div class="sidebar-panel-main">
		<div class="sidebar-panel-content sidebar-historybox-goods-list">
			<!---->
			<!---->
			<!-- 没有浏览历史的展示形式 _start -->
			<div class="tip-box">
				<img src="/static/storeindex/images/noresult.png" class="tip-icon" />
				<div class="tip-text">
					您还没有在商城留下任何足迹哦
					<br />
					<a class="color" href="./">赶快去看看吧</a>
				</div>
			</div>
			<!-- 没有浏览历史的展示形式 _end-->
			<!---->
			<!---->
		</div>
	</div>
</div>
<!---->
			<!--浏览历史 end-->
			<!--对比列表 start-->
			
<!--对比列表 start-->
<div class="right-sidebar-panels sidebar-comparebox">
	<h3 class="sidebar-panel-header">
		<a href="javascript:void(0);" class="title">
			<i class="compare-icon"></i>
			<em class="title">宝贝对比</em>
		</a>
		<span class="close-panel"></span>
	</h3>
	<div>
		<div class="sidebar-panel-main sidebar-comparebox-goods-list">
			
			<div class="sidebar-panel-content compare-panel-content">
				
				<!-- 没有对比商品的展示形式 _start -->
				<div class="tip-box">
					<img src="/static/storeindex/images/noresult.png" class="tip-icon" />
					<div class="tip-text">
						您还没有选择任何的对比商品哦 
						<br />
						<a class="color" href="./">再去看看吧</a>
					</div>
				</div>
				<!-- 没有对比商品的展示形式 _end-->
				
			</div>
		</div>
		
		
	</div>
</div>
<!--对比列表 end-->

			<!--对比列表 end-->
		</div>
	</div>
</div>
<!-- 右侧边栏 _end -->

<!-- 底部 _start-->



<div class="site-footer">
	
	

	

	
	
	<div class="footer-service"><div align="center">
	<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/backend/1/images/2016/11/28/14803038465459.jpg" alt="" height="110" width="1210" /><br />
</div></div>
	
	
	<div class="footer-related">
		
		

		


		
		
		<div class="footer-article w1210">
			<dl class="col-article col-article-spe">
				<dt class="phone color">400-078-5268</dt>
				<dd class="email color">szy@68ecshop.com</dd>
				
				<dd class="customer">
					<span>联系我们</span>
					
					<a href="javascript:void(0);" class="service-online">
						<em class="icon-yw service-online"></em>
					</a>
					
					
					<a target="_blank" href="http://amos.alicdn.com/getcid.aw?v=2&uid=ll4000785268&site=cntaobao&s=2&groupid=0&charset=utf-8">
						<em class="icon-ww"></em>
					</a>
					
					
					<a href="http://wpa.qq.com/msgrd?v=3&uin=800007396&site=qq&menu=yes" target="_blank">
						<em class="icon-kfqq"></em>
					</a>
					
				</dd>
				
			</dl>
			<!---->
			<dl class="col-article col-article-first">
				<dt>新手上路</dt>
				
				<dd>
					
					<a rel="nofollow" href="/help/2.html" target="_blank">购物流程</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/3.html" target="_blank">订单查询</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/4.html" target="_blank">常见问题</a>
					
				</dd>
				<!-- -->
			</dl>
			<!---->
			<dl class="col-article col-article-first">
				<dt>支付方式</dt>
				
				<dd>
					
					<a rel="nofollow" href="/help/5.html" target="_blank">网上支付</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/87.html" target="_blank">货到付款</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/88.html" target="_blank">公司转账</a>
					
				</dd>
				<!-- -->
			</dl>
			<!---->
			<dl class="col-article col-article-first">
				<dt>配送服务</dt>
				
				<dd>
					
					<a rel="nofollow" href="/help/6.html" target="_blank">配送范围及收费标准</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/7.html" target="_blank">订单进度查询</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/8.html" target="_blank">验货与签收</a>
					
				</dd>
				<!-- -->
			</dl>
			<!---->
			<dl class="col-article col-article-first">
				<dt>售后服务</dt>
				
				<dd>
					
					<a rel="nofollow" href="/help/9.html" target="_blank">退换货政策</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/10.html" target="_blank">退换货流程</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/11.html" target="_blank">退款说明</a>
					
				</dd>
				<!-- -->
			</dl>
			<!---->
			<dl class="col-article col-article-first">
				<dt>商家合作</dt>
				
				<dd>
					
					<a rel="nofollow" href="/help/13.html" target="_blank">商家入驻</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/89.html" target="_blank">商家规则</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="http://help.68mall.com/info/110.html" target="_blank">入驻流程</a>
					<!--   -->
				</dd>
				<!-- -->
			</dl>
			<!---->

			<div class="QR-code fr">
				
				
				<ul class="tabs">
					
					<li class="current">APP</li>
					<li >微信</li>
					
				</ul>
				<div class="code-content">
					
					<div class="code">
						<img src="http://images.68mall.com/1737/system/config/mall/app_download_qrcode.png">
					</div>
					
					
					<div class="code hide">
						<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/system/config/mall/mall_wx_qrcode_0.png">
					</div>
					
				</div>
				
				
			</div>
		</div>
		
		
		
		

		
		
		<div class="footer-info">
			<div class="info-text">
				<!-- 底部导航 -->
				<p class="nav-bottom">
					
					
					<a href="https://www.68mall.com/company" target="_blank">公司简介</a>
					
					
					<em>|</em>
					
					<a href="https://www.68mall.com/help/4.html" target="_blank">联系我们</a>
					
					
					<em>|</em>
					
					<a href="http://bbs.68mall.com/" target="_blank">官网论坛</a>
					
					
					<em>|</em>
					
					<a href="https://www.68mall.com/agent.html" target="_blank">代理合作</a>
					
					
					<em>|</em>
					
					<a href="/help/2.html" target="_blank">帮助中心</a>
					
					
					<em>|</em>
					
					<a href="/shop/apply.html" target="_blank">商家入驻</a>
					
					
					<em>|</em>
					
					<a href="https://www.68mall.com/company" target="_blank">联系我们</a>
					
				</p>
				<p>
					Copyright  秦皇岛商之翼(www.68mall.com) 版权所有
					<a href="http://www.miibeian.gov.cn/" target="_blank">冀ICP备07501206号-2</a>
				</p>
				<p class="company-info" style="display: none;">秦皇岛市海港区秦皇半岛二区51号楼3层东侧</p>
				<p class="qualified">
					
					<a href="http://www.68mall.com" target="_blank">
						<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/backend/1/images/2016/11/10/14787661020127.png" alt="" />
					</a>
					
					<a href="http://www.68mall.com" target="_blank">
						<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/backend/1/images/2016/11/10/14787669819785.png" alt="" />
					</a>
					
				</p>
			</div>
			
			<div class="info-text"></div>
			
			<!--<span class="vol">
	<b>Powered by</b>
	<a style="color: #4FC0E8;" href="http://www.68mall.com" target="_blank">商之翼</a>
	· 翼商城
</span>-->
<div class="copyright">
	<p>
		<a href="http://www.68mall.com/statistics.html?product_type=shop&domain=http://bj.68dsw.com" target="_blank" class="copyright-logo">
			<img src="http://bj.68dsw.com/images/power-by-logo.png" />
			提供技术支持
		</a>
	</p>
</div>

			
		</div>
		
	</div>
</div>
<!-- 底部 _end-->

	
</body>
<script src="/static/storeindex/js/shop_index.js?v=20180027"></script>
<script src="/static/storeindex/js/jquery.fly.min.js?v=20180027"></script>
<script src="/static/storeindex/js/szy.cart.js?v=20180027"></script>
<script type="text/javascript">
$().ready(function(){
	// 缓载图片
	$.imgloading.loading();
	//图片预加载
	document.onreadystatechange = function() {
		 if (document.readyState == "complete") {
				$.imgloading.setting({
					threshold: 1000
				});
				$.imgloading.loading();
		 }
	}
});
</script>
</html>