<!DOCTYPE html>
<html lang="zh-CN">
<?php echo $__env->make('common.link', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="style-seller">
	
	<?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<!--中间内容-->
	<div class="seller-center">
		<div class="wrapper">
			
			<?php echo $__env->make('common.slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
			<!--右侧内容-->
			<div class="seller-rihgt">
				<div class="seller-page">
					<div class="seller-page-bg"></div>
					<!--在这里调用内容-->
					<link rel="stylesheet" href="/static/css/styles.css?v=20181020"/>
<div class="page">
	<div class="fixed-bar">
	<div class="item-title">
		<div class="subject">
			<h3>
				<span class="action">运费设置 - 列表</span>
				<!--帮助教程-->
                <!--<a class="help-href" href="javascript:;" data-toggle="tooltip" data-placement="auto bottom" title="点击跳转到该模块教程页面"><i class="help-icon"></i></a>-->
                <!---->
			</h3>
			
			<h5>
				
								
								<!-- <span class="action-span">
													
										
													<a  href="#" class="btn btn-warning click-loading">
														<i class="fa fa-map-marker"></i>
														添加同城运费模板
													</a>
												</span> -->
								<span class="action-span">
					
										
					<a  href="add" class="btn btn-warning click-loading">
						<i class="fa fa-globe"></i>
						添加全国运费模板
					</a>
				</span>
				
			</h5>
			
						<ul class="tab-base shop-row">
								<li>
										<a class="current" data-tab-id="tab_1" data-tab-current="true">
						<span>运费模板列表</span>
					</a>
									</li>
								<!-- <li>
										<a href="/shop/freight/default.html" onClick="if($.loading){ $.loading.start(); }" data-tab-id="tab_2">
														<span>店铺统一运费</span>
													</a>
									</li> -->
								<!-- <li>
										<a href="/shop/freight/calculate.html" onClick="if($.loading){ $.loading.start(); }" data-tab-id="tab_3">
														<span>运费模拟计算</span>
													</a>
									</li> -->
				
			</ul>
					</div>
	</div>
</div>
<div class="titleBar-box">
	<a class="btn btn-default dropdown-toggle" id="dropdownTab" data-toggle="dropdown">
		主题
		<span class="caret"></span>
	</a>
	<ul class="dropdown-menu flipInX animated" role="menu" aria-labelledby="dropdownTab">
				<li role="presentation">
			<a href="" data-tab-id="tab_1">运费模板列表</a>
		</li>
				 <!--<li role="presentation">
							<a href="/shop/freight/default.html" data-tab-id="tab_2">店铺统一运费</a>
						 </li>
				<li role="presentation">
							<a href="/shop/freight/calculate.html" data-tab-id="tab_3">运费模拟计算</a>
						</li> -->
		
	</ul>

</div>
 
	
	
<div class="explanation m-b-10">
	<div class="title explain-checkZoom" title="">
		<i class="fa fa-bullhorn"></i>
		<h4>温馨提示</h4>
	</div>
	<ul class="explain-panel">
				<li>
			<span>全国运费模板：适合配送指定省市区县以及在“地区管理”模块中自定义的地区</span>
		</li>
				<li>
			<span>同城运费模板：有地图划定区域和有超区自动校验，适合配送范围内地图信息完善的地区</span>
		</li>
				<li>
			<span>运费模板：是为一批商品设置同一个运费，当需要修改运费时，这些关联的商品的运费将一起被修改</span>
		</li>
				<li>
			<span>运费模板设置，是为第三方快递、自行配送等配送方式共用的运费模板</span>
		</li>
				<li>
			<span>发布商品时，需关联运费模板；会员购买商品，会根据当前商品的运费模板售卖区域进行确定有货无货</span>
		</li>
		
	</ul>
</div>

	
	<div id="table_list" class="table-responsive freight">
		
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<table class="table table-hover">
			<!--以下为循环内容-->
			<tbody class="freight">

				<!--运费模板-->
				<tr class="freight-hd">
					<td colspan="6">
						<span class="freight-name">
							<span class="c-blue">
								
								<i class="fa fa-globe" title="<?php echo e($data->title); ?>"></i>
								
								<?php echo e($data->title); ?>

							</span>
							
							<label class="label label-primary m-l-5">包邮 </label>
							
							
							
							
						</span>
						<div class="freight-operate">
							<span class="freight-time">最后编辑时间：<?php echo e(date('Y-m-d H:i:s',$data->update_time)); ?></span>
							<span class="handle">
								
								<!-- <a href="/shop/freight/add.html?id=2595" class="click-loading">复制模板</a> -->
								
								<a href="/store/freight/edit?id=<?php echo e($data->id); ?>" class="click-loading">修改</a>
								<!-- <a href="javascript:void(0);" data-id="<?php echo e($data->id); ?>" class="del border-none">删除</a> -->
							</span>
						</div>
					</td>
				</tr>
				<tr>
					<th class="w300">运送到</th>
					<th>首件(件)</th>
					<th>运费(元)</th>
					<th>续件(件)</th>
					<th>续费(元)</th>
					<th class="w150">货到付款</th>
				</tr>
				<!--运费模板内容-->
				
				<?php $__currentLoopData = $data->record; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td title="">
						<?php if($record->is_default): ?>
						<b>默认</b>
						<?php else: ?>
						<?php echo e($record->region_names); ?>

						<?php endif; ?>
					</td>
					<td><?php echo e($record->start_num); ?></td>
					<td><?php echo e($record->start_money); ?></td>
					<td><?php echo e($record->plus_num); ?></td>
					<td><?php echo e($record->plus_money); ?></td>
					<td>
						<?php if($record->is_cash=='0'): ?>
						不支持
						<?php else: ?>
						支持
						<?php endif; ?>
						
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<!-- <table class="table table-hover">
			以下为循环内容
			<tbody class="freight">
				运费模板
				<tr class="freight-hd">
					<td colspan="6">
						<span class="freight-name">
							<span class="c-blue">
								
								<i class="fa fa-map-marker" title="高级版运费模板"></i>
								
								上海市
							</span>
							
							<label class="label label-primary m-l-5">包邮 </label>
							
							
							
							
						</span>
						<div class="freight-operate">
							<span class="freight-time">最后编辑时间：2017-05-03 10:43:56</span>
							<span class="handle">
								
								<a href="/shop/freight/map-add.html?id=2594" class="click-loading">复制模板</a>
								
								<a href="/shop/freight/edit.html?id=2594" class="click-loading">修改</a>
								<a href="javascript:void(0);" data-id="2594" class="del border-none">删除</a>
							</span>
						</div>
					</td>
				</tr>
				<tr>
					<th class="w300">运送到</th>
					<th>首件(件)</th>
					<th>运费(元)</th>
					<th>续件(件)</th>
					<th>续费(元)</th>
					<th class="w150">货到付款</th>
				</tr>
				运费模板内容
				
				
				<tr>
					<td title="">
						
						<b>默认</b>
						
					</td>
					<td>1.0</td>
					<td>0.00</td>
					<td>1.0</td>
					<td>0.00</td>
					<td>
						
						不支持
						
					</td>
				</tr>
				
				
				
				<tr>
					<td title="区域1">
						
						区域1
						
						<i class="c-blue m-l-5 fa fa-exclamation-circle goods-reason" title="上海市嘉定区江桥镇曹安公路2038号华拓大厦附近" style="cursor: pointer;"></i>
						
						
					</td>
					<td>1.0</td>
					<td>0.00</td>
					<td>1.0</td>
					<td>0.00</td>
					<td>
						
						支持,需加价：0.00元
						
					</td>
				</tr>
				
				
			</tbody>
		</table> -->
		
		<!-- -->
        <table class="table b-n">
			<tfoot>
				<tr>
					<td class="b-n">
						<div class="pull-right">
							
							
<div id="pagination">
	<script data-page-json="true" type="text">
	{"page_key":"page","page_id":"pagination","default_page_size":10,"cur_page":1,"page_size":10,"page_size_list":[10,50,500,1000],"record_count":2,"page_count":1,"offset":0,"url":null,"sql":null}
</script>
	
	
	<!-- <div class="pagination-info">
		共2条记录，每页显示：
		<select class="select m-r-5" data-page-size="10">
			
			
			<option value="10" selected="selected">10</option>
			
			
			
			<option value="50">50</option>
			
			
			
			<option value="500">500</option>
			
			
			
			<option value="1000">1000</option>
			
			
		</select>
		条
	</div> -->
	
	<?php if($count>10): ?>
		<?php echo $data->links(); ?>

	<?php endif; ?>
	
	<!-- <div class="pagination-goto">
		<input class="ipt form-control goto-input" type="text">
		<button class="btn btn-default goto-button" title="点击跳转到指定页面">GO</button>
		<a class="goto-link" data-go-page="" style="display: none;"></a>
	</div> -->
	<script type="text/javascript">
		$().ready(function() {
			$(".pagination-goto > .goto-input").keyup(function(e) {
				$(".pagination-goto > .goto-link").attr("data-go-page", $(this).val());
				if (e.keyCode == 13) {
					$(".pagination-goto > .goto-link").click();
				}
			});
			$(".pagination-goto > .goto-button").click(function() {
				var page = $(".pagination-goto > .goto-link").attr("data-go-page");
				if ($.trim(page) == '') {
					return false;
				}
				$(".pagination-goto > .goto-link").attr("data-go-page", page);
				$(".pagination-goto > .goto-link").click();
				return false;
			});
		});
	</script>
	
</div>
						</div>
					</td>
				</tr>
			</tfoot>
		</table>
		
		
	</div>
	
</div>
<script type="text/javascript">
	$().ready(function() {
		var tablelist = $("#table_list").tablelist();
		// 删除记录
		$("body").on('click', '.del', function() {
			var id = $(this).data("id");
			tablelist.remove({
				confirm: '删除运费模板后系统将会自动下架所有绑定此运费模板的商品，这些下架的商品必须重新编辑选择运费模板后才能上架，您确定要继续删除此运费模板吗？',
				url: '/shop/freight/delete',
				data: {
					id: id
				}
			});
		});
	});
</script>
					
				</div>
			</div>
		</div>
		<!--底部内容-->
		<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>

<script type="text/javascript">
function toFirst(target){
	var url = $(target).parents("li").find(".sub-list").find("li:first").find("a").attr("href");
	$.go(url);
}
function to(url, target){
	
}

function clearCache(){
	// 缓载
	$.loading.start();
	$.post("/site/clear-cache", {}, function(result){
		if(result.code == 0){
			$.msg(result.message);
		}else{
			$.msg(result.message, {
				time: 5000
			});
		}
	}).always(function(){
		$.loading.stop();
	});
}
// 登录成功关闭弹出框
$.login.success = function(){
	// 关闭并销毁登录窗口
	$.login.close(true);
}
</script>

<script type="text/javascript">
	// setInterval("auto_print()",10000);
	function auto_print(order_id)
	{
		$.ajax({
			type: "GET",
			url: "/site/auto-print",
			dataType: "json",
			data: {
				order_id: order_id
			},
			success: function(result) {
				if(result.code == 0)
				{
					lodop_print_html(result.print_title, result.data,result.printer);
				}
			}
		});
	}
</script>

<!-- 加载消息监听js-->
<script src="/assets/d2eace91/js/message/message.js?v=20180027"></script>
<script src="/assets/d2eace91/js/message/messageWS.js?v=20180027"></script>
<script type="text/javascript">
//声音监听
WS_AddUser({
	'user_id': 'shop_1717',
	'url': "ws://push.yunmall.68mall.com:7272",
	'type': "add_user"
}); 
//右下角消息提醒弹窗js
function open_message_box(data) {
	if (!data) {    
		data = {};
    }
	
	var src = window.location.href;
	
	// 如果当前框架中的链接地址和弹框的链接地址一致则不弹框
	if(data.auto_refresh == 1 && data.link && src.indexOf(data.link) != -1){
		
		var contentWindow = window;
		
		if(contentWindow.tablelist){
			contentWindow.tablelist.load({
				page: {
					cur_page: 1
				}
			});
		}else{
			contentWindow.location.reload();
		}
		
		return;
	}
	
	$('.message-pop-box').find('#message-pop-text').html(data.content);
	
	if(data.link){
		$('.message-pop-box').find('.message-btn').attr('href', data.link).show();
	}else{
		$('.message-pop-box').find('.message-btn').hide();
	}
	
	if(data.content || data.link){
		$('.message-pop-box').removeClass('down').addClass('up');
	}
	
	try {
		if(refresh_order && typeof(refresh_order) == "function") { 
			refresh_order();
        } 
    } catch(e) {}
}
$('.message-pop-box .close').click(function() {
	$('.message-pop-box').removeClass('up').addClass('down');
});
//用户信息
$(".admin").mouseenter(function() {
	window.focus();
	$("#admin-panel").show();
}).mouseleave(function() {
	$("#admin-panel").hide();
});
</script>
<script type="text/javascript">
	var clipboard = new Clipboard('.btn-copy');
    clipboard.on('success', function(e) {
        $.msg('复制成功');
    });
    clipboard.on('error', function(e) {
    	$.msg('复制失败');
    });
 	// 更新后台主框架消息弹窗
	function update_message() {
		// 是否重新获取数据
		if ($("#message-panel").html().length > 0) {
			// if (parseInt($("#counts_all").val()) != 0) {
			var time_step = 5; // 最小刷新间隔，单位：秒
			var this_time = new Date();
			if ((parseInt($("#counts_time").val()) + parseInt(time_step)) > parseInt(this_time.getTime() / 1000)) {
				return true;
			}
			// }
		}
		$.ajax({
			type: 'GET',
			url: '/site/update-message.html',
			data: {},
			dataType: 'json',
			success: function(result) {
				if (result.code == 0) {
					$("#message-panel").html(result.data);
				} else if (result.code == 1) {
				} else {
					$.msg(result.message);
				}
			}
		});
	}
	// 消息通知
	$("#message-box").mouseenter(function() {
		update_message();
		window.focus();
		$("#message-panel").show();
	}).mouseleave(function() {
		$("#message-panel").hide();
	}).find(".close").click(function() {
		$("#message-panel").hide();
	});
</script>

</html>

