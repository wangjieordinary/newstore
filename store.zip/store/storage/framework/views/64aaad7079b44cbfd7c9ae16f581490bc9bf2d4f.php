<div id="tablelist" class="attachment-box">
	<ul class="image-list">
		<?php $__currentLoopData = $imageslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageslist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<!--点击添加selected样式，则为已选中状态-->
		<li class="image-item" title="上传时间：<?php echo e(date('Y-m-d H:i:s', $imageslist->add_time)); ?>" data-id="<?php echo e($imageslist->id); ?>">
			<img class="image-box" src="<?php echo e($imageslist->image_url); ?>" data-path="<?php echo e($imageslist->image_url); ?>" data-url="<?php echo e($imageslist->image_url); ?>" data-width="<?php echo e($imageslist->width); ?>" data-height="<?php echo e($imageslist->height); ?>" />
			<div class="image-meta"><?php echo e($imageslist->width); ?>*<?php echo e($imageslist->height); ?></div>
			<div class="image-title"><?php echo e($imageslist->title); ?></div>
			<div class="attachment-selected"><i class="fa fa-check"></i></div>
		</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
		<!--分页-->
		<div class="text-r page-box">
			<div id="pagination">
				<script data-page-json="true" type="text">
				{"page_key":"page","page_id":"pagination","default_page_size":10,"cur_page":<?php echo e($page); ?>,"page_size":"10","page_size_list":[10,50,500,1000],"record_count":7,"page_count":1,"offset":<?php echo e($offset); ?>,"url":null,"sql":null}</script>
				<ul class="pagination">
					<li class="disabled" style="display: none;">
						<a class="fa fa-angle-double-left" data-go-page="1" title="第一页"></a>
					</li>
					<li class="disabled">
						<a class="fa fa-angle-left" title="上一页"></a>
					</li>
					<!--   -->
					<?php for($i=1;$i<=$pagestr;$i++): ?>
									<?php if($page==$i): ?>{
										<li class="active">
											<a data-cur-page="<?php echo e($i); ?>"><?php echo e($i); ?></a>
										</li>
									<?php else: ?>
										<li>
										<a href="javascript:void(0);" data-go-page="<?php echo e($i); ?>"><?php echo e($i); ?></a>
										</li>
									<?php endif; ?>
								<?php endfor; ?>
					<li class="disabled">
						<a class="fa fa-angle-right" title="下一页"></a>
					</li>
					<li class="disabled" style="display: none;">
						<a class="fa fa-angle-double-right" data-go-page="1" title="最后一页"></a>
					</li>
				</ul>
			</div>
		</div>
	</div>