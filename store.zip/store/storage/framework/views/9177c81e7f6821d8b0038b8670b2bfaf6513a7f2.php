<!DOCTYPE html>
<!--[if IE 8]> <html lang="zh-CN" class="ie8"> <![endif]-->
<html lang="zh-CN">
<?php echo $__env->make('common.link', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="style-seller">
	
	<?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<!--中间内容-->
	<div class="seller-center">
		<div class="wrapper">
			
			<!--左侧部分-->
			<?php echo $__env->make('common.slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
			<!--右侧内容-->
			<div class="seller-rihgt">
				<div class="seller-page">
					<div class="seller-page-bg"></div>
					<!--在这里调用内容-->
					<link rel="stylesheet" href="/static/css/styles.css?v=20181020"/>
<div class="page">
	<div class="fixed-bar">
	<div class="item-title">
		<div class="subject">
			<h3>
				<span class="action">发布商品 - 成功</span>
				<!--帮助教程-->
                <!--<a class="help-href" href="javascript:;" data-toggle="tooltip" data-placement="auto bottom" title="点击跳转到该模块教程页面"><i class="help-icon"></i></a>-->
                <!---->
			</h3>
			
			<h5>
				
								
								<span class="action-span">
					
										
					<a  href="<?php echo e(url('store/goods/list')); ?>" class="btn btn-warning click-loading">
						<i class="fa fa-reply"></i>
						返回商品列表
					</a>
				</span>
								<span class="action-span">
					
										
					<a id='btn_view' href="javascript:void(0);" class="btn btn-warning ">
						<i class="fa fa-th-large"></i>
						查看商品
					</a>
				</span>
				
			</h5>
			
						<ul class="tab-base shop-row">
								<!-- <li>
										<a href="edit.html?id=<?php echo e($goods_id); ?>" onClick="if($.loading){ $.loading.start(); }" data-tab-id="tab_goods">
														<span>编辑商品</span>
													</a>
									</li> -->
								<!-- <li>
										<a href="edit-images.html?id=<?php echo e($goods_id); ?>" onClick="if($.loading){ $.loading.start(); }" data-tab-id="tab_image">
														<span>编辑图片</span>
													</a>
									</li> -->
								<!-- <li>
										<a href="edit-gift.html?id=<?php echo e($goods_id); ?>" onClick="if($.loading){ $.loading.start(); }" data-tab-id="tab_gift">
																<span>赠送赠品</span>
															</a>
									</li> -->
								<!-- <li>
										<a class="current" data-tab-id="tab_gift" data-tab-current="true">
														<span>发布成功</span>
													</a>
									</li> -->
				
			</ul>
					</div>
	</div>
</div>
<!-- <div class="titleBar-box">
	<a class="btn btn-default dropdown-toggle" id="dropdownTab" data-toggle="dropdown">
		主题
		<span class="caret"></span>
	</a>
	<ul class="dropdown-menu flipInX animated" role="menu" aria-labelledby="dropdownTab">
				<li role="presentation">
			<a href="edit.html?id=40163" data-tab-id="tab_goods">编辑商品</a>
		</li>
				<li role="presentation">
			<a href="edit-images.html?id=40163" data-tab-id="tab_image">编辑图片</a>
		</li>
				<li role="presentation">
			<a href="edit-gift.html?id=40163" data-tab-id="tab_gift">赠送赠品</a>
		</li>
				<li role="presentation">
			<a href="edit-gift.html?id=40163" data-tab-id="tab_gift">发布成功</a>
		</li>
		
	</ul>

</div> -->
 
	<div class="table-content">
		<!--步骤-->
		<ul class="add-goods-step">
	<li id="step_1">
		<i class="fa fa-list-alt step"></i>
		<h6>STEP.1</h6>
		<h2>选择商品分类</h2>
		<i class="fa fa-angle-right"></i>
	</li>
	<li id="step_2">
		<i class="fa fa-edit step"></i>
		<h6>STEP.2</h6>
		<h2>填写商品详情</h2>
		<i class="fa fa-angle-right"></i>
	</li>
	<li id="step_3">
		<i class="fa fa-image step"></i>
		<h6>STEP.3</h6>
		<h2>上传商品图片</h2>
		<i class="fa fa-angle-right"></i>
	</li>
	<li id="step_4">
		<i class="fa fa-check-square-o step"></i>
		<h6>STEP.4</h6>
		<h2>商品发布成功</h2>
	</li>
</ul>
<script type="text/javascript">
$().ready(function(){
	$("#step_4").addClass("current");
});
</script>
		<div class="content">
			<div class="goods-info-four">
				<div class="issued-success">
					<h2>
						<i class="fa fa-check-circle-o m-r-10"></i>
						恭喜您，商品发布成功！
					</h2>
					<div class="issued-success-content m-t-20">
						<p>
							<a class="add-gift" href="<?php echo e(url('store/goods/add')); ?>">
								<i class="fa fa-plus"></i>
								继续添加商品
							</a>
						</p>
						<p class="page-jump">
							<a class="c-blue m-r-20" href="#" target="_blank">去店铺查看商品详情&gt;&gt;</a>
							<!-- <a class="c-blue" href="/goods/publish/edit-gift.html?id=40163&ref_url=/goods/default/onsale">为此商品添加赠品&gt;&gt;</a> -->
						</p>
						<h5 style="display: none">您还可以:</h5>
						<ul class="" style="display: none">
							<li>
								1. 继续 "
								<a href="/goods/publish/edit.html?id=40163" class="c-blue">重新编辑刚发布的商品</a>
								"
							</li>
							<li>
								2. 进入 " 商家中心" 管理 "
								<a href="/goods/list.html" class="c-blue">出售中的商品</a>
								"
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$("#btn_view").click(function() {
		$.go("http://www.68dsw.com/goods-40163.html", "_blank");
	});
</script>
					
				</div>
			</div>
		</div>
		<!--底部内容-->
		<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>

<script type="text/javascript">
function toFirst(target){
	var url = $(target).parents("li").find(".sub-list").find("li:first").find("a").attr("href");
	$.go(url);
}
function to(url, target){
	
}

function clearCache(){
	// 缓载
	$.loading.start();
	$.post("/site/clear-cache", {}, function(result){
		if(result.code == 0){
			$.msg(result.message);
		}else{
			$.msg(result.message, {
				time: 5000
			});
		}
	}).always(function(){
		$.loading.stop();
	});
}
// 登录成功关闭弹出框
$.login.success = function(){
	// 关闭并销毁登录窗口
	$.login.close(true);
}
</script>

<script type="text/javascript">
	// setInterval("auto_print()",10000);
	function auto_print(order_id)
	{
		$.ajax({
			type: "GET",
			url: "/site/auto-print",
			dataType: "json",
			data: {
				order_id: order_id
			},
			success: function(result) {
				if(result.code == 0)
				{
					lodop_print_html(result.print_title, result.data,result.printer);
				}
			}
		});
	}
</script>

<!-- 加载消息监听js-->
<script src="/assets/d2eace91/js/message/message.js?v=20180027"></script>
<script src="/assets/d2eace91/js/message/messageWS.js?v=20180027"></script>
<script type="text/javascript">
//声音监听
WS_AddUser({
	'user_id': 'shop_1717',
	'url': "ws://push.yunmall.68mall.com:7272",
	'type': "add_user"
}); 
//右下角消息提醒弹窗js
function open_message_box(data) {
	if (!data) {    
		data = {};
    }
	
	var src = window.location.href;
	
	// 如果当前框架中的链接地址和弹框的链接地址一致则不弹框
	if(data.auto_refresh == 1 && data.link && src.indexOf(data.link) != -1){
		
		var contentWindow = window;
		
		if(contentWindow.tablelist){
			contentWindow.tablelist.load({
				page: {
					cur_page: 1
				}
			});
		}else{
			contentWindow.location.reload();
		}
		
		return;
	}
	
	$('.message-pop-box').find('#message-pop-text').html(data.content);
	
	if(data.link){
		$('.message-pop-box').find('.message-btn').attr('href', data.link).show();
	}else{
		$('.message-pop-box').find('.message-btn').hide();
	}
	
	if(data.content || data.link){
		$('.message-pop-box').removeClass('down').addClass('up');
	}
	
	try {
		if(refresh_order && typeof(refresh_order) == "function") { 
			refresh_order();
        } 
    } catch(e) {}
}
$('.message-pop-box .close').click(function() {
	$('.message-pop-box').removeClass('up').addClass('down');
});
//用户信息
$(".admin").mouseenter(function() {
	window.focus();
	$("#admin-panel").show();
}).mouseleave(function() {
	$("#admin-panel").hide();
});
</script>
<script type="text/javascript">
	var clipboard = new Clipboard('.btn-copy');
    clipboard.on('success', function(e) {
        $.msg('复制成功');
    });
    clipboard.on('error', function(e) {
    	$.msg('复制失败');
    });
 	// 更新后台主框架消息弹窗
	function update_message() {
		// 是否重新获取数据
		if ($("#message-panel").html().length > 0) {
			// if (parseInt($("#counts_all").val()) != 0) {
			var time_step = 5; // 最小刷新间隔，单位：秒
			var this_time = new Date();
			if ((parseInt($("#counts_time").val()) + parseInt(time_step)) > parseInt(this_time.getTime() / 1000)) {
				return true;
			}
			// }
		}
		$.ajax({
			type: 'GET',
			url: '/site/update-message.html',
			data: {},
			dataType: 'json',
			success: function(result) {
				if (result.code == 0) {
					$("#message-panel").html(result.data);
				} else if (result.code == 1) {
				} else {
					$.msg(result.message);
				}
			}
		});
	}
	// 消息通知
	$("#message-box").mouseenter(function() {
		update_message();
		window.focus();
		$("#message-panel").show();
	}).mouseleave(function() {
		$("#message-panel").hide();
	}).find(".close").click(function() {
		$("#message-panel").hide();
	});
</script>

</html>

