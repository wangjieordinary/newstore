			<!--左侧部分-->
			<div class="seller-left">
				<!--搜索-->
				<div class="search">
					<div class="search-bar">
						<!--这里搜索-->
						<form action="/goods/list/index.html" method="GET" target="_blank">
							<input class="search-input-text" placeholder="商城商品搜索" type="text" name="keyword">
							<a class="search-input-btn" href="javascript:void(0);" title="点击进行搜索" onclick="$(this).parents('form').submit()">
								<i class="fa fa-search"></i>
							</a>
						</form>
					</div>
				</div>

				<!--左侧导航-->
				<ul class="left-menu">
					<!--当首页选中的时候，这块显示添加常用功能菜单按钮，点击弹出选择常用功能菜单,最多可选择10个；选择完毕后，以下面的li标签内容显示，添加按钮则隐藏-->
					<div class="add-quickmenu" style="display: none">
						<a href="javascript:;" title="添加常用功能菜单" data-toggle="modal" data-target="#allModal">
							<i class="fa fa-plus"></i>
							添加常用功能菜单
						</a>
					</div>
					<li <?php if(in_array($position,['goods-index','goods_edit'])): ?> class="selected" <?php endif; ?>">
						
						<a href="<?php echo e(url('store/goods/list')); ?>" data-menus="goods|goods-list">商品管理</a>
						
					</li>			
					<li <?php if($position=='goods-publish'): ?> class="selected" <?php endif; ?>>
						
						<a href="<?php echo e(url('store/goods/add')); ?>" data-menus="goods|goods-publish">发布商品</a>
						
					</li>		
					<li <?php if($position=='goods-cate'): ?> class="selected" <?php endif; ?>>
						
						<a href="<?php echo e(url('store/category/list')); ?>" data-menus="goods|goods-category-list">店铺商品分类</a>
						
					</li>		
					<li <?php if($position=='goods-spec'): ?> class="selected" <?php endif; ?>>
						
						<a href="<?php echo e(url('store/spec/list')); ?>" data-menus="goods|goods-spec-list">规格管理</a>
						
					</li>		
					<li <?php if($position=='goods-freight'): ?> class="selected" <?php endif; ?>>
						<a href="<?php echo e(url('store/freight/list')); ?>" data-menus="goods|shop-freight-list">运费设置</a>
					</li>		
					<!-- <li class="<?php if(Request::path() == 'store/images_dir/list'): ?> selected <?php endif; ?>">
						<a href="<?php echo e(url('store/images_dir/list')); ?>" data-menus="goods|goods-image-dir-list">图片空间</a>
					</li>		
					<li class="<?php if(Request::path() == 'store/goodsset/list'): ?> selected <?php endif; ?>">
						<a href="<?php echo e(url('store/goodsset/list')); ?>" data-menus="goods|goods-set">商品设置</a>
					</li>		
					<li class="<?php if(Request::path() == 'store/trash/list'): ?> selected <?php endif; ?>">
						<a href="<?php echo e(url('store/trash/list')); ?>" data-menus="goods|goods-pictures-recover">回收站</a>
					</li> -->
					
					
					<!--分割线-->
					<!--      <li class="line"></li> -->
				</ul>
			</div>