	<!--[if IE]>
	<div class="ie-warning">什么？您还在使用 Internet Explorer (IE) 浏览器？ 很遗憾，我们已不再支持IE浏览器。事实上，升级到以下支持HTML5的浏览器将获得更牛逼的操作体验：<a href="http://www.mozillaonline.com/">Firefox</a> / <a href="http://www.google.com/chrome/?hl=zh-CN">Chrome</a> / <a href="http://www.apple.com.cn/safari/">Safari</a> / <a href="http://www.operachina.com/">Opera</a>，
	赶紧升级浏览器，让操作效率提升80%-120%！
	</div>
	<style type="text/css">
	.style-seller .ie-warning{ position:fixed; top:0px; }
	.style-seller .seller-head{ top:38px;}
	.style-seller .seller-center,.style-seller .seller-left{ padding-top:38px}
	</style>
	<![endif]-->
	<!--顶部导航-->
	<div class="seller-head">
		<!--导航-->
		<div class="seller-nav">
			<div class="site-nav-content wrapper">
				<div class="seller-logo">
					<a href="<?php echo e(env('APP_URL')); ?>" target="_blank">
						<img src="/static/images/seller_center_logo_0.png">
					</a>
					<h1 class="hide">卖家中心</h1>
				</div>
				<div class="seller-nav-list">
					<ul>
						<li data-param="index" <?php if($position=='index-index'): ?> class="active" <?php endif; ?>>
							<a href="<?php echo e(env('APP_URL')); ?>" target="_top" data-menus="index">
								<em>首页</em>
							</a>
							<b class="arrow"></b>
							<div class="sub-list">
								<ul>
									<li>
										<a href="<?php echo e(env('APP_URL')); ?>" data-menus="index|index-welcome" target="">欢迎页</a>
									</li>
									<!-- <li>
										<a href="/index/index/guide" data-menus="index|index-guide" target="">新手向导</a>
									</li> -->
								</ul>
							</div>
						</li>
						<li data-param="goods" <?php if(in_array($position,['goods-index','goods-publish','goods-cate','goods_edit'])): ?> class="active" <?php endif; ?>>
							<a href="javascript:void(0);" target="_top" data-menus="goods">
								<em>商品</em>
							</a>
							<b class="arrow"></b>
							<div class="sub-list">
								<ul>
									<li <?php if($position=='goods_edit'): ?> class="selected" <?php endif; ?>>
										<a href="<?php echo e(url('store/goods/list')); ?>" data-menus="goods|goods-list" target="">商品管理</a>
									</li>
									<li>
										<a href="<?php echo e(url('store/goods/add')); ?>" data-menus="goods|goods-publish" target="">发布商品</a>
									</li>
									<!-- <li>
										<a href="/goods/cloud/cloud-manage.html" data-menus="goods|goods-cloud-manage" target="">数据采集</a>
									</li> -->
									<li>
										<a href="<?php echo e(url('store/category/list')); ?>" data-menus="goods|goods-category-list" target="">店铺商品分类</a>
									</li>
									<li>
										<a href="<?php echo e(url('store/spec/list')); ?>" data-menus="goods|goods-spec-list" target="">规格管理</a>
									</li>
									<li>
										<a href="<?php echo e(url('store/freight/list')); ?>" data-menus="goods|shop-freight-list" target="">运费设置</a>
									</li>
									<!-- <li>
										<a href="/goods/image-dir/list.html" data-menus="goods|goods-image-dir-list" target="">图片空间</a>
									</li>
									<li>
										<a href="/goods/goods-set/index.html" data-menus="goods|goods-set"  target="">商品设置</a>
									</li>
									<li>
										<a href="/goods/list/trash.html" data-menus="goods|goods-pictures-recover" target="">回收站</a>
									</li> -->
								</ul>
							</div>
						</li>
						<li data-param="trade" class="">
							<a href="javascript:void(0);" target="_top" data-menus="trade">
								<em>交易</em>
							</a>
							<b class="arrow"></b>
							<div class="sub-list">
								<ul>
									<!-- <li>
										<a href="/shop/config/index.html?group=trade" data-menus="trade|trade-set" target="">交易设置</a>
									</li> -->
									<li>
										<a href="<?php echo e(url('store/order/list')); ?>" data-menus="trade|trade-order-list" target="">订单管理</a>
									</li>
									<!-- <li>
																			<a href="<?php echo e(url('store/delivery/list')); ?>" data-menus="trade|trade-delivery-list" target="">发货单管理</a>
																		</li> -->									
									<!-- <li>
										<a href="/trade/back/list" data-menus="trade|trade-back-list" target="">退款/退货管理</a>
									</li>
									<li>
										<a href="/trade/back/list?is_after_sale=1" data-menus="trade|trade-after-sale-list" target="">售后管理</a>
									</li>
									<li>
										<a href="/trade/complaint/list" data-menus="trade|trade-complaint-manage" target="">投诉管理</a>
									</li>
									<li>
										<a href="/trade/service/evaluate-buyer-list" data-menus="trade|trade-evaluate-buyer-list" target="">评价管理</a>
									</li> -->
								</ul>
							</div>
						</li>
						<!-- <li data-param="dashboard" class="">
							<a href="javascript:void(0);" target="_top" data-menus="dashboard">
								<em>营销</em>
							</a>
							<b class="arrow"></b>
							<div class="sub-list">
								<ul>
									<li>
										<a href="/dashboard/center/index" data-menus="dashboard|dashboard-center" target="">营销中心</a>
									</li>
								</ul>
							</div>
						</li>
						<li data-param="member" class="">
							<a href="javascript:void(0);" target="_top" data-menus="member">
								<em>会员</em>
							</a>
							<b class="arrow"></b>
							<div class="sub-list">
								<ul>
									<li>
										<a href="/member/member/user-list.html?type=1&amp;order=1" data-menus="member|member-list" target="">会员列表</a>
									</li>
									<li>
										<a href="/member/rank/list.html" data-menus="member|member-level" target="">会员等级</a>
									</li>
								</ul>
							</div>
						</li>						
						<li data-param="shop" class="">
							<a href="javascript:void(0);" target="_top" data-menus="shop">
								<em>店铺</em>
							</a>
							<b class="arrow"></b>
							<div class="sub-list">
								<ul>
									<li>
										<a href="/shop/shop-set/edit" data-menus="shop|shop-set" target="">店铺设置</a>
									</li>
									<li>
										<a href="/shop/shop-info/shop-info" data-menus="shop|shop-info" target="">店铺信息</a>
									</li>
									<li>
										<a href="/shop/print-spec/list" data-menus="shop|shop-print-spec" target="">打印设置</a>
									</li>
									<li>
										<a href="/shop/shipping/self.html" data-menus="shop|shop-express-list" target="">配送方式</a>
									</li>
									<li>
										<a href="/shop/contract/list" data-menus="shop|shop-shop-contract" target="">保障服务</a>
									</li>
									<li>
										<a href="/goods/self-pickup/list.html" data-menus="shop|self-pickup" target="">上门自提</a>
									</li>
									<li>
										<a href="/article/article/list" data-menus="shop|shop-article-list" target="">文章列表</a>
									</li>									
									<li>
										<a href="/shop/navigation/list" data-menus="shop|shop-navigation" target="">店铺导航</a>
									</li>
									<li>
										<a href="/design/tpl-setting/setup?page=shop" data-menus="shop|shop-design" target="_blank">店铺装修</a>
									</li>
									<li>
										<a href="/oauth/oauth/index.html" data-menus="shop|shop-oauth" target="">授权周边系统</a>
									</li>
								</ul>
							</div>
						</li>
						
						<li data-param="store" class="">
							<a href="javascript:void(0);" target="_top" data-menus="store" onclick="toFirst(this)">
								<em>网点</em>
							</a>
							<b class="arrow"></b>
							<div class="sub-list">
								<ul>
									<li>
										<a href="/store/default/list" data-menus="store|store-list" onclick="to(&#39;/store/default/list&#39;, this)" target="">线下网点管理</a>
									</li>
									<li>
										<a href="/store/group/list" data-menus="store|store-group-list" onclick="to(&#39;/store/group/list&#39;, this)" target="">网点分组管理</a>
									</li>
									<li>
										<a href="/store/trade/list" data-menus="store|store-trade-list" onclick="to(&#39;/store/trade/list&#39;, this)" target="">网点销售统计</a>
									</li>
								</ul>
							</div>
						</li>
						
						<li data-param="account" class="">
							<a href="javascript:void(0);" target="_top" data-menus="account" onclick="toFirst(this)">
								<em>账号</em>
							</a>
							<b class="arrow"></b>
							<div class="sub-list">
								<ul>
									<li>
										<a href="/shop/account/list" data-menus="account|shop-account" onclick="to(&#39;/shop/account/list&#39;, this)" target="">帐号管理</a>
									</li>
									<li>
										<a href="/shop/config/index.html?group=aliim" data-menus="account|shop-config-aliim" onclick="to(&#39;/shop/config/index.html?group=aliim&#39;, this)" target="">阿里云旺</a>
									</li>
									<li>
										<a href="/shop/customer-type/list" data-menus="account|shop-customer-type-list" onclick="to(&#39;/shop/customer-type/list&#39;, this)" target="">客服类型</a>
									</li>
									<li>
										<a href="/shop/customer/list" data-menus="account|shop-customer-list" onclick="to(&#39;/shop/customer/list&#39;, this)" target="">客服管理</a>
									</li>
									<li>
										<a href="/shop/message/index" data-menus="account|shop-message" onclick="to(&#39;/shop/message/index&#39;, this)" target="">系统消息</a>
									</li>
									<li>
										<a href="/shop/log/list" data-menus="account|shop-log-list" onclick="to(&#39;/shop/log/list&#39;, this)" target="">操作日志</a>
									</li>
								</ul>
							</div>
						</li>
						
						
						
						
						
						<li data-param="finance" class="">
							<a href="javascript:void(0);" target="_top" data-menus="finance" onclick="toFirst(this)">
								<em>财务</em>
							</a>
							<b class="arrow"></b>
							<div class="sub-list">
								<ul>
									
									
									<li>
										<a href="/finance/seller-account/list.html" data-menus="finance|finance-seller-account" onclick="to(&#39;/finance/seller-account/list.html&#39;, this)" target="">店铺进出账明细</a>
									</li>
									
									
									
									<li>
										<a href="/finance/bill/shop-bill" data-menus="finance|finance-bill-manager-list" onclick="to(&#39;/finance/bill/shop-bill&#39;, this)" target="">结算管理</a>
									</li>
									
									
									
									<li>
										<a href="/finance/bill/store-bill" data-menus="finance|finance-bill-list" onclick="to(&#39;/finance/bill/store-bill&#39;, this)" target="">网点结算</a>
									</li>
									
									
									
									<li>
										<a href="/finance/account-detail/list.html" data-menus="finance|finance-account-detail" onclick="to(&#39;/finance/account-detail/list.html&#39;, this)" target="">店铺账户明细</a>
									</li>
									
									
								</ul>
							</div>
						</li>
						<li data-param="weixin" class="">
							<a href="javascript:void(0);" target="_top" data-menus="weixin" onclick="toFirst(this)">
								<em>移动端</em>
							</a>
							<b class="arrow"></b>
							<div class="sub-list">
								<ul>
									<li>
										<a href="/shop/weixin-config/index.html" data-menus="weixin|shop-weixin-config" onclick="to(&#39;/shop/weixin-config/index.html&#39;, this)" target="">微信设置</a>
									</li>
									<li>
										<a href="/shop/weixin-menu/list" data-menus="weixin|shop-weixin-menu" onclick="to(&#39;/shop/weixin-menu/list&#39;, this)" target="">自定义菜单</a>
									</li>
									<li>
										<a href="/shop/weixin-keyword/list" data-menus="weixin|shop-weixin-keyword" onclick="to(&#39;/shop/weixin-keyword/list&#39;, this)" target="">关键词回复</a>
									</li>
									<li>
										<a href="/shop/programs-qrcode/list" data-menus="weixin|shop-weixin-programs-qrcode" onclick="to(&#39;/shop/programs-qrcode/list&#39;, this)" target="">小程序码管理</a>
									</li>
								</ul>
							</div>
						</li>						
						<li data-param="statistics" class="">
							<a href="javascript:void(0);" target="_top" data-menus="statistics" onclick="toFirst(this)">
								<em>财务报表</em>
							</a>
							<b class="arrow"></b>
							<div class="sub-list">
								<ul>
									<li>
										<a href="/statistics/data-profiling/index.html" data-menus="statistics|data-profiling"  target="">数据概况</a>
									</li>
									<li>
										<a href="/statistics/sales-statistics/index.html" data-menus="statistics|sales-statistics" target="">营业统计</a>
									</li>
									<li>
										<a href="/statistics/goods-analyse/index.html" data-menus="statistics|goods-analyse" target="">商品分析</a>
									</li>
									<li>
										<a href="/statistics/goods-statistics/sales.html" data-menus="statistics|goods-statistics" target="">单品统计</a>
									</li>
									<li>
										<a href="/statistics/trade-analyse/index.html" data-menus="statistics|trade-analyse" target="">交易分析</a>
									</li>
									<li>
										<a href="/statistics/users-statistics/list.html" data-menus="statistics|users-statistics" target="">会员统计</a>
									</li>
								</ul>
							</div>
						</li> -->
					</ul>
				</div>

				<!--个人信息-->
				<div class="admin">
					<a class="dropdown-toggle">
						<div class="pic" title="[ 店铺 ] ">
							<img src="/static/images/default_user_portrait_0.png">
						</div>
					</a>
					<ul id="admin-panel" class="dropdown-menu dropdown-list right animated fadeInUp">
						<li class="top-dropdown-bg"></li>
						<li class="user-title">
							<h5>
								<span class="user-role m-r-2">[&nbsp;店铺&nbsp;]</span>
								<span class="user-name" title="<?php echo e(session('loginstore')->telephone); ?>">
									
									<?php echo e(session('loginstore')->telephone); ?>

									
								</span>
							</h5>
						</li>
						<li class="divider"></li>
						<li>
							<a href="#" target="_blank">
								<i class="fa fa-home"></i>
								商城首页
							</a>
						</li>
						
						<!-- <li>
							<a href="http://market.68dsw.com/" target="_blank">
								<i class="fa fa-home"></i>
								批发市场
							</a>
						</li>
						
						<li>
							<a href="http://www.68dsw.com/user.html" target="_blank">
								<i class="fa fa-user"></i>
								用户中心
							</a>
						</li> -->
						<!-- <li>
							<a href="http://www.68dsw.com/user/security/edit-password.html" target="_blank">
								<i class="fa fa-lock"></i>
								修改密码
							</a>
						</li> -->
						<li>
							<a href="/user/logout" data-method="get" data-confirm="您确定要退出卖家中心吗？">
								<i class="fa fa-sign-out"></i>
								退出
							</a>
						</li>
					</ul>
				</div>
				<!--右侧菜单-->
				<div class="right-menu">
					<ul>
						<li class="we-chat">
							<a class="go-store dropdown-toggle" href="/storeindex/<?php echo e(session('loginstore')->id); ?>" title="前往店铺" target="_blank">
								<i></i>
								<span>店铺</span>
							</a>
							<div class="we-chat-box dropdown-menu dropdown-list animated fadeInUp">
								<div class="top-dropdown-bg"></div>
								<h5>微信扫码访问</h5>
								<img class="we-chat-img" src="/static/images/showqrcode">
								<div class="we-chat-btn" style="position: relative;">
									<a class="m-r-10 btn-copy" href="/goods/list/index.html#" data-clipboard-text="http://m.68dsw.com/shop/309.html">复制页面链接</a>
									<a class="" href="http://www.68dsw.com/shop/309.html" target="_blank">电脑上查看</a>
								</div>
							</div>
						</li>
						
						<!-- <li>
							<a class="wholesale-market" href="http://market.68dsw.com/" target="_blank" title="批发市场">
								<i></i>
								<span>批发市场</span>
							</a>
						</li>
						
												<li id="message-box" class="top-menu">
							<a class="message-alert" data-toggle="dropdown" title="查看待处理事项">
								<i></i>
								<span>提醒</span>
								<em id="message_logo" style="display: none">0</em>
							</a>
							消息提醒
							<div id="message-panel" class="manager-menu right dropdown-menu animated fadeInDown"></div>
						</li> -->
						<li>
							<a class="wipe-cache" onclick="clearCache()" title="清除缓存">
								<i></i>
								<span>清缓存</span>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>