<!DOCTYPE html>
<!--[if IE 8]> <html lang="zh-CN" class="ie8"> <![endif]-->
<html lang="zh-CN">
<?php echo $__env->make('common.link', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="style-seller">
	
	<?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<!--中间内容-->
	<div class="seller-center">
		<div class="wrapper">
			
			<?php echo $__env->make('common.indexslider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
			<!--右侧内容-->
			<div class="seller-rihgt">
				<div class="seller-page">
					<div class="seller-page-bg"></div>
					<!--在这里调用内容-->
					
<!-- 卖家中心首页样式 -->
<link rel="stylesheet" href="/static/newcss/index.css?v=20181020"/>
<!-- 图表 -->
<script src="/static/newjs/chart.js?v=20180027"></script>
<script src="/static/newjs/chart-data.js?v=20180027"></script>
<div class="page">

	<!-- <div class="alert renew-box hide">
		<a href="#" class="close" data-dismiss="alert"> &times; </a> 
		
		
		<p>
			欢迎使用
			<span class="major-label m-l-5 m-r-5 site_name"></span>
			商城系统，您的店铺即将到期，到期前您还未缴费，将影响您店铺的正常运营，建议尽快进行续费！
		</p>
		<p>
			续费流程：前往店铺->店铺信息->续签日志tab->
			<a class="major-label m-l-5 m-r-5" href="/shop/shop-info/renew-add">添加续签申请</a>
			进行线上缴费，或联系平台方管理员进行缴纳费用！
		</p>
		
		
	</div>-->
	<div class="seller">
		<div class="store-logo">
			<p>
			<?php if($store->storelogo != null): ?>
				<img src="<?php echo e($store->storelogo); ?>">
			<?php else: ?>
				<img src="/static/images/default_user_portrait_0.png">
			<?php endif; ?>
				<!-- <img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/images/2017/05/03/14937788991187.jpg" /> -->
			</p>
			<a href="/shop/shop-set/edit">
				<i class="fa fa-edit"></i>
				编辑店铺设置
			</a>
		</div>
		<div class="store-qrcode">
			<p>
			<?php if($store->qrcode != null): ?>
				<img src="<?php echo e($store->qrcode); ?>">
			<?php else: ?>
				<img src="/static/images/1541036757.png">
			<?php endif; ?>
			</p>
			<a class="btn-link" href="/shop/download-qrcode?shop_id=309"> 下载店铺二维码 </a>
		</div>
		<!-- end -->
		<div class="store-info">
			<h2><?php echo e($store->store_name); ?></h2>
			<ul>
				<li>
					<span>累计信用评价：</span>
					
					<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/system/credit/2016/12/26/14827402454984.gif" height="16" />
					
					
				</li>
				<li>
					<span>用户名：</span>
					<font><?php echo e($store->telephone); ?></font>
				</li>
				
				<li>
					<span>店铺有效期：</span>
					<font><?php echo e($store->validityperiod); ?></font>
				</li>
				
				
				<li>
					<span>上次登录IP：</span>
					<font title="<?php echo e($store->last_login); ?>"><?php echo e($store->last_login); ?></font>
				</li>
				<li>
					<span>上次登录时间：</span>
					<font><?php echo e(date('Y-m-d H:i:s', $store->last_time)); ?></font>
				</li>
				
			</ul>
		</div>
		<div class="store-grade">
			<h3>店铺动态评分</h3>
			<ul>
				<li>
					<div id="container1">
					</div>
					<span>描述相符</span>
				</li>
				<li>
					<div id="container2"></div>

					<span>服务态度</span>
				</li>
				<li>
					<div id="container3"></div>
					<span>发货速度</span>
				</li>
				<li>
					<div id="container4"></div>
					<span>综合评分</span>
				</li>
			</ul>
		</div>
	</div>
	<div class="manage">

		<div class="module goods-manage">
			<h5>商品管理</h5>
			<div class="module-content">
				<ul>
					<li>
						<a href="<?php echo e(url('store/goods/list')); ?>" class="num">
							出售中的商品
							<i id="onsale_goods_count">&nbsp;</i>
						</a>
					</li>
					<li>
						<a href="/goods/list/index.html?status=1" class="num">
							仓库中的商品
							<i id="offsale_goods_count"></i>
						</a>
					</li>
					<li>
						<a href="/goods/list/index.html?status=3" class="num">
							等待审核的商品
							<i id="wait_audit_goods_count"></i>
						</a>
					</li>
					<li>
						<a href="/goods/list/index.html?status=5" class="num">
							违规下架的商品
							<i id="illegal_goods_count"></i>
						</a>
					</li>
				</ul>
			</div>
		</div>
		<div class="module order-remind">
			<h5>订单提醒</h5>
			<div class="module-content">
				<ul>
					<li>
						<a href="/trade/order/list?order_status=unpayed" class="num">
							待付款订单
							<i id="unpayed_order_count"></i>
						</a>
					</li>
					<li>
						<a href="/trade/order/list?order_status=unshipped" class="num">
							待发货订单
							<i id="unshipping_order_count"></i>
						</a>
					</li>
					<li>
						<a href="/trade/order/list?evaluate_status=unevaluate" class="num">
							待评价订单
							<i id="unevaluate_order_count"></i>
						</a>
					</li>
					<li>
						<a href="/trade/order/list?order_status=backing" class="num">
							退款中订单
							<i id="backing_order_count"></i>
						</a>
					</li>
					<li>
						<a href="/trade/back/list?is_after_sale=1" class="num">
							售后退款订单
							<i id="after_sale_order_count"></i>
						</a>
					</li>
					<li>
						<a href="/trade/back/list.html?is_after_sale=1&type=1" class="num">
							换货维修订单
							<i id="exchange_order_count"></i>
						</a>
					</li>
					<!-- 
					<li>
						<a href="/trade/order/list?order_status=" class="num">
							售后中订单
							<i></i>
						</a>
					</li>
					 -->
				</ul>
			</div>
		</div>
		<div class="module illegal-remind">
			<h5>违规提醒</h5>
			<div class="module-content">
				<ul>
					<li>
						<a href="/trade/complaint/list?complaint_status=3" class="num">
							待处理的投诉
							<i id="wait_complaint_count"></i>
						</a>
					</li>
					<li>
						<a href="/trade/complaint/list?complaint_status=4" class="num">
							平台介入的投诉
							<i id="involve_complaint_count"></i>
						</a>
					</li>
				</ul>
			</div>
		</div>
		<div class="module order-remind">
			<h5>
				客户等级分析
				<a class="c-666 pull-right" href="/member/rank/list.html">设置VIP等级</a>
			</h5>
			<div class="module-content m-t-10">
				<div id="customer_div" style="width: 100%; height: 300px;"></div>
			</div>
		</div>
	</div>

	<div class="system">
		<div class="chart-info">
			<h5>今日统计</h5>
			<div class="module-content p-0">
				<ul>
					<li style="width: 34%">
						<div class="value">
							<span>
								今日营业总额
								<i class="fa fa-question-circle" data-toggle="popover" data-trigger="hover" data-placement="top" data-content="在线支付的订单，买家付款后进行统计，如果买家取消订单或卖家发货后，买家申请退款退货，并且退款成功后，统计相应减少；货到付款的订单，买家点击确认收货或卖家点击收到货款后，才进行统计。"></i>
							</span>
							<h4 id="today_gains">&nbsp;</h4>
						</div>

					</li>
					<li style="width: 35%">
						<div class="value">
							<span>
								今日有效订单量
								<i class="fa fa-question-circle" data-toggle="popover" data-trigger="hover" data-placement="top" data-content="在线支付的订单，买家付款后进行统计，如果买家取消订单或卖家发货后，买家申请退款退货，并且退款成功后，统计相应减少；货到付款的订单，买家点击确认收货或卖家点击收到货款后，才进行统计。"></i>
							</span>
							<h4 id="today_order_count">&nbsp;</h4>
						</div>

					</li>
					<li style="width: 28%">
						<div class="value">
							<span>今日添加会员</span>
							<h4 id="today_users_count">&nbsp;</h4>
						</div>
					</li>
				</ul>
			</div>
		</div>
		<!-- <div class="contact-info">
			<h5>平台联系方式</h5>
			<div class="module-content">
				<ul>
					<li>
						<span>电话：400-078-5269</span>
					</li>
					<li>
						<span style="width: 220px">邮件：szy@68ecshop.com</span>
					</li>
					<li>
						<span>QQ：3152659060</span>
					</li>
					<li>
						<span>旺旺：</span>
					</li>
				</ul>
			</div>
		</div>
		
		<div class="contact-info">
			<h5>站点联系方式</h5>
			<div class="module-content">
				<ul>
					<li>
						<span>电话：0335-7106712</span>
					</li>
					<li>
						<span style="width: 220px">邮件：szy@68mall.com</span>
					</li>
					<li>
						<span>QQ：800007396</span>
					</li>
					<li>
						<span>旺旺：szy18830368437</span>
					</li>
				</ul>
			</div>
		</div> -->
		
		<!-- <div class="system-info">
			<div class="tabmenu">
				<ul class="tab">
					<li class="active">
						<a href="#texpress1" data-toggle="tab">商家公告</a>
					</li>
					<li>
						<a href="#texpress2" data-toggle="tab">站内信</a>
					</li>
				</ul>
			</div>
			<div class="tab-content">
				<div id="texpress1" class="tab-pane fade in active">
					<ul>
						
						
						
						
						<li>
							<h2>
								<a href="http://www.68dsw.com/article/91.html" target="_blank">小京东+测试</a>
							</h2>
							<span class="data">5月17日</span>
						</li>
						
						
						
					</ul>
				</div>
				<div id="texpress2" class="tab-pane fade">
					<ul>
						
						
						
						
						<li>
							<h2>
								<a href="javascript:void(0);" class="link" data-msg-id="25154">亲爱的店主，您店铺订单号为：20181029...</a>
							</h2>
							<span class="data">10月29日</span>
						</li>
						
						
						
						
						<li>
							<h2>
								<a href="javascript:void(0);" class="link" data-msg-id="25147">亲爱的店主，您店铺订单号为：20180814...</a>
							</h2>
							<span class="data">8月14日</span>
						</li>
						
						
						
						
						<li>
							<h2>
								<a href="javascript:void(0);" class="link" data-msg-id="25138">亲爱的店主，您店铺订单号为：20180814...</a>
							</h2>
							<span class="data">8月14日</span>
						</li>
						
						
						
						
						
						<li class="text-c m-t-10">
							<a class="btn-link" href="/shop/message/index">查看更多</a>
						</li>
						
					</ul>
				</div>
			</div>
		</div> -->
		<div class="order-ranking">
			<h5>
				销售情况统计
				<span>( 近10天 )</span>
			</h5>
			<div class="module-content m-t-10">
				<div id="sales_div" style="width: 100%; height: 300px;"></div>
			</div>
		</div>
	</div>
	<div class="clear"></div>
</div>
<div class="clear"></div>
<script type="text/javascript">
	$().ready(function() {
		radialIndicator.defaults.barColor = {
			100: '#F47171',
			200: '#FF9162',
			300: '#FFFF75',
			400: '#21BCFE',
			500: '#4ED89D'
		};
		radialIndicator.defaults.minValue = 0;
		radialIndicator.defaults.maxValue = 500;
		radialIndicator.defaults.format = '#.##分';

		$('#container1').radialIndicator({
			initValue: 400
		});
		$('#container2').radialIndicator({
			initValue: 500
		});
		$('#container3').radialIndicator({
			initValue: 500
		});
		$('#container4').radialIndicator({
			initValue: 466.66666666667
		});
	});
</script>
<!-- ECharts单文件引入 -->
<script src="/static/newjs/echarts-all.js?v=20180027"></script>
<script type="text/javascript">
$().ready(function() {
	// 基于准备好的dom，初始化echarts图表
	var myChart = echarts.init(document.getElementById('sales_div')); 
	
	var option = {
		tooltip: {
			show: true
		},
		legend: {
			data:['订单金额']
		},
		xAxis : [
			{
				type : 'category',
				data : ["10\u670820\u65e5","10\u670821\u65e5","10\u670822\u65e5","10\u670823\u65e5","10\u670824\u65e5","10\u670825\u65e5","10\u670826\u65e5","10\u670827\u65e5","10\u670828\u65e5","10\u670829\u65e5"]
			}
		],
		yAxis : [
			{
				type : 'value'
			}
		],
		series : [
			{
				"name":"订单金额",
				"type":"bar",
				"data":[0,0,0,0,0,0,0,0,0,0]
			}
		]
	};

	// 为echarts对象加载数据 
	myChart.setOption(option); 
});
</script>

<script type="text/javascript">
$().ready(function() {
	// 基于准备好的dom，初始化echarts图表
	var myChart = echarts.init(document.getElementById('customer_div')); 
	
	option = {
		tooltip : {
			trigger: 'item'
		},
		legend: {
			orient : 'vertical',
			x : 'left',
			data:["\u666e\u901a\u4f1a\u5458\uff08VIP1\uff09","\u9ad8\u7ea7\u4f1a\u5458(VIP2)"]
		},
		calculable : true,
		series : [
			{
				name:'客户等级',
				type:'pie',
				radius : ['50%', '70%'],
				itemStyle : {
					normal : {
						label : {
							show : false
						},
						labelLine : {
							show : false
						}
					},
					emphasis : {
						label : {
							show : true,
							position : 'center',
							textStyle : {
								fontSize : '15',
								fontWeight : 'bold'
							}
						}
					}
				},
				data:[{"name":"\u666e\u901a\u4f1a\u5458\uff08VIP1\uff09","value":"0"},{"name":"\u9ad8\u7ea7\u4f1a\u5458(VIP2)","value":"0"}]
			}
		]
	};

	// 为echarts对象加载数据 
	myChart.setOption(option); 
});
</script>

<script type="text/javascript">
$().ready(function() {
	$.ajax({
		url:'/store/get-data',
		type: 'get',
		dataType:'json',
		success:function(data) {
			// 出售中的商品
			$("#onsale_goods_count").html(data.onsale_goods_count);
			if(data.onsale_goods_count == 0) {
				$("#onsale_goods_count").parent().removeClass("num");
			}
			// 仓库中的商品
			$("#offsale_goods_count").html(data.offsale_goods_count);
			if(data.offsale_goods_count == 0) {
				$("#offsale_goods_count").parent().removeClass("num");
			}
			// 等待审核的商品
			$("#wait_audit_goods_count").html(data.wait_audit_goods_count);
			if(data.wait_audit_goods_count == 0) {
				$("#wait_audit_goods_count").parent().removeClass("num");
			}
			// 违规下架的商品
			$("#illegal_goods_count").html(data.illegal_goods_count);
			if(data.illegal_goods_count == 0) {
				$("#illegal_goods_count").parent().removeClass("num");
			}
			// 待付款订单
			$("#unpayed_order_count").html(data.unpayed_order_count);
			if(data.unpayed_order_count == 0) {
				$("#unpayed_order_count").parent().removeClass("num");
			}
			// 待发货订单
			$("#unshipping_order_count").html(data.unshipping_order_count);
			if(data.unshipping_order_count == 0) {
				$("#unshipping_order_count").parent().removeClass("num");
			}
			// 待评价订单
			$("#unevaluate_order_count").html(data.unevaluate_order_count);
			if(data.unevaluate_order_count == 0) {
				$("#unevaluate_order_count").parent().removeClass("num");
			}
			// 退款中订单
			$("#backing_order_count").html(data.backing_order_count);
			if(data.backing_order_count == 0) {
				$("#backing_order_count").parent().removeClass("num");
			}
			// 售后中订单
			// $("#sercive_order_count").html(data.sercive_order_count);
			//  售后退款订单
			$("#after_sale_order_count").html(data.after_sale_order_count);
			if(data.after_sale_order_count == 0) {
				$("#after_sale_order_count").parent().removeClass("num");
			}
			// 换货维修订单
			$("#exchange_order_count").html(data.exchange_order_count);
			if(data.exchange_order_count == 0) {
				$("#exchange_order_count").parent().removeClass("num");
			}
			// 待处理的投诉
			$("#wait_complaint_count").html(data.wait_complaint_count);
			if(data.wait_complaint_count == 0) {
				$("#wait_complaint_count").parent().removeClass("num");
			}  
			// 平台介入的投诉
			$("#involve_complaint_count").html(data.involve_complaint_count);
			if(data.involve_complaint_count == 0) {
				$("#involve_complaint_count").parent().removeClass("num");
			}
			// 今日收益
			$("#today_gains").html("<em>￥</em>" + data.today_gains);
			// 今日订单
			$("#today_order_count").html(data.today_order_count);
			// 今日添加会员
			$("#today_users_count").html(data.today_users_count);
		}
	});
});
</script>
<script type="text/javascript">
	$().ready(function() {
		 $("[data-toggle='popover']").popover();
		// 查看详情
		$("body").on("click", ".link", function() {
			var msg_id = $(this).data("msg-id");

			$.open({
				title: "站内信",
				ajax: {
					url: "/shop/message/view",
					data: {
						msg_id: msg_id
					}
				},
				width: "600px",
				btn: ['关闭']
			});
		});
	});
</script>
<script type="text/javascript">
		$().ready(function() {
			//店铺指引页面 弹窗
			 $.ajax({
					url: '/store/show-message',
					dataType: 'json',
					success: function(data) {
						if (data.data == 0) {
							$.open({
								title: "店铺指引",
								ajax: {
									url: '/index/index/seller-guide',
								},
								width: "1080px",
								height:"540px",
							});
						}
					}
				}); 
			 //店铺到期提醒
			 $.ajax({
				 url:'/store/expiration-reminding',
				 dataType: 'json',
				 success:function(result){
					 if (result.code == 0) {
						 $(".renew-box").removeClass('hide');
						 $(".site_name").html(result.data['shop_name']);
						 $(".shop_end_time").html(result.data['end_time']);
					 }
				 }
			 });
		});
</script>
					
				</div>
			</div>
		</div>
		<!--底部内容-->
		<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>

<script type="text/javascript">
function toFirst(target){
	var url = $(target).parents("li").find(".sub-list").find("li:first").find("a").attr("href");
	$.go(url);
}
function to(url, target){
	
}

function clearCache(){
	// 缓载
	$.loading.start();
	$.post("/site/clear-cache", {}, function(result){
		if(result.code == 0){
			$.msg(result.message);
		}else{
			$.msg(result.message, {
				time: 5000
			});
		}
	}).always(function(){
		$.loading.stop();
	});
}
// 登录成功关闭弹出框
$.login.success = function(){
	// 关闭并销毁登录窗口
	$.login.close(true);
}
</script>

<script type="text/javascript">
	// setInterval("auto_print()",10000);
	function auto_print(order_id)
	{
		$.ajax({
			type: "GET",
			url: "/site/auto-print",
			dataType: "json",
			data: {
				order_id: order_id
			},
			success: function(result) {
				if(result.code == 0)
				{
					lodop_print_html(result.print_title, result.data,result.printer);
				}
			}
		});
	}
</script>

<!-- 加载消息监听js-->
<script src="/static/newjs/message.js?v=20180027"></script>
<script src="/static/newjs/messageWS.js?v=20180027"></script>
<script type="text/javascript">
//声音监听
WS_AddUser({
	'user_id': 'shop_1717',
	'url': "ws://push.yunmall.68mall.com:7272",
	'type': "add_user"
}); 
//右下角消息提醒弹窗js
function open_message_box(data) {
	if (!data) {    
		data = {};
    }
	
	var src = window.location.href;
	
	// 如果当前框架中的链接地址和弹框的链接地址一致则不弹框
	if(data.auto_refresh == 1 && data.link && src.indexOf(data.link) != -1){
		
		var contentWindow = window;
		
		if(contentWindow.tablelist){
			contentWindow.tablelist.load({
				page: {
					cur_page: 1
				}
			});
		}else{
			contentWindow.location.reload();
		}
		
		return;
	}
	
	$('.message-pop-box').find('#message-pop-text').html(data.content);
	
	if(data.link){
		$('.message-pop-box').find('.message-btn').attr('href', data.link).show();
	}else{
		$('.message-pop-box').find('.message-btn').hide();
	}
	
	if(data.content || data.link){
		$('.message-pop-box').removeClass('down').addClass('up');
	}
	
	try {
		if(refresh_order && typeof(refresh_order) == "function") { 
			refresh_order();
        } 
    } catch(e) {}
}
$('.message-pop-box .close').click(function() {
	$('.message-pop-box').removeClass('up').addClass('down');
});
//用户信息
$(".admin").mouseenter(function() {
	window.focus();
	$("#admin-panel").show();
}).mouseleave(function() {
	$("#admin-panel").hide();
});
</script>
<script type="text/javascript">
	var clipboard = new Clipboard('.btn-copy');
    clipboard.on('success', function(e) {
        $.msg('复制成功');
    });
    clipboard.on('error', function(e) {
    	$.msg('复制失败');
    });
 	// 更新后台主框架消息弹窗
	function update_message() {
		// 是否重新获取数据
		if ($("#message-panel").html().length > 0) {
			// if (parseInt($("#counts_all").val()) != 0) {
			var time_step = 5; // 最小刷新间隔，单位：秒
			var this_time = new Date();
			if ((parseInt($("#counts_time").val()) + parseInt(time_step)) > parseInt(this_time.getTime() / 1000)) {
				return true;
			}
			// }
		}
		$.ajax({
			type: 'GET',
			url: '/site/update-message.html',
			data: {},
			dataType: 'json',
			success: function(result) {
				if (result.code == 0) {
					$("#message-panel").html(result.data);
				} else if (result.code == 1) {
				} else {
					$.msg(result.message);
				}
			}
		});
	}
	// 消息通知
	$("#message-box").mouseenter(function() {
		update_message();
		window.focus();
		$("#message-panel").show();
	}).mouseleave(function() {
		$("#message-panel").hide();
	}).find(".close").click(function() {
		$("#message-panel").hide();
	});
</script>

</html>

