<!DOCTYPE html>
<!--[if IE 8]> <html lang="zh-CN" class="ie8"> <![endif]-->
<html lang="zh-CN">
<?php echo $__env->make('common.link', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="style-seller">
	
	<?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<!--中间内容-->
	<div class="seller-center">
		<div class="wrapper">
			
			<!--左侧部分-->
			<?php echo $__env->make('common.slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<!--右侧内容-->
			<div class="seller-rihgt">
				<div class="seller-page">
					<div class="seller-page-bg"></div>
					<!--在这里调用内容-->
					<link rel="stylesheet" href="/static/css/styles.css?v=20181020"/>
<div class="page">
	<div class="fixed-bar">
	<div class="item-title">
		<div class="subject">
			<h3>
				<span class="action">发布商品 - 上传商品图片</span>
				<!--帮助教程-->
                <!--<a class="help-href" href="javascript:;" data-toggle="tooltip" data-placement="auto bottom" title="点击跳转到该模块教程页面"><i class="help-icon"></i></a>-->
                <!----->
			</h3>
			
					</div>
	</div>
</div>
 
	<div class="table-content">
		<!--步骤-->
		
		<ul class="add-goods-step">
	<li id="step_1">
		<i class="fa fa-list-alt step"></i>
		<h6>STEP.1</h6>
		<h2>选择商品分类</h2>
		<i class="fa fa-angle-right"></i>
	</li>
	<li id="step_2">
		<i class="fa fa-edit step"></i>
		<h6>STEP.2</h6>
		<h2>填写商品详情</h2>
		<i class="fa fa-angle-right"></i>
	</li>
	<li id="step_3">
		<i class="fa fa-image step"></i>
		<h6>STEP.3</h6>
		<h2>上传商品图片</h2>
		<i class="fa fa-angle-right"></i>
	</li>
	<li id="step_4">
		<i class="fa fa-check-square-o step"></i>
		<h6>STEP.4</h6>
		<h2>商品发布成功</h2>
	</li>
</ul>
<script type="text/javascript">
$().ready(function(){
	$("#step_3").addClass("current");
});
</script>
		
		<!-- 温馨提示 -->
		<div class="content">
			
			<div class="goods-info-three">
				<div class="col-sm-9">
					
					<div class="goodspic-list image-list">
						<div class="title">
							<h3>规格：无</h3>
						</div>
						<!-- 容器 -->
						<div id="goods_images_container_default" class="goods-images-container" data-spec_id="default"></div>
					</div>
					
					<div class="goods-next p-b-30 text-c p-l-0">
						
						<input type="button" id="btn_submit" value="下一步，确认商品发布" class="btn btn-primary" />
						
						<!--不可点击状态的下一步-->
						<!--<button class="btn btn-default">下一步，确认商品发布</button>-->
					</div>
				</div>
				<div class="col-sm-3">
					<div class="pic-upload-request p-15">
						<h4>上传要求：</h4>
						<ul>
							<li>1. 请使用jpg、jpeg、png等格式，单张大小不超过4M的正方形图片。</li>
							<li>2. 上传图片最大尺寸将被保留为1280像素，建议使用尺寸800*800像素。</li>
							<li>3. 每种颜色最多5张图片，可上传图片或从图片空间中选择已有的图片，上传后的图片也将被保存在店铺图片空间中以便其它使用。</li>
							<li>4. 通过更改排序数字修改商品图片的显示顺序。</li>
							<li>5. 图片质量要清晰，不能虚化，要保证亮度充足。</li>
							<li>6. 操作完成后请点下一步，否则无法在网站生效。</li>
						</ul>
						<h4>建议：</h4>
						<ul>
							<li>1. 主图为白色背景正面图。</li>
							<li>2. 排序依次为正面图-&gt;背面图-&gt;侧面图-&gt;细节图。</li>
						</ul>
					</div>
				</div>
			</div>
			
		</div>
	</div>
</div>
<!-- AJAX上传 -->
<script src="/static/js/jquery.ajaxfileupload.js?v=20180027"></script>
<!-- 图片上传、图片空间 -->
<script src="/static/js/jquery.widget.js?v=20180027"></script>
<!-- 验证规则 -->
<script id="client_rules" type="text">

</script>
<script type="text/javascript">
	$().ready(function() {
		window.onscroll = function() {
			$(window).scroll(function() {
				var scrollTop = $(document).scrollTop();
				var height = $(".table-content").height();
				var wHeight = $(window).height();
				if (scrollTop > (height - wHeight)) {
					$(".goods-next").removeClass("goods-btn-fixed");
				} else {
					$(".goods-next").addClass("goods-btn-fixed");
				}
			});

		};
		
		$("#btn_view").click(function() {
			$.go("<?php echo e(env('APP_URL')); ?>", "_blank");
		});
	});
</script>
<script id="goods_images_list" type="text">
{"default":["","","","",""]}
</script>
<script type="text/javascript">
	$().ready(function() {
		
		var imagegroups = [];

		var images = $.parseJSON($("#goods_images_list").text());

		// 

		imagegroups["spec_default"] = $("#goods_images_container_default").imagegroup({
			size: 5,
			mode: 1,
			host: "<?php echo e(env('APP_URL')); ?>",
			values: images["default"],
			gallery: true,
		});

		// 
		
		// 提交
		$("#btn_submit").click(function() {
			var goods_images = {};

			$(".goods-images-container").each(function() {
				var spec_id = $(this).data("spec_id");
				var imagegroup = imagegroups["spec_" + spec_id];

				if (!goods_images[spec_id]) {
					goods_images[spec_id] = [];
				}

				var index = 0;

				for (var i = 0; i < imagegroup.values.length; i++) {

					var path = imagegroup.values[i];

					if (path && path != "") {
						goods_images[spec_id].push({
							path: path,
							is_default: index == 0 ? 1 : 0,
							sort: i + 1
						});
						index++;
					}
				}
			});

			var data = {
				goods_images: goods_images
			};

			// 加载
			$.loading.start();

			$.post('/store/goods/edit-images?id=<?php echo e($id); ?>', data, function(result) {
				// 加载
				$.loading.stop();

				if (result.code == 0) {
					$.msg(result.message, {
						time: 2000
					}, function() {
						// 加载
						$.loading.start();
						$.go('/store/goods/success?id=<?php echo e($id); ?>');
					});
				} else {
					$.msg(result.message, {
						time: 5000
					});
				}
			}, 'json');
		});
	});
</script>
					
				</div>
			</div>
		</div>
		<!--底部内容-->
		<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>

<script type="text/javascript">
function toFirst(target){
	var url = $(target).parents("li").find(".sub-list").find("li:first").find("a").attr("href");
	$.go(url);
}
function to(url, target){
	
}

function clearCache(){
	// 缓载
	$.loading.start();
	$.post("/site/clear-cache", {}, function(result){
		if(result.code == 0){
			$.msg(result.message);
		}else{
			$.msg(result.message, {
				time: 5000
			});
		}
	}).always(function(){
		$.loading.stop();
	});
}
// 登录成功关闭弹出框
$.login.success = function(){
	// 关闭并销毁登录窗口
	$.login.close(true);
}
</script>

<script type="text/javascript">
	// setInterval("auto_print()",10000);
	function auto_print(order_id)
	{
		$.ajax({
			type: "GET",
			url: "/site/auto-print",
			dataType: "json",
			data: {
				order_id: order_id
			},
			success: function(result) {
				if(result.code == 0)
				{
					lodop_print_html(result.print_title, result.data,result.printer);
				}
			}
		});
	}
</script>

<!-- 加载消息监听js-->
<script src="/static/js/message.js?v=20180027"></script>
<script src="/static/js/messageWS.js?v=20180027"></script>
<script type="text/javascript">
//声音监听
WS_AddUser({
	'user_id': 'shop_1717',
	'url': "ws://push.yunmall.68mall.com:7272",
	'type': "add_user"
}); 
//右下角消息提醒弹窗js
function open_message_box(data) {
	if (!data) {    
		data = {};
    }
	
	var src = window.location.href;
	
	// 如果当前框架中的链接地址和弹框的链接地址一致则不弹框
	if(data.auto_refresh == 1 && data.link && src.indexOf(data.link) != -1){
		
		var contentWindow = window;
		
		if(contentWindow.tablelist){
			contentWindow.tablelist.load({
				page: {
					cur_page: 1
				}
			});
		}else{
			contentWindow.location.reload();
		}
		
		return;
	}
	
	$('.message-pop-box').find('#message-pop-text').html(data.content);
	
	if(data.link){
		$('.message-pop-box').find('.message-btn').attr('href', data.link).show();
	}else{
		$('.message-pop-box').find('.message-btn').hide();
	}
	
	if(data.content || data.link){
		$('.message-pop-box').removeClass('down').addClass('up');
	}
	
	try {
		if(refresh_order && typeof(refresh_order) == "function") { 
			refresh_order();
        } 
    } catch(e) {}
}
$('.message-pop-box .close').click(function() {
	$('.message-pop-box').removeClass('up').addClass('down');
});
//用户信息
$(".admin").mouseenter(function() {
	window.focus();
	$("#admin-panel").show();
}).mouseleave(function() {
	$("#admin-panel").hide();
});
</script>
<script type="text/javascript">
	var clipboard = new Clipboard('.btn-copy');
    clipboard.on('success', function(e) {
        $.msg('复制成功');
    });
    clipboard.on('error', function(e) {
    	$.msg('复制失败');
    });
 	// 更新后台主框架消息弹窗
	function update_message() {
		// 是否重新获取数据
		if ($("#message-panel").html().length > 0) {
			// if (parseInt($("#counts_all").val()) != 0) {
			var time_step = 5; // 最小刷新间隔，单位：秒
			var this_time = new Date();
			if ((parseInt($("#counts_time").val()) + parseInt(time_step)) > parseInt(this_time.getTime() / 1000)) {
				return true;
			}
			// }
		}
		$.ajax({
			type: 'GET',
			url: '/site/update-message.html',
			data: {},
			dataType: 'json',
			success: function(result) {
				if (result.code == 0) {
					$("#message-panel").html(result.data);
				} else if (result.code == 1) {
				} else {
					$.msg(result.message);
				}
			}
		});
	}
	// 消息通知
	$("#message-box").mouseenter(function() {
		update_message();
		window.focus();
		$("#message-panel").show();
	}).mouseleave(function() {
		$("#message-panel").hide();
	}).find(".close").click(function() {
		$("#message-panel").hide();
	});
</script>

</html>

