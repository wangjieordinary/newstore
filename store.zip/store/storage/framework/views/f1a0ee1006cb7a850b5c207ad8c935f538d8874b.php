<!DOCTYPE html>
<!--[if IE 8]> <html lang="zh-CN" class="ie8"> <![endif]-->
<html lang="zh-CN">
<?php echo $__env->make('common.link', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="style-seller">
	
	<?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<!--中间内容-->
	<div class="seller-center">
		<div class="wrapper">
			
			<!--左侧部分-->
			<?php echo $__env->make('common.slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
			
			<!--右侧内容-->
			<div class="seller-rihgt">
				<div class="seller-page">
					<div class="seller-page-bg"></div>
					<!--在这里调用内容-->
					<script src="/static/js/bootstrap-editable.js?v=20180027"></script>
					<link rel="stylesheet" href="/static/css/bootstrap-editable.css?v=20181020"/>

<div class="page">
	<div class="fixed-bar">
	<div class="item-title">
		<div class="subject">
			<h3>
				<span class="action">规格管理 - 规格列表</span>
				<!--帮助教程-->
                <!--<a class="help-href" href="javascript:;" data-toggle="tooltip" data-placement="auto bottom" title="点击跳转到该模块教程页面"><i class="help-icon"></i></a>-->
                <!---->
			</h3>
			
			<h5>
				
								
								<span class="action-span">
					
										
					<a  href="<?php echo e(url('store/spec/add')); ?>" class="btn btn-warning click-loading">
						<i class="fa fa-plus"></i>
						添加规格
					</a>
				</span>
				
			</h5>
			
						<ul class="tab-base shop-row">
								<li>
										<a class="current" data-tab-id="tab_list" data-tab-current="true">
						<span>规格列表</span>
					</a>
									</li>
				
			</ul>
					</div>
	</div>
</div>
<div class="titleBar-box">
	<a class="btn btn-default dropdown-toggle" id="dropdownTab" data-toggle="dropdown">
		主题
		<span class="caret"></span>
	</a>
	<ul class="dropdown-menu flipInX animated" role="menu" aria-labelledby="dropdownTab">
				<li role="presentation">
			<a href="list.html" data-tab-id="tab_list">规格列表</a>
		</li>
		
	</ul>

</div>
 
	<!-- 温馨提示 -->
	

	<!-- 搜索条件 -->
	<div class="search-term m-b-10">
		<div class="simple-form-field simple-form-search">
			<div class="form-group">
				<label class="control-label">
					<i class="fa fa-search"></i>
				</label>
			</div>
		</div>
		<div class="simple-form-field">
			<div class="form-group">
				<label class="control-label">
					<span>关键词：</span>
				</label>
				<div class="form-control-wrap">
					<input type="text" id="keywords" class="form-control" placeholder="请输入规格名称或者描述" />
				</div>
			</div>
		</div>
		<div class="simple-form-field">
			<input type="button" id="btn_submit" class="btn btn-primary m-r-5" value="搜索" />
		</div>
	</div>
	
<div class="common-title">
	<div class="ftitle">
		<h3>规格列表</h3>
		
		<h5>
			(&nbsp;共
			<span data-total-record=true><?php echo e($count); ?></span>
			条记录&nbsp;)
		</h5>
		
	</div>
	<div class="operate m-l-20">
		
		<a class="reload" href="javascript:tablelist.load();" data-toggle="tooltip" data-placement="auto bottom" title="刷新数据">
			<i class="fa fa-refresh"></i>
		</a>
		
		
		
	</div>
</div>
	<!-- 列表 -->
	<div class="table-responsive">
		
		<table id="table_list" class="table table-hover">
			<thead>
				<tr>
					<th class="tcheck">
						<input type="checkbox" class="checkBox allCheckBox"></input>
					</th>
					<th class="text-c w80" data-sortname="attr_id">编号</th>
					<th class="w250" data-sortname="attr_name">规格名称</th>
					<th class="w250">规格值</th>
					<!-- 
					<th class="text-c" data-sortname="is_show">是否有效</th>
					 -->
					<!-- <th class="text-c w100" data-sortname="attr_sort">排序</th> -->
					<th class="handle w150">操作</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $speclist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speclist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td class="tcheck">
						<input type="checkbox" class="checkBox" value="<?php echo e($speclist->id); ?>" />
					</td>
					<td class="text-c"><?php echo e($speclist->id); ?></td>
					<td><?php echo e($speclist->spec_name); ?></td>
					<td>
						<span title="<?php echo e($speclist->spec_value); ?>"><?php echo e($speclist->spec_value); ?></span>
					</td>
					<!-- <td class="text-c">
						<font class="f14">
							<a href="javascript:void(0);" class="attr_sort" data-id=1049>255</a>
						</font>
					</td> -->
					<td class="handle">
						<a href="<?php echo e(url('store/spec/edit')); ?>?id=<?php echo e($speclist->id); ?>">编辑</a>
						<span>|</span>
						<a href="javascript:void(0);" object_id="<?php echo e($speclist->id); ?>" class="del border-none">删除</a>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
			<tfoot>
				<tr>
					<!-- <td class="text-c w10">
						<input type="checkbox" class="allCheckBox checkBox">
						</input>
					</td> -->
					<td colspan="5">
						<!-- <div class="pull-left">
							<input type="button" class="btn btn-danger m-r-2 delete-spec" value="批量删除" />
						</div> -->
						<div class="pull-right page-box">
							<div id="pagination">
						<script data-page-json="true" type="text">
						{"page_key":"page","page_id":"pagination","default_page_size":10,"cur_page":1,"page_size":10,"page_size_list":[10,50,500,1000],"record_count":1,"page_count":1,"offset":0,"url":null,"sql":null}
						</script>
	
	
	<div class="pagination-info">
		共<?php echo e($count); ?>条记录，每页显示：
		<!-- <select class="select m-r-5" data-page-size="10">
			
			
			<option value="10" selected="selected">10</option>
			
			
			
			<option value="50">50</option>
			
			
			
			<option value="500">500</option>
			
			
			
			<option value="1000">1000</option>
			
			
		</select> -->
		条
	</div>
	<?php if($count>10): ?>
	<?php echo e($speclist->links()); ?>

	<?php endif; ?>	
	<div class="pagination-goto">
		<input class="ipt form-control goto-input" type="text">
		<button class="btn btn-default goto-button" title="点击跳转到指定页面">GO</button>
		<a class="goto-link" data-go-page="" style="display: none;"></a>
	</div>
	<script type="text/javascript">
		$().ready(function() {
			$(".pagination-goto > .goto-input").keyup(function(e) {
				$(".pagination-goto > .goto-link").attr("data-go-page", $(this).val());
				if (e.keyCode == 13) {
					$(".pagination-goto > .goto-link").click();
				}
			});
			$(".pagination-goto > .goto-button").click(function() {
				var page = $(".pagination-goto > .goto-link").attr("data-go-page");
				if ($.trim(page) == '') {
					return false;
				}
				$(".pagination-goto > .goto-link").attr("data-go-page", page);
				$(".pagination-goto > .goto-link").click();
				return false;
			});
		});
	</script>
	
</div>
						</div>
					</td>
				</tr>
			</tfoot>
		</table>
		
	</div>
</div>
<script type="text/javascript">
	var tablelist;
	$().ready(function() {
		tablelist = $("#table_list").tablelist();
		// 搜索
		$("#btn_submit").click(function() {
			tablelist.load({
				'type_name': $("#type_name").val(),
				'keywords': $("#keywords").val(),
			});
			return false;
		});
		// 删除记录
		$("body").on('click', '.del', function() {
			var id = $(this).attr("object_id");
			tablelist.remove({
				confirm: '您确定删除这条规格记录以及规格所关联的规格值吗？',
				url: 'delete',
				data: {
					id: id
				}
			});
		});

		//批量删除
		$("body").on("click", ".delete-spec", function() {

			var ids = $(this).data("id");

			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}

			if (!ids) {
				$.msg("请选择要删除的规格");
				return;
			}

			$.confirm("您确定要删除吗？", function() {
				$.loading.start();
				$.post('/goods/spec/delete', {
					ids: ids
				}, function(result) {
					if (result.code == 0) {
						$.loading.stop();
						$.msg(result.message);
						$.go('/store/spec/list')
						//tablelist.load();
					} else {
						$.loading.stop();
						$.msg(result.message, {
							time: 5000
						});
					}
				}, "json");
			});
		});

	});
</script>

<script type='text/javascript'>
	$(document).ready(function() {
		$(".attr_sort").editable({
			type: "text",
			url: "/goods/spec/edit-attr-info",
			pk: 1,
			ajaxOptions: {
				type: "post"
			},
			params: function(params) {
				params.id = $(this).data("id");
				params.title = "attr_sort";
				return params;
			},
			success: function(response, newValue) {
				var response = eval("(" + response + ")");
				if (response.code == -1) {
					return response.message;
				}
			}
		});
	});
</script>
					
				</div>
			</div>
		</div>
		<!--底部内容-->
		<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



</body>

<script type="text/javascript">
function toFirst(target){
	var url = $(target).parents("li").find(".sub-list").find("li:first").find("a").attr("href");
	$.go(url);
}
function to(url, target){
	
}

function clearCache(){
	// 缓载
	$.loading.start();
	$.post("/site/clear-cache", {}, function(result){
		if(result.code == 0){
			$.msg(result.message);
		}else{
			$.msg(result.message, {
				time: 5000
			});
		}
	}).always(function(){
		$.loading.stop();
	});
}
// 登录成功关闭弹出框
$.login.success = function(){
	// 关闭并销毁登录窗口
	$.login.close(true);
}
</script>

<script type="text/javascript">
	// setInterval("auto_print()",10000);
	function auto_print(order_id)
	{
		$.ajax({
			type: "GET",
			url: "/site/auto-print",
			dataType: "json",
			data: {
				order_id: order_id
			},
			success: function(result) {
				if(result.code == 0)
				{
					lodop_print_html(result.print_title, result.data,result.printer);
				}
			}
		});
	}
</script>

<!-- 加载消息监听js-->
<script src="/assets/d2eace91/js/message/message.js?v=20180027"></script>
<script src="/assets/d2eace91/js/message/messageWS.js?v=20180027"></script>
<script type="text/javascript">
//声音监听
WS_AddUser({
	'user_id': 'shop_1717',
	'url': "ws://push.yunmall.68mall.com:7272",
	'type': "add_user"
}); 
//右下角消息提醒弹窗js
function open_message_box(data) {
	if (!data) {    
		data = {};
    }
	
	var src = window.location.href;
	
	// 如果当前框架中的链接地址和弹框的链接地址一致则不弹框
	if(data.auto_refresh == 1 && data.link && src.indexOf(data.link) != -1){
		
		var contentWindow = window;
		
		if(contentWindow.tablelist){
			contentWindow.tablelist.load({
				page: {
					cur_page: 1
				}
			});
		}else{
			contentWindow.location.reload();
		}
		
		return;
	}
	
	$('.message-pop-box').find('#message-pop-text').html(data.content);
	
	if(data.link){
		$('.message-pop-box').find('.message-btn').attr('href', data.link).show();
	}else{
		$('.message-pop-box').find('.message-btn').hide();
	}
	
	if(data.content || data.link){
		$('.message-pop-box').removeClass('down').addClass('up');
	}
	
	try {
		if(refresh_order && typeof(refresh_order) == "function") { 
			refresh_order();
        } 
    } catch(e) {}
}
$('.message-pop-box .close').click(function() {
	$('.message-pop-box').removeClass('up').addClass('down');
});
//用户信息
$(".admin").mouseenter(function() {
	window.focus();
	$("#admin-panel").show();
}).mouseleave(function() {
	$("#admin-panel").hide();
});
</script>
<script type="text/javascript">
	var clipboard = new Clipboard('.btn-copy');
    clipboard.on('success', function(e) {
        $.msg('复制成功');
    });
    clipboard.on('error', function(e) {
    	$.msg('复制失败');
    });
 	// 更新后台主框架消息弹窗
	function update_message() {
		// 是否重新获取数据
		if ($("#message-panel").html().length > 0) {
			// if (parseInt($("#counts_all").val()) != 0) {
			var time_step = 5; // 最小刷新间隔，单位：秒
			var this_time = new Date();
			if ((parseInt($("#counts_time").val()) + parseInt(time_step)) > parseInt(this_time.getTime() / 1000)) {
				return true;
			}
			// }
		}
		$.ajax({
			type: 'GET',
			url: '/site/update-message.html',
			data: {},
			dataType: 'json',
			success: function(result) {
				if (result.code == 0) {
					$("#message-panel").html(result.data);
				} else if (result.code == 1) {
				} else {
					$.msg(result.message);
				}
			}
		});
	}
	// 消息通知
	$("#message-box").mouseenter(function() {
		update_message();
		window.focus();
		$("#message-panel").show();
	}).mouseleave(function() {
		$("#message-panel").hide();
	}).find(".close").click(function() {
		$("#message-panel").hide();
	});
</script>

</html>

