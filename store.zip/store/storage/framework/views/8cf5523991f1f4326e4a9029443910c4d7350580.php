<script src="<?php echo e(asset('vendor/kindeditor/kindeditor-all-min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/kindeditor/lang/zh-CN.js')); ?>"></script>
<script>
    KindEditor.ready(function (K) {
        window.editor = K.create('#'+'<?php echo e($editor); ?>', {
            uploadJson: "<?php echo e(asset('kindeditor/upload')); ?>",
            //fileManagerJson: '',
            allowFileManager: false,
            formatUploadUrl: false
        });
    });
</script>