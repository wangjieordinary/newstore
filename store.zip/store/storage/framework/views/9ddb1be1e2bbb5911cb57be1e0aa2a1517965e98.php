<!-- 新订单列表 -->
<div id="table_list">
	<div class="common-title">
	<div class="ftitle">
		<h3>订单列表</h3>
		<h5>(&nbsp;共<span data-total-record=true>0</span>条记录&nbsp;)</h5>
	</div>
	<div class="operate m-l-20">
		<a class="reload" href="javascript:tablelist.load();" data-toggle="tooltip" data-placement="auto bottom" title="刷新数据"><i class="fa fa-refresh"></i></a>
	</div>
</div>
<!--列表内容-->
<!-- 不要格式化！！！ -->
<div class="item-list-hd order-list">
	<ul class="item-list-tabs">
		<li id="all" class="tabs-t">
			<a>全部订单（<span id="order-all"></span>）</a>
		</li>
		<li id="unpayed" class="tabs-t <?php if($order_status=='unpayed'): ?> current <?php endif; ?>">
			<a>等待买家付款（<span id="order-unpayed"></span>）</a>
		</li>
		<!-- <li id="unshipped" class="tabs-t">
			<a>待发货未指派订单（<span id="order-unshipped"></span>）</a>
		</li>
		<li id="assign" class="tabs-t">
			<a>待发货已指派订单（<span id="order-assign"></span>）</a>
		</li> -->
		<li id="shipped" class="tabs-b <?php if($order_status=='shipped'): ?> current <?php endif; ?>">
			<a>已发货（<span id="order-shipped"></span>）</a>
		</li>
		<li id="finished" class="tabs-b <?php if($order_status=='finished'): ?> current <?php endif; ?>">
			<a>已完成（<span id="order-finished"></span>）</a>
		</li>
		<!-- <li id="closed" class="tabs-b">
			<a>已关闭（<span id="order-closed"></span>）</a>
		</li>
		<li id="backing" class="tabs-b">
			<a>退款中（<span id="order-backing"></span>）</a>
		</li>
		<li id="cancel" class="tabs-b last">
			<a>取消订单申请（<span id="order-cancel"></span>）</a>
		</li> -->
	</ul>
</div>
<style type="text/css">
.item-list-hd.order-list ul li {padding: 8px 3px 5px 5px;}
</style>
<script type="text/javascript">
$().ready(function() {
	$("li[class^='tabs-']").click(function() {
		$("li[class^='tabs-']").removeClass('current');
		$(this).addClass('current');
		// 订单状态下拉框中必须存在此状态，才能被选中
		$("#order_status").val($(this).attr("id"));
		tablelist = $("#table_list").tablelist({
			params: $("#searchForm").serializeJson()
		});
		tablelist.params.order_status = $(this).attr("id")
		tablelist.load();
	});
	var url = '/store/order/get-order-counts';
	//
	var data = $("#searchForm").serializeJson();
	$.ajax({
		url: url,
		dataType: 'json',
		type: 'POST',
		data: data,
		success: function(data) {
			$("#order-all").html(data.all);
			$("#order-unpayed").html(data.unpayed);
			$("#order-unshipped").html(data.unshipped);
			$("#order-assign").html(data.assign);
			$("#order-shipped").html(data.shipped);
			$("#order-finished").html(data.finished);
			$("#order-closed").html(data.closed);
			$("#order-backing").html(data.backing);
			$("#order-cancel").html(data.cancel);
			$("#order-pending").html(data.pending);
		}
	});
});
</script>
				<?php if(count($orderlist)>0): ?>;
				<?php $__currentLoopData = $orderlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="new-order-item">
			<!--订单基本信息及状态-->
			<div class="order-item-title">
				<input name="order_id_box" type="checkbox" class="table-list-checkbox checkBox cur-p m-r-5" value="<?php echo e($orderlist->id); ?>" />
				
				<h5 class="order-id">#1</h5>
				
				（订单ID：<?php echo e($orderlist->id); ?>）
				
				<span>
					<em class="c-red">立即配送</em>
					送达
				</span>
				
				<span>订单编号：<?php echo e($orderlist->ddh); ?></span>
				<span>下单时间：<?php echo e($orderlist->atime); ?></span>
				
				
				
				
				<!-- 支付方式 -->
				<label class="label label-primary">
					<?php if($orderlist->zflx=='1'): ?>
						积分
					<?php elseif($orderlist->zflx=='2'): ?>
						现金
					<?php elseif($orderlist->zflx=='3'): ?>
						微信
					<?php elseif($orderlist->zflx=='7'): ?>
						余额+积分
					<?php elseif($orderlist->zflx=='8'): ?>
						微信+积分
					<?php endif; ?>
				</label>
				
			</div>
			<!--订单提示信息-->
			
			
			<!-- <div class="order-item-reminder order-item-layout">
				<h5>温馨提示：</h5>
				<p>交易已关闭</p>
				<p>
					
					关闭类型： 买家取消订单
					
				</p>
				<p>关闭原因： 其他原因</p>
			</div> -->
						
			
			<!--买家信息-->

			<div class="order-item-user order-item-layout over-visible pos-r">
				<h5 class="name">
					
					<?php echo e($orderlist->sname); ?>

					
					<span class="name-label popover-box buyer">
						<?php echo e($orderlist->userinfo->telephone); ?>

						<div class="popover-info" style="right: -280px; left: auto;">
							<i class="fa fa-caret-left"></i>
							<ul>
								<li>
									<h3>
										<i class="fa fa-user"></i>
										联系信息
									</h3>
								</li>
								<li>
									<div class="dt">
										<span>会员账号：</span>
									</div>
									<div class="dd"><?php echo e($orderlist->userinfo->telephone); ?></div>
								</li>
								<li>
									<div class="dt">
										<span>会员昵称：</span>
									</div>
									<div class="dd"><?php echo e($orderlist->userinfo->telephone); ?></div>
								</li>
								<li>
									<div class="dt">
										<span>绑定电话：</span>
									</div>
									<div class="dd"><?php echo e($orderlist->userinfo->telephone); ?></div>
								</li>
								<li>
									<div class="dt">
										<span>绑定邮箱：</span>
									</div>
									<div class="dd"></div>
								</li>
								<!-- <li>
									<div class="dt">
										<span>交易订单：</span>
									</div>
									<div class="dd">
										1笔
										
										<a class="c-blue m-l-10" href="http://seller.68dsw.com/trade/order/list.html?uid=2450" target="_blank">（会员所有订单）</a>
										
									</div>
								</li> -->
							</ul>
						</div>
					</span>
				</h5>
				
				
				<p class="tel"><?php echo e($orderlist->ssj); ?></p>
				<p class="address">
					<?php echo e($orderlist->sadd); ?> 					<!-- 地图功能，暂时没有 -->
					<!-- <a class="address-map m-l-10">
						<i class="fa fa-map-marker"></i>
					</a> -->
					
				</p>

				
				
								
			</div>
			
			<div class="clear"></div>
			<!--买家留言-->
						<!-- 其它信息 -->
						<!-- 预售发货时间 -->
			

			
			<!-- 配送状态 -->
			<div class="order-item-delivery">
				<div class="order-item-title">
					
					<h5>配送状态：</h5>
					<span class="c-green m-l-10">
					<?php if($orderlist->zt=='0'): ?>
						未处理
					<?php elseif($orderlist->zt=='1'): ?>
						未付款
					<?php elseif($orderlist->zt=='2'): ?>
						已付款
					<?php elseif($orderlist->zt=='3'): ?>
						已发货
					<?php elseif($orderlist->zt=='4'): ?>
						已退款
					<?php elseif($orderlist->zt=='5'): ?>
					已确认
					<?php elseif($orderlist->zt=='7'): ?>
						已取消
					<?php endif; ?>
					</span>
					
				</div>

			</div>
			
			<!-- 商品信息 -->
			<div class="order-item-goods">
				<div class="order-item-title">
					<h5>
						商品信息（共&nbsp;
						<em><?php echo e($orderlist->goodscount); ?></em>
						&nbsp;件商品）
					</h5>
					<a class="goods-toggle-btn btn btn-primary btn-xs c-fff pull-right">
						收起
						<i class="fa fa-angle-down m-r-0 m-l-5"></i>
					</a>
				</div>
				<table class="table m-b-0 order-item-layout goods-toggle-panel">
					
					<?php $__currentLoopData = $orderlist->goodslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goodslist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="order-item">
						<td class="item">
							<div class="pic-info">
								<a href="#" class="goods-thumb" title="查看商品详情" target="_blank">
									<img src="<?php echo e($goodslist->goodsinfo->pic1); ?>" alt="查看商品详情"></img>
								</a>
							</div>
							<div class="txt-info">
								<div class="desc">
									<a href="#" class="goods-name" target="_blank" title="<?php echo e($goodslist->goodsinfo->name); ?>">
										
										
										<?php echo e($goodslist->goodsinfo->name); ?>

									</a>
									<!-- <a href="http://www.68dsw.com/44898" class="snap">【交易快照】</a> -->
								</div>
								
								
								<div class="icon m-b-5">
									
								</div>
							</div>
						</td>
						<td>
							
							<span></span>
							
						</td>
						
						<td>¥<?php echo e($goodslist->dj); ?>元</td>
						
						<td class="c-red">× <?php echo e($goodslist->sl); ?></td>
						
						<td>¥<?php echo e($goodslist->zj); ?>元</td>
						
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</table>
				<!-- 商品小计 -->
				
				<div class="order-item-layout text-r">
					<strong>小计</strong>
					<p class="m-t-5">
						商品总金额：
						<em class="m-r-5">¥<?php echo e($goodslist->zj); ?>元</em>
						+ 运费：
						<em class="m-r-5">¥0.00元 </em>
						
						- 店铺红包：
						<em class="m-r-5">¥0.00元</em>
						- 平台红包：
						<em class="m-r-5">¥0.00元</em>
						
						
						- 卖家优惠：
						<em class="m-r-5">¥0.00元</em>
						
						= 订单总金额：
						<em class="m-r-5">¥<?php echo e($goodslist->zj); ?>元</em>
					</p>
				</div>
				<div class="order-item-layout text-r">
										
					<span class="c-red">[ 
						<?php if($orderlist->zt=='1'): ?>
							未付款
						<?php elseif($orderlist->zt=='2'): ?>
							已付款
						<?php endif; ?>
					 ]</span>
					<strong class="m-l-10">¥<?php echo e($orderlist->jine); ?>元</strong>
									</div>
								<div class="order-item-layout text-r">
					<strong>平台佣金：</strong>
					<strong class="c-red m-l-10">¥0.00元</strong>
				</div>
				<div class="order-item-layout text-r">
					<strong>本单预计收入：</strong>
					<strong class="c-red m-l-10">¥<?php echo e($orderlist->jine-$goodslist->zcb); ?>元</strong>
				</div>
								
			</div>
			<!-- 订单备注信息 -->
			
			
			<!-- 退款信息 -->
						<!-- 订单操作 -->

			<div class="order-item-handle">
				<!-- <div class="pull-left">
					
					<a class="btn btn-warning" id="order_print_5044" href="javascript:order_print('5044')">打印订单</a>
					<a class="btn btn-default m-l-5" id="remark" data-id="5044">备注</a>
					
				</div> -->

				
				<div class="pull-right">
										
										
					<?php if($orderlist->zt=='2'): ?>
					<a class="btn btn-primary m-l-5" href="/store/order/toshipping?id=<?php echo e($orderlist->id); ?>">去发货</a>
					<?php endif; ?>
					<a class="btn btn-primary m-l-5" href="/store/order/info?id=<?php echo e($orderlist->id); ?>">订单详情</a>
					
				</div>
				
			</div>

			<!-- 订单状态 -->
						<div class="seal-state state6"></div>
						
			
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php else: ?>

<div class="no-data-page">
	<div class="icon">
		<i class="fa fa-file-text-o"></i>
	</div>
	<h5>暂无指定订单</h5>
	<p>暂时没有符合条件的订单，稍后再来看看吧！</p>
</div>
<?php endif; ?>
</div>
<script type="text/javascript">
$('body').find('.order-toggle-btn').click(function() {
	if ($(this).hasClass('toggle')) {
		$(this).html('收起<i class="fa fa-angle-down m-r-0 m-l-5"></i>').removeClass('toggle');
		$(this).parents().next(".order-toggle-panel").slideToggle(300);
	} else {
		$(this).html('展开<i class="fa fa-angle-up m-r-0 m-l-5"></i>').addClass('toggle');
		$(this).parents().next(".order-toggle-panel").slideToggle(300);
	}
})
$('body').find('.goods-toggle-btn').click(function() {
	if ($(this).hasClass('toggle')) {
		$(this).html('收起<i class="fa fa-angle-down m-r-0 m-l-5"></i>').removeClass('toggle');
		$(this).parents().next(".goods-toggle-panel").slideToggle(300);
	} else {
		$(this).html('展开<i class="fa fa-angle-up m-r-0 m-l-5"></i>').addClass('toggle');
		$(this).parents().next(".goods-toggle-panel").slideToggle(300);
	}
});
</script>