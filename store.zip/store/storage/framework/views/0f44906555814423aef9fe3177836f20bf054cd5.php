<head>
<meta charset="utf-8" />
<title>店铺首页</title>
<!-- 头部元数据 -->
<meta name="csrf-param" content="_csrf">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Keywords" content="" />
<meta name="Description" content="" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,Chrome=1" />
<meta name="format-detection" content="telephone=no">
<!-- 网站头像 -->
<link rel="icon" type="image/x-icon" href="http://68dsw.oss-cn-beijing.aliyuncs.com/images/system/config/website/favicon_0.jpg" />
<link rel="shortcut icon" type="image/x-icon" href="http://68dsw.oss-cn-beijing.aliyuncs.com/images/system/config/website/favicon_0.jpg" />
<link rel="stylesheet" href="/static/storeindex/css/iconfont.css?v=20181020"/>
<link rel="stylesheet" href="/static/storeindex/css/common.css?v=20181020"/>
<link rel="stylesheet" href="/static/storeindex/css/shop_index.css?v=20181020"/>
<link rel="stylesheet" href="/static/storeindex/css/template.css?v=20181020"/>

<!--整站改色 _start-->
<link rel="stylesheet" href="/static/css/color-style.css?v=20181020"/>
<!--整站改色 _end-->
<!-- ================== END BASE CSS STYLE ================== -->
<script src="/static/js/jquery.js?v=20180027"></script>
<script src="/static/storeindex/js/yii.js?v=20180027"></script>
<script src="/static/storeindex/js/layer.js?v=20180027"></script>
<script src="/static/js/jquery.method.js?v=20180027"></script>
<script src="/static/js/jquery.modal.js?v=20180027"></script>
<script src="/static/storeindex/js/common.js?v=20180027"></script>
<script src="/static/js/jquery.tablelist.js?v=20180027"></script>
<!-- 图片缓载js -->
<script src="/static/storeindex/js/jquery.lazyload.js?v=20180027"></script>
</head>