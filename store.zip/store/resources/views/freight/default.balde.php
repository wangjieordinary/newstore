<!DOCTYPE html>
<!--[if IE 8]> <html lang="zh-CN" class="ie8"> <![endif]-->
<html lang="zh-CN">
@include('common.link')
<body class="style-seller">
	
	@include('common.header')
	
	<!--中间内容-->
	<div class="seller-center">
		<div class="wrapper">
			
			<!--左侧部分-->
			@include('common.slider')
			
			<!--右侧内容-->
			<div class="seller-rihgt">
				<div class="seller-page">
					<div class="seller-page-bg"></div>
					<!--在这里调用内容-->
					
<link rel="stylesheet" href="/static/css/styles.css?v=20181020"/>
<div class="page">
	<div class="fixed-bar">
	<div class="item-title">
		<div class="subject">
			<h3>
				<span class="action">运费设置 - 店铺统一运费</span>
				<!--帮助教程-->
                <!--<a class="help-href" href="javascript:;" data-toggle="tooltip" data-placement="auto bottom" title="点击跳转到该模块教程页面"><i class="help-icon"></i></a>-->
                <!----->
			</h3>
			
						<ul class="tab-base shop-row">
								<li>
										<a href="/shop/freight/list.html" onClick="if($.loading){ $.loading.start(); }" data-tab-id="tab_1">
						<span>运费模板列表</span>
					</a>
									</li>
								<li>
										<a class="current" data-tab-id="tab_2" data-tab-current="true">
						<span>店铺统一运费</span>
					</a>
									</li>
								<li>
										<a href="/shop/freight/calculate.html" onClick="if($.loading){ $.loading.start(); }" data-tab-id="tab_3">
						<span>运费模拟计算</span>
					</a>
									</li>
				
			</ul>
					</div>
	</div>
</div>
<div class="titleBar-box">
	<a class="btn btn-default dropdown-toggle" id="dropdownTab" data-toggle="dropdown">
		主题
		<span class="caret"></span>
	</a>
	<ul class="dropdown-menu flipInX animated" role="menu" aria-labelledby="dropdownTab">
				<li role="presentation">
			<a href="/shop/freight/list.html" data-tab-id="tab_1">运费模板列表</a>
		</li>
				<li role="presentation">
			<a href="/shop/freight/default.html" data-tab-id="tab_2">店铺统一运费</a>
		</li>
				<li role="presentation">
			<a href="/shop/freight/calculate.html" data-tab-id="tab_3">运费模拟计算</a>
		</li>
		
	</ul>

</div>
 
	
		
	<form id="ShopConfigModel" class="form-horizontal" name="ShopConfigModel" action="/shop/config/index" method="post" enctype="multipart/form-data">
<input type="hidden" name="_csrf" value="AdeHOf5IAffOcUexjAxB59vXqO-odAxU3uO083NBsQNJgsoMmXk1hYkrPojmRjaRjrXHo-RCVm2Bgf7HFDDnSQ==">
	<input type="hidden" name="group" value="freight">
	<input type="hidden" name="tabs" value="">
	<div class="table-content m-t-30">

		
		
		

		<div class="simple-form-field" >
<div class="form-group">
<label for="shopconfigmodel-freight_fee" class="col-sm-4 control-label">
<span class="text-danger ng-binding">*</span>
<span class="ng-binding">店铺统一运费：</span>
</label>
<div class="col-sm-8">
<div class="form-control-box">

		
		
		
		<input type="text" id="shopconfigmodel-freight_fee" class="form-control ipt m-r-10" name="ShopConfigModel[freight_fee]" value="0">
		
		
		
		元
		
		
</div>

<div class="help-block help-block-t"><div class="help-block help-block-t">当发布、编辑商品的运费设置为店铺统一运费时，此商品的运费按照店铺的统一运费进行计算</div></div>
</div>
</div>
</div>
		
		
		
		
		

		<div class="simple-form-field" >
<div class="form-group">
<label for="shopconfigmodel-freight_cod_enable" class="col-sm-4 control-label">
<span class="text-danger ng-binding">*</span>
<span class="ng-binding">是否支持货到付款：</span>
</label>
<div class="col-sm-8">
<div class="form-control-box">

		
		
		
		
		<label class="control-label control-label-switch">
<div class="switch bootstrap-switch bootstrap-switch-mini sm-nav-switch">
<input type="hidden" name="ShopConfigModel[freight_cod_enable]" value="0"><label><input type="checkbox" id="shopconfigmodel-freight_cod_enable" class="form-control b-n" name="ShopConfigModel[freight_cod_enable]" value="1" data-on-text="是" data-off-text="否"> </label>
</div>
</label>
		
		
		
		
</div>

<div class="help-block help-block-t"><div class="help-block help-block-t">仅用于控制店铺统一运费是否支持货到付款，按运费模板计算运费的商品不受此设置影响</div></div>
</div>
</div>
</div>
		
		
		
		
		

		<div class="simple-form-field" >
<div class="form-group">
<label for="shopconfigmodel-freight_cash_more" class="col-sm-4 control-label">
<span class="text-danger ng-binding">*</span>
<span class="ng-binding">货到付款加价：</span>
</label>
<div class="col-sm-8">
<div class="form-control-box">

		
		
		
		<input type="text" id="shopconfigmodel-freight_cash_more" class="form-control ipt m-r-10" name="ShopConfigModel[freight_cash_more]" value="0">
		
		
		
		元
		
		
</div>

<div class="help-block help-block-t"><div class="help-block help-block-t">仅在上一项支持货到付款为“是”时起作用，用于控制店铺统一运费在支持货到付款时加价金额，按运费模板计算运费的商品不受此设置影响</div></div>
</div>
</div>
</div>
		
		
		
		
		<div class="simple-form-field p-b-30">
			<div class="form-group">
				<label for="text4" class="col-sm-4 control-label"></label>
				<div class="col-xs-8">
					<input type="hidden" name="back_url" value="/shop/freight/default.html" />
					<input type="button" id="btn_submit" value="确认提交" class="btn btn-primary" />
				</div>
			</div>
		</div>
		</form>
	</div>
</div>


<!-- 表单验证 -->
<script src="/static/js/validate/jquery.validate.js?v=20180027"></script>
<script src="/static/js/validate/jquery.validate.custom.js?v=20180027"></script>
<script src="/static/js/validate/messages_zh.js?v=20180027"></script>
<!-- AJAX上传+图片预览 -->
<script src="/static/js/jquery.ajaxfileupload.js?v=20180027"></script>
<script src="/static/js/imgPreview.js?v=20180027"></script>
<script src="/static/js/jquery.widget.js?v=20180027"></script>
<!-- 验证规则 -->
<script id="client_rules" type="text">
[{"id": "shopconfigmodel-freight_fee", "name": "ShopConfigModel[freight_fee]", "attribute": "freight_fee", "rules": {"string":true,"messages":{"string":"店铺统一运费必须是一条字符串。"}}},{"id": "shopconfigmodel-freight_fee", "name": "ShopConfigModel[freight_fee]", "attribute": "freight_fee", "rules": {"required":true,"messages":{"required":"店铺统一运费不能为空。"}}},{"id": "shopconfigmodel-freight_fee", "name": "ShopConfigModel[freight_fee]", "attribute": "freight_fee", "rules": {"required":true,"messages":{"required":"店铺统一运费不能为空。"}}},{"id": "shopconfigmodel-freight_fee", "name": "ShopConfigModel[freight_fee]", "attribute": "freight_fee", "rules": {"number":{"pattern":"/^\\s*[-+]?[0-9]*\\.?[0-9]+([eE][-+]?[0-9]+)?\\s*$/"},"messages":{"number":"店铺统一运费必须是一个数字。","decimal":"店铺统一运费必须是一个不大于2位小数的数字。","min":"店铺统一运费必须不小于0。","max":"店铺统一运费必须不大于1000。"},"decimal":2,"min":0,"max":1000}},{"id": "shopconfigmodel-freight_cod_enable", "name": "ShopConfigModel[freight_cod_enable]", "attribute": "freight_cod_enable", "rules": {"string":true,"messages":{"string":"是否支持货到付款必须是一条字符串。"}}},{"id": "shopconfigmodel-freight_cod_enable", "name": "ShopConfigModel[freight_cod_enable]", "attribute": "freight_cod_enable", "rules": {"required":true,"messages":{"required":"是否支持货到付款不能为空。"}}},{"id": "shopconfigmodel-freight_cash_more", "name": "ShopConfigModel[freight_cash_more]", "attribute": "freight_cash_more", "rules": {"string":true,"messages":{"string":"货到付款加价必须是一条字符串。"}}},{"id": "shopconfigmodel-freight_cash_more", "name": "ShopConfigModel[freight_cash_more]", "attribute": "freight_cash_more", "rules": {"required":true,"messages":{"required":"货到付款加价不能为空。"}}},{"id": "shopconfigmodel-freight_cash_more", "name": "ShopConfigModel[freight_cash_more]", "attribute": "freight_cash_more", "rules": {"required":true,"messages":{"required":"货到付款加价不能为空。"}}},{"id": "shopconfigmodel-freight_cash_more", "name": "ShopConfigModel[freight_cash_more]", "attribute": "freight_cash_more", "rules": {"number":{"pattern":"/^\\s*[-+]?[0-9]*\\.?[0-9]+([eE][-+]?[0-9]+)?\\s*$/"},"messages":{"number":"货到付款加价必须是一个数字。","decimal":"货到付款加价必须是一个不大于2位小数的数字。","min":"货到付款加价必须不小于0。"},"decimal":2,"min":0}},]
</script>





<script type="text/javascript">
	$().ready(function() {

		var validator = $("#ShopConfigModel").validate();
		// 验证规则，此验证规则会影响编辑器中JavaScript的的格式化操作
		$.validator.addRules($("#client_rules").html());
		$("#btn_submit").click(function() {
			validator.form();
			if (!validator.form()) {
				return;
			}
			$.loading.start();
			$("#ShopConfigModel").submit();
			/**
			var data = $("#SystemConfigModel").serializeJson();
			$.post('/system/config/index', data, function(result) {
				if (result.code == 0) {
					$.msg(result.message, {
						icon: 1
					});
				} else {
					$.alert(result.message, {
						icon: 2
					});
				}
			}, "json");
			 **/
		});

		$(".szy-imagegroup").each(function() {
			var id = $(this).data("id");
			var size = $(this).data("size");
			var mode = $(this).data("mode");
			var labels = $(this).data("labels");
			
			var target = $("#" + id);
			var value = $(target).val() ;
			
			var options = $(this).data("options") ? $(this).data("options") : [];

			$(this).imagegroup({
				host: "http://68dsw.oss-cn-beijing.aliyuncs.com/images/",
				size: size,
				mode: mode,
				labels: labels,
				options: options,
				values: value.split("|"),
				// 改变事件
				change: function(values, type){
					if (!values) {
						values = [];
					}
					values = values.join("|");
					target.val(values);
				}
			});
		});
	});
</script>
					
				</div>
			</div>
		</div>
		<!--底部内容-->
		@include('common.footer')

</body>

<script type="text/javascript">
function toFirst(target){
	var url = $(target).parents("li").find(".sub-list").find("li:first").find("a").attr("href");
	$.go(url);
}
function to(url, target){
	
}

function clearCache(){
	// 缓载
	$.loading.start();
	$.post("/site/clear-cache", {}, function(result){
		if(result.code == 0){
			$.msg(result.message);
		}else{
			$.msg(result.message, {
				time: 5000
			});
		}
	}).always(function(){
		$.loading.stop();
	});
}
// 登录成功关闭弹出框
$.login.success = function(){
	// 关闭并销毁登录窗口
	$.login.close(true);
}
</script>

<script type="text/javascript">
	// setInterval("auto_print()",10000);
	function auto_print(order_id)
	{
		$.ajax({
			type: "GET",
			url: "/site/auto-print",
			dataType: "json",
			data: {
				order_id: order_id
			},
			success: function(result) {
				if(result.code == 0)
				{
					lodop_print_html(result.print_title, result.data,result.printer);
				}
			}
		});
	}
</script>

<!-- 加载消息监听js-->
<script src="/static/js/message/message.js?v=20180027"></script>
<script src="/static/js/message/messageWS.js?v=20180027"></script>
<script type="text/javascript">
//声音监听
WS_AddUser({
	'user_id': 'shop_1717',
	'url': "ws://push.yunmall.68mall.com:7272",
	'type': "add_user"
}); 
//右下角消息提醒弹窗js
function open_message_box(data) {
	if (!data) {    
		data = {};
    }
	
	var src = window.location.href;
	
	// 如果当前框架中的链接地址和弹框的链接地址一致则不弹框
	if(data.auto_refresh == 1 && data.link && src.indexOf(data.link) != -1){
		
		var contentWindow = window;
		
		if(contentWindow.tablelist){
			contentWindow.tablelist.load({
				page: {
					cur_page: 1
				}
			});
		}else{
			contentWindow.location.reload();
		}
		
		return;
	}
	
	$('.message-pop-box').find('#message-pop-text').html(data.content);
	
	if(data.link){
		$('.message-pop-box').find('.message-btn').attr('href', data.link).show();
	}else{
		$('.message-pop-box').find('.message-btn').hide();
	}
	
	if(data.content || data.link){
		$('.message-pop-box').removeClass('down').addClass('up');
	}
	
	try {
		if(refresh_order && typeof(refresh_order) == "function") { 
			refresh_order();
        } 
    } catch(e) {}
}
$('.message-pop-box .close').click(function() {
	$('.message-pop-box').removeClass('up').addClass('down');
});
//用户信息
$(".admin").mouseenter(function() {
	window.focus();
	$("#admin-panel").show();
}).mouseleave(function() {
	$("#admin-panel").hide();
});
</script>
<script type="text/javascript">
	var clipboard = new Clipboard('.btn-copy');
    clipboard.on('success', function(e) {
        $.msg('复制成功');
    });
    clipboard.on('error', function(e) {
    	$.msg('复制失败');
    });
 	// 更新后台主框架消息弹窗
	function update_message() {
		// 是否重新获取数据
		if ($("#message-panel").html().length > 0) {
			// if (parseInt($("#counts_all").val()) != 0) {
			var time_step = 5; // 最小刷新间隔，单位：秒
			var this_time = new Date();
			if ((parseInt($("#counts_time").val()) + parseInt(time_step)) > parseInt(this_time.getTime() / 1000)) {
				return true;
			}
			// }
		}
		$.ajax({
			type: 'GET',
			url: '/site/update-message.html',
			data: {},
			dataType: 'json',
			success: function(result) {
				if (result.code == 0) {
					$("#message-panel").html(result.data);
				} else if (result.code == 1) {
				} else {
					$.msg(result.message);
				}
			}
		});
	}
	// 消息通知
	$("#message-box").mouseenter(function() {
		update_message();
		window.focus();
		$("#message-panel").show();
	}).mouseleave(function() {
		$("#message-panel").hide();
	}).find(".close").click(function() {
		$("#message-panel").hide();
	});
</script>

</html>

