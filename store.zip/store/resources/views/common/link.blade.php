	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta name="csrf-param" content="_csrf">
		<meta name="csrf-token" content="{{ csrf_token() }}">

		<title>商品列表</title>
		<!-- 禁止搜索引擎收录 -->
		<meta name="robots" content="noarchive">
		<meta name="baidspider" content="noarchive">
		<meta name="googlebot" content="noarchive">
		<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport">
		<meta content="" name="description">
		<meta content="" name="author">
		<!-- 网站头像 -->
		<link rel="icon" type="image/x-icon" href="http://68dsw.oss-cn-beijing.aliyuncs.com/images/system/config/website/favicon_0.jpg">
		<link rel="shortcut icon" type="image/x-icon" href="http://68dsw.oss-cn-beijing.aliyuncs.com/images/system/config/website/favicon_0.jpg">
		<meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,Chrome=1">


		<!-- ================== BEGIN BASE CSS STYLE ================== -->
		<link rel="stylesheet" href="/static/css/font-awesome.min.css">
		<link rel="stylesheet" href="/static/css/jquery.mCustomScrollbar.css">
		<link rel="stylesheet" href="/static/css/bootstrap.min.css">
		<link rel="stylesheet" href="/static/css/animate.css">
		<link rel="stylesheet" href="/static/css/bootstrap-switch.min.css">
		<link rel="stylesheet" href="/static/css/chosen.css">
		<link rel="stylesheet" href="/static/css/common.css">
		<link rel="stylesheet" href="/static/css/seller.css">
		<!-- -->
		<link rel="stylesheet" href="/static/css/mj-style.css">
		<!-- ================== END BASE CSS STYLE ================== -->
		<!--[if lt IE 9]>
		      <script src="/static/js/html5shiv.min.js?v=20180027"></script>
		      <script src="/static/js/respond.min.js?v=20180027"></script>
		    <![endif]-->
		<!-- ================== BEGIN BASE JS ================== -->
		<script src="/static/js/CLodopfuncs.js?priority=0"></script>
		<script src="/static/js/CLodopfuncs.js?priority=1"></script>
		<script src="/static/js/jquery.js"></script>
		<!-- 加载Layer插件 -->
		<script src="/static/js/layer.js."></script>
		<link rel="stylesheet" href="/static/css/layer.css" id="layuicss-layer">
		<script src="/static/js/jquery.method.js"></script>
		<script src="/static/js/jquery.modal.js"></script>
		
		<script src="/static/js/bootstrap.min.js"></script>
		<script src="/static/js/bootstrap-switch.min.js"></script>
		<script src="/static/js/jquery.mousewheel.min.js"></script>
		<script src="/static/js/jquery.mCustomScrollbar.js"></script>
		<script src="/static/js/jquery.chosen.js"></script>
		<script src="/static/js/jquery.tablelist.js"></script>
		<script src="/static/js/common.js"></script>
		<script src="/static/js/jquery.cookie.js"></script>
		<script src="/static/js/clipboard.min.js"></script>
		
		<script src="/static/newjs/imgPreview.js"></script>
		<!-- 图片缓载js -->
		<script src="/static/newjs/jquery.lazyload.js"></script>
		<!-- 表单验证 -->
		<script src="/static/newjs/jquery.validate.js"></script>
		<script src="/static/newjs/jquery.validate.custom.js"></script>
		<script src="/static/newjs/messages_zh.js"></script>
		<!-- 加载Chosen插件 END-->
		<script src="/static/js/common.js"></script>
		 <script src="/static/js/LodopAuto.js"></script> <script type="text/javascript">
		// 返回顶部js
		$(window).scroll(function() {
			var position = $(window).scrollTop();
			if (position >0) {
				$('.totop').removeClass('bounceOut').addClass('animated bounceIn');
			} else {
				$('.totop').removeClass('bounceIn').addClass('animated bounceOut');
			}
		});

		</script>
		<!-- ================== END BASE JS ================== -->
		<script type="text/javascript">
		$().ready(function() {		
					
																																			
							$(".totop").click(function() {
					$("html, body").animate({
						scrollTop: 0
					}, 600);
					return false;
				});
			});
		</script>
		<script src="/static/js/bootstrap-editable.js"></script>
		<link rel="stylesheet" href="/static/css/bootstrap-editable.css">
		<link rel="stylesheet" href="/static/css/styles.css">
	</head>