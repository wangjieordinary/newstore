<div class="footer">
			<div class="wrapper">
				<p class="footer-link">
					
					<!---->
					
					<a href="#" target="_blank">公司简介</a>
					
					
					<!---->
					
					<em>|</em>
					
					<a href="#" target="_blank">联系我们</a>
					
					
					<!---->
					
					<em>|</em>
					
					<a href="#" target="_blank">官网论坛</a>
					
					
					<!---->
					
					<em>|</em>
					
					<a href="#" target="_blank">代理合作</a>
					
					
					<!---->
					
					<em>|</em>
					
					<a href="#" target="_blank">帮助中心</a>
					
					
					<!---->
					
					<em>|</em>
					
					<a href="#" target="_blank">商家入驻</a>
					
					
					<!---->
					
					<em>|</em>
					
					<a href="#" target="_blank">联系我们</a>
					
					
				</p>
				<font>
					Copyright  中国农民自由贸易网 版权所有
					<a class="c-ccc m-l-10" href="javascript:;" target="_blank">冀ICP备07501206号-2</a>
				</font>
				
				<p><!--<span class="vol">
	<b>Powered by</b>
	<a style="color: #4FC0E8;" href="http://www.68mall.com" target="_blank">商之翼</a>
	· 翼商城
</span>-->
</p><div class="copyright">
	<p>
		<a href="#" target="_blank" class="copyright-logo">
			提供技术支持
		</a>
	</p>
</div>
<p></p>
				
			</div>
		</div>

		<!--返回顶部-->
		<a class="totop animation" href="javascript:;">
			<i class="fa fa-angle-up"></i>
		</a>
	</div>

	<form id="__SZY_TO_URL_FORM__" method="GET"></form>

	<!--右下角消息提醒弹窗-->
	<div class="message-pop-box down">
		<div class="message-title">
			<h5>
				<i class="news-icon"></i>
				消息提醒
			</h5>
			<a class="close" href="javascript:void(0);">×</a>
		</div>
		<div class="message-info">
			<div class="message-icon"></div>
			<h5>
				<span id="message-pop-text"></span>
			</h5>
			<a class="btn btn-primary btn-sm message-btn" href="javascript:void(0);" target="_blank">立即处理</a>
		</div>
	</div>
	<!-- 店铺即将到期提醒弹框，宽度给600即可-->
	<div class="modal-body" style="display: none">
		<div class="f14 p-10">
			<p class="m-b-5">
				欢迎是用xxx商城系统，您的店铺服务将于
				<span class="c-red">2017-02-30</span>
				日到期/已过期，将影响您店铺的正常运营，建议尽快进行续费！

			</p>
			<p class="m-b-5">
				续费流程：前往
				<span class="c-red">
					“店铺 -&gt; 店铺信息 -&gt;
					<a href="http://seller.68dsw.com/goods/shop/shop-info/renew-list">续签列表</a>
					”
				</span>
				进行线上提交续签申请，线下联系平台方管理员进行缴纳费用！
			</p>

		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-primary" data-dismiss="modal">确定</button>
		</div>
	</div>

	<!--店铺关闭提示-->
	<div class="store-close-box hide">
		<a class="store-close">×</a>
		<span class="store-mark">店铺已关闭，请联系平台管理员</span>
	</div>