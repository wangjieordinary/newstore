<!DOCTYPE html>
<!--[if IE 8]> <html lang="zh-CN" class="ie8"> <![endif]-->
<html lang="zh-CN">
@include('common.link')
<body class="style-seller">
	
	@include('common.header')
	
	<!--中间内容-->
	<div class="seller-center">
		<div class="wrapper">
			
			<!--左侧部分-->
			@include('common.slider')
			
			<!--右侧内容-->
			<div class="seller-rihgt">
				<div class="seller-page">
					<div class="seller-page-bg"></div>
					<!--在这里调用内容-->
					<div class="page">
	<!-- 标题栏 -->
	<div class="fixed-bar">
	<div class="item-title">
		<div class="subject">
			<h3>
				<span class="action">规格管理 - 添加规格</span>
				<!--帮助教程-->
                <!--<a class="help-href" href="javascript:;" data-toggle="tooltip" data-placement="auto bottom" title="点击跳转到该模块教程页面"><i class="help-icon"></i></a>-->
                <!--- -->
			</h3>
			
			<h5>
				
								
								<span class="action-span">
					
										
					<a  href="list" class="btn btn-warning click-loading">
						<i class="fa fa-reply"></i>
						返回规格列表
					</a>
				</span>
				
			</h5>
			
					</div>
	</div>
</div>
 
	<!-- 温馨提示 -->
	
	<div class="table-content m-t-30 clearfix">

		<form id="Attribute" class="form-horizontal" name="Attribute" action="{{url('store/spec/doadd')}}" method="POST">
		@csrf
		<!-- 隐藏域 -->
		<input type="hidden" id="attribute-attr_id" class="form-control" name="Attribute[attr_id]">
		
		<input type="hidden" id="attribute-is_spec" class="form-control" name="Attribute[is_spec]" value="1">
		
		<input type="hidden" id="attribute-is_index" class="form-control" name="Attribute[is_index]" value="0">
		
		<input type="hidden" id="attribute-is_linked" class="form-control" name="Attribute[is_linked]" value="0">
		<!-- 名称 -->
		<div class="simple-form-field" >
<div class="form-group">
<label for="attribute-attr_name" class="col-sm-4 control-label">
<span class="text-danger ng-binding">*</span>
<span class="ng-binding">规格名称：</span>
</label>
<div class="col-sm-8">
<div class="form-control-box">

		
		<input type="text" id="attribute-attr_name" class="form-control" name="Attribute[attr_name]"><i class="fa fa-question-circle f16 c-ddd m-l-10 cur-p" data-toggle="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="<img width='200' height='155' src='/images/goods/spec-sample.png'>"></i>
		
		
</div>

<div class="help-block help-block-t"></div>
</div>
</div>
</div>
		<!-- 描述 -->
		<div class="simple-form-field" >
<div class="form-group">
<label for="attribute-attr_remark" class="col-sm-4 control-label">

<span class="ng-binding">规格描述：</span>
</label>
<div class="col-sm-8">
<div class="form-control-box">

		
		<textarea id="attribute-attr_remark" class="form-control" name="Attribute[attr_remark]" rows="5"></textarea>
		
		
</div>

<div class="help-block help-block-t"></div>
</div>
</div>
</div>
		<!-- 规格值列表 -->
		<div class="simple-form-field" >
<div class="form-group">
<label for="" class="col-sm-4 control-label">
<span class="text-danger ng-binding">*</span>
<span class="ng-binding">规格值：</span>
</label>
<div class="col-sm-8">
<div class="form-control-box">

		
		
				
		<div id="values_select" class='attr-values-area'>
			<ul class="attr-values">
				
				
				<li class="m-b-10 new-attr-value">
					<input type="hidden" class="form-control" name="attr_vid" value="0">
					
					<input type="text" class="form-control" name="attr_vname" placeholder="请输入规格可选值" data-rule-maxlength="30" data-msg-maxlength="规格值最大不能超过30个字符">
					
					<!-- <input type="text" id="attrvalue-attr_vsort" class="form-control small m-l-10" name="attr_vsort" placeholder="排序" data-rule-integer="true" data-rule-min="0" data-rule-max="255"> -->
					<input type="button" value="移除" class="btn btn-danger btn-sm m-l-10 m-t-3 del-attr-value" />
					<label style="display: none;">
						<input type='hidden' value="0" name='is_delete' />
					</label>
				</li>
				<li class="m-b-10 new-attr-value">
					<input type="hidden" class="form-control" name="attr_vid" value="0">
					
					<input type="text" class="form-control" name="attr_vname" placeholder="请输入规格可选值" data-rule-maxlength="30" data-msg-maxlength="规格值最大不能超过30个字符">
					
					<!-- <input type="text" id="attrvalue-attr_vsort" class="form-control small m-l-10" name="attr_vsort" placeholder="排序" data-rule-integer="true" data-rule-min="0" data-rule-max="255"> -->
					<input type="button" value="移除" class="btn btn-danger btn-sm m-l-10 m-t-3 del-attr-value" />
					<label style="display: none;">
						<input type='hidden' value="0" name='is_delete' />
					</label>
				</li>
				<li class="m-b-10 new-attr-value">
					<input type="hidden" class="form-control" name="attr_vid" value="0">
					
					<input type="text" class="form-control" name="attr_vname" placeholder="请输入规格可选值" data-rule-maxlength="30" data-msg-maxlength="规格值最大不能超过30个字符">
					
					<!-- <input type="text" id="attrvalue-attr_vsort" class="form-control small m-l-10" name="attr_vsort" placeholder="排序" data-rule-integer="true" data-rule-min="0" data-rule-max="255"> -->
					<input type="button" value="移除" class="btn btn-danger btn-sm m-l-10 m-t-3 del-attr-value" />
					<label style="display: none;">
						<input type='hidden' value="0" name='is_delete' />
					</label>
				</li>
				
			</ul>
			<a id="add_attribute_value" href="javascript:void(0);" class="btn btn-warning btn-sm">
				<i class="fa fa-plus"></i>
				<!-- 继续添加规格值 -->
				添加规格值
			</a>
		</div>
		
</div>

<div class="help-block help-block-t"></div>
</div>
</div>
</div>
		
		<!-- 排序 -->
		<div class="simple-form-field" >
<div class="form-group">
<label for="attribute-attr_sort" class="col-sm-4 control-label">
<span class="text-danger ng-binding">*</span>
<span class="ng-binding">排序：</span>
</label>
<div class="col-sm-8">
<div class="form-control-box">

		
		<input type="text" id="attribute-attr_sort" class="form-control small" name="Attribute[attr_sort]" value="255">
		
		
</div>

<div class="help-block help-block-t"><div class="help-block help-block-t">控制商家发布商品页面，规格展示顺序，数字范围为0~255，数字越小越靠前</div></div>
</div>
</div>
</div>
		<!-- 确认提交 -->
		<div class="simple-form-field" >
<div class="form-group">
<label for="" class="col-sm-4 control-label">


</label>
<div class="col-sm-8">
<div class="form-control-box">

		<input type="button" class="btn btn-primary" id="btn_submit" name="btn_submit" value="确认提交" />
		
</div>

<div class="help-block help-block-t"></div>
</div>
</div>
</div>
	</div>
	</form>
</div>
<!-- JSON2 -->
<script src="/static/js/jquery.json-2.4.js?v=20180027"></script>
<!-- 双向选择器:css -->
<link rel="stylesheet" href="/static/css/selector/jquery.multiselect2side.css?v=20181020"/>
<!-- 验证规则 -->
<script id="client_rules" type="text">
[{"id": "attribute-attr_name", "name": "Attribute[attr_name]", "attribute": "attr_name", "rules": {"required":true,"messages":{"required":"规格名称不能为空。"}}},{"id": "attribute-attr_style", "name": "Attribute[attr_style]", "attribute": "attr_style", "rules": {"required":true,"messages":{"required":"规格样式不能为空。"}}},{"id": "attribute-type_id", "name": "Attribute[type_id]", "attribute": "type_id", "rules": {"required":true,"messages":{"required":"商品类型ID不能为空。"}}},{"id": "attribute-shop_id", "name": "Attribute[shop_id]", "attribute": "shop_id", "rules": {"required":true,"messages":{"required":"店铺ID不能为空。"}}},{"id": "attribute-attr_sort", "name": "Attribute[attr_sort]", "attribute": "attr_sort", "rules": {"required":true,"messages":{"required":"排序不能为空。"}}},{"id": "attribute-type_id", "name": "Attribute[type_id]", "attribute": "type_id", "rules": {"integer":{"pattern":"/^\\s*[+-]?\\d+\\s*$/"},"messages":{"integer":"商品类型ID必须是整数。"}}},{"id": "attribute-shop_id", "name": "Attribute[shop_id]", "attribute": "shop_id", "rules": {"integer":{"pattern":"/^\\s*[+-]?\\d+\\s*$/"},"messages":{"integer":"店铺ID必须是整数。"}}},{"id": "attribute-par_attr_id", "name": "Attribute[par_attr_id]", "attribute": "par_attr_id", "rules": {"integer":{"pattern":"/^\\s*[+-]?\\d+\\s*$/"},"messages":{"integer":"上级规格ID必须是整数。"}}},{"id": "attribute-attr_vid", "name": "Attribute[attr_vid]", "attribute": "attr_vid", "rules": {"integer":{"pattern":"/^\\s*[+-]?\\d+\\s*$/"},"messages":{"integer":"规格值ID必须是整数。"}}},{"id": "attribute-is_spec", "name": "Attribute[is_spec]", "attribute": "is_spec", "rules": {"integer":{"pattern":"/^\\s*[+-]?\\d+\\s*$/"},"messages":{"integer":"是否为规格属性必须是整数。"}}},{"id": "attribute-attr_style", "name": "Attribute[attr_style]", "attribute": "attr_style", "rules": {"integer":{"pattern":"/^\\s*[+-]?\\d+\\s*$/"},"messages":{"integer":"规格样式必须是整数。"}}},{"id": "attribute-is_index", "name": "Attribute[is_index]", "attribute": "is_index", "rules": {"integer":{"pattern":"/^\\s*[+-]?\\d+\\s*$/"},"messages":{"integer":"是否检索必须是整数。"}}},{"id": "attribute-is_linked", "name": "Attribute[is_linked]", "attribute": "is_linked", "rules": {"integer":{"pattern":"/^\\s*[+-]?\\d+\\s*$/"},"messages":{"integer":"是否关联相同规格商品必须是整数。"}}},{"id": "attribute-is_show", "name": "Attribute[is_show]", "attribute": "is_show", "rules": {"integer":{"pattern":"/^\\s*[+-]?\\d+\\s*$/"},"messages":{"integer":"显示必须是整数。"}}},{"id": "attribute-attr_name", "name": "Attribute[attr_name]", "attribute": "attr_name", "rules": {"string":true,"messages":{"string":"规格名称必须是一条字符串。","maxlength":"规格名称只能包含至多10个字符。"},"maxlength":10}},{"id": "attribute-attr_remark", "name": "Attribute[attr_remark]", "attribute": "attr_remark", "rules": {"string":true,"messages":{"string":"规格描述必须是一条字符串。","maxlength":"规格描述只能包含至多255个字符。"},"maxlength":255}},{"id": "attribute-attr_sort", "name": "Attribute[attr_sort]", "attribute": "attr_sort", "rules": {"integer":{"pattern":"/^\\s*[+-]?\\d+\\s*$/"},"messages":{"integer":"排序必须是整数。","min":"排序必须不小于0。","max":"排序必须不大于255。"},"min":0,"max":255}},]
</script>
<script type="text/javascript">
	$().ready(function() {
		$("[data-toggle='popover']").popover();
		//var validator = $("#Attribute").validate();
		// 验证规则，此验证规则会影响编辑器中JavaScript的的格式化操作
		//$.validator.addRules($("#client_rules").html());
		$("#btn_submit").click(function() {
			/*if (!validator.form()) {
				return;
			}*/

			var url = $("#Attribute").attr("action");
			var data = $("#Attribute").remove(".attr-values-area").serializeJson();

			data = {
				_csrf: data._csrf,
				Attribute: data.Attribute,
				attr_values: data.attr_values
			};

			var attr_values = [];

			var message = null;

			$(".attr-values-area:visible").each(function() {
				if ($(this).attr("id") == "values_select") {
					$(this).find(".attr-value,.new-attr-value").each(function() {
						/*if ($(this).find("[name='attr_vsort']").valid() == false) {
							$(this).find("[name='attr_vsort']").focus();
							message = "规格值排序输入错误！";
							return false;
						}*/

						var object = $(this).serializeJson();
						if ($.trim(object.attr_vname) != '') {
							attr_values.push(object);
						}
					});
				}
			});

			if (message != null) {
				$.msg(message);
				return;
			}

			if (attr_values.length == 0) {
				$.msg("规格值不能为空！");
				return;
			}

			data.attr_values = attr_values;

			data = JSON.stringify(data);

			//加载提示
			$.loading.start();

			$.post(url, {
				data: data
			}, function(result) {
				if (result.code == 0) {
					$.msg(result.message);
					if (result.data) {
						$.loading.start();
						$.go(result.data);
					}
				} else {
					$.msg(result.message, {
						time: 5000
					});
				}
			}, "json").always(function() {
				$.loading.stop();
			});
		});

		// 模板
		var attr_value_tpl = $(".attr-values").find("li:last").clone();

		if ($(".new-attr-value").size() == 1) {
			$(".new-attr-value").find(".del-attr-value").prop("disabled", true);
		}

		// 继续添加规格值的点击事件
		$("#add_attribute_value").click(function() {
			$(".attr-values").append($(attr_value_tpl).clone());
			if ($(".new-attr-value").size() > 1) {
				$(".new-attr-value").find(".del-attr-value").prop("disabled", false);
			}
		});

		// 删除规格
		$('body').on("click", ".del-attr-value", function() {
			$(this).parents(".new-attr-value").remove();
			if ($(".new-attr-value").size() == 1) {
				$(".new-attr-value").find(".del-attr-value").prop("disabled", true);
			}
		})

		// 删除提示
		$(".delete_label").mouseover(function() {
			var element = this;
			$.tips("被勾选“删除”的规格值将在您点击“确认提交”按钮后被系统删除，请谨慎操作！", this, {
				time: 0
			});
		}).mouseout(function() {
			$.closeAll("tips");
		});

	});
</script>
					
				</div>
			</div>
		</div>
		<!--底部内容-->
		@include('common.footer')
</body>

<script type="text/javascript">
function toFirst(target){
	var url = $(target).parents("li").find(".sub-list").find("li:first").find("a").attr("href");
	$.go(url);
}
function to(url, target){
	
}

function clearCache(){
	// 缓载
	$.loading.start();
	$.post("/site/clear-cache", {}, function(result){
		if(result.code == 0){
			$.msg(result.message);
		}else{
			$.msg(result.message, {
				time: 5000
			});
		}
	}).always(function(){
		$.loading.stop();
	});
}
// 登录成功关闭弹出框
$.login.success = function(){
	// 关闭并销毁登录窗口
	$.login.close(true);
}
</script>

<script type="text/javascript">
	// setInterval("auto_print()",10000);
	function auto_print(order_id)
	{
		$.ajax({
			type: "GET",
			url: "/site/auto-print",
			dataType: "json",
			data: {
				order_id: order_id
			},
			success: function(result) {
				if(result.code == 0)
				{
					lodop_print_html(result.print_title, result.data,result.printer);
				}
			}
		});
	}
</script>

<!-- 加载消息监听js-->
<script src="/assets/d2eace91/js/message/message.js?v=20180027"></script>
<script src="/assets/d2eace91/js/message/messageWS.js?v=20180027"></script>
<script type="text/javascript">
//声音监听
WS_AddUser({
	'user_id': 'shop_1717',
	'url': "ws://push.yunmall.68mall.com:7272",
	'type': "add_user"
}); 
//右下角消息提醒弹窗js
function open_message_box(data) {
	if (!data) {    
		data = {};
    }
	
	var src = window.location.href;
	
	// 如果当前框架中的链接地址和弹框的链接地址一致则不弹框
	if(data.auto_refresh == 1 && data.link && src.indexOf(data.link) != -1){
		
		var contentWindow = window;
		
		if(contentWindow.tablelist){
			contentWindow.tablelist.load({
				page: {
					cur_page: 1
				}
			});
		}else{
			contentWindow.location.reload();
		}
		
		return;
	}
	
	$('.message-pop-box').find('#message-pop-text').html(data.content);
	
	if(data.link){
		$('.message-pop-box').find('.message-btn').attr('href', data.link).show();
	}else{
		$('.message-pop-box').find('.message-btn').hide();
	}
	
	if(data.content || data.link){
		$('.message-pop-box').removeClass('down').addClass('up');
	}
	
	try {
		if(refresh_order && typeof(refresh_order) == "function") { 
			refresh_order();
        } 
    } catch(e) {}
}
$('.message-pop-box .close').click(function() {
	$('.message-pop-box').removeClass('up').addClass('down');
});
//用户信息
$(".admin").mouseenter(function() {
	window.focus();
	$("#admin-panel").show();
}).mouseleave(function() {
	$("#admin-panel").hide();
});
</script>
<script type="text/javascript">
	var clipboard = new Clipboard('.btn-copy');
    clipboard.on('success', function(e) {
        $.msg('复制成功');
    });
    clipboard.on('error', function(e) {
    	$.msg('复制失败');
    });
 	// 更新后台主框架消息弹窗
	function update_message() {
		// 是否重新获取数据
		if ($("#message-panel").html().length > 0) {
			// if (parseInt($("#counts_all").val()) != 0) {
			var time_step = 5; // 最小刷新间隔，单位：秒
			var this_time = new Date();
			if ((parseInt($("#counts_time").val()) + parseInt(time_step)) > parseInt(this_time.getTime() / 1000)) {
				return true;
			}
			// }
		}
		$.ajax({
			type: 'GET',
			url: '/site/update-message.html',
			data: {},
			dataType: 'json',
			success: function(result) {
				if (result.code == 0) {
					$("#message-panel").html(result.data);
				} else if (result.code == 1) {
				} else {
					$.msg(result.message);
				}
			}
		});
	}
	// 消息通知
	$("#message-box").mouseenter(function() {
		update_message();
		window.focus();
		$("#message-panel").show();
	}).mouseleave(function() {
		$("#message-panel").hide();
	}).find(".close").click(function() {
		$("#message-panel").hide();
	});
</script>

</html>

