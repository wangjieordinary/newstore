<div id="tablelist" class="attachment-box">
	<ul class="image-list">
		@foreach($imageslist as $imageslist)
		<!--点击添加selected样式，则为已选中状态-->
		<li class="image-item" title="上传时间：{{date('Y-m-d H:i:s', $imageslist->add_time)}}" data-id="{{$imageslist->id}}">
			<img class="image-box" src="{{$imageslist->image_url}}" data-path="{{$imageslist->image_url}}" data-url="{{$imageslist->image_url}}" data-width="{{$imageslist->width}}" data-height="{{$imageslist->height}}" />
			<div class="image-meta">{{$imageslist->width}}*{{$imageslist->height}}</div>
			<div class="image-title">{{$imageslist->title}}</div>
			<div class="attachment-selected"><i class="fa fa-check"></i></div>
		</li>
		@endforeach
	</ul>
		<!--分页-->
		<div class="text-r page-box">
			<div id="pagination">
				<script data-page-json="true" type="text">
				{"page_key":"page","page_id":"pagination","default_page_size":10,"cur_page":{{$page}},"page_size":"10","page_size_list":[10,50,500,1000],"record_count":7,"page_count":1,"offset":{{$offset}},"url":null,"sql":null}</script>
				<ul class="pagination">
					<li class="disabled" style="display: none;">
						<a class="fa fa-angle-double-left" data-go-page="1" title="第一页"></a>
					</li>
					<li class="disabled">
						<a class="fa fa-angle-left" title="上一页"></a>
					</li>
					<!--   -->
					@for($i=1;$i<=$pagestr;$i++)
									@if($page==$i){
										<li class="active">
											<a data-cur-page="{{$i}}">{{$i}}</a>
										</li>
									@else
										<li>
										<a href="javascript:void(0);" data-go-page="{{$i}}">{{$i}}</a>
										</li>
									@endif
								@endfor
					<li class="disabled">
						<a class="fa fa-angle-right" title="下一页"></a>
					</li>
					<li class="disabled" style="display: none;">
						<a class="fa fa-angle-double-right" data-go-page="1" title="最后一页"></a>
					</li>
				</ul>
			</div>
		</div>
	</div>