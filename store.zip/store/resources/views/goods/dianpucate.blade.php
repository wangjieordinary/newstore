<div class="simple-form-field toggle hide">
	<div class="form-group">
		<label class="control-label">
			<span>店铺商品分类：</span>
		</label>
		<div class="form-control-wrap">
			
			<div class="chosen-container chosen-container-single" title="" style="width: 120px;" id="searchmodel_scid_chosen">
				<a class="chosen-single" tabindex="-1">
					<span>-- 请选择分类 --</span>
					<div>
						<b></b>
					</div>
				</a>
				<div class="chosen-drop">
					<div class="chosen-search">
						<input type="text" autocomplete="off">
					</div>
					<ul class="chosen-results"></ul>
				</div>
			</div>
			<select id="searchmodel-scid" class="form-control chosen-select" name="scid" data-width="120" style="display: none;">
				<option value="">-- 请选择分类 --</option>
				<option value="289">◢&nbsp;坚果炒货</option>
				<option value="290">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;夏威夷果</option>
				<option value="291">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;巴旦木</option>
				<option value="292">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;松子</option>
				<option value="293">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;开心果</option>
				<option value="294">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;碧根果</option>
				<option value="295">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;腰果</option>
				<option value="296">◢&nbsp;肉干肉脯</option>
				<option value="297">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;猪肉</option>
				<option value="298">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;牛肉</option>
				<option value="299">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;鸭肉</option>
				<option value="300">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;鸡肉</option>
				<option value="301">◢&nbsp;果干蜜饯</option>
				<option value="302">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;葡萄干</option>
				<option value="303">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;芒果干</option>
				<option value="304">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;枣</option>
				<option value="305">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;草莓干</option>
				<option value="306">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;猕猴桃干</option>
				<option value="307">◢&nbsp;水果生鲜</option>
				<option value="308">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;蔬菜</option>
				<option value="309">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;水果</option>
				<option value="310">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;肉类</option>
				<option value="311">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;鱼类</option>
				<option value="312">◢&nbsp;休闲零食</option>
				<option value="313">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;饼干糕点</option>
			</select>
		</div>
	</div>
</div>