<!-- <div class="category-search">
				<form id="searchForm" name="searchForm" action="http://seller.68dsw.com/goods/publish/add.html">
					<div class="simple-form-field">
						<div class="form-group">
							<label class="control-label">
								<span>商品分类搜索：</span>
							</label>
							<div class="form-control-wrap">
								<input id="cat_name" name="cat_name" class="form-control" type="text" placeholder="分类名称">
							</div>
						</div>
					</div>
					<div class="simple-form-field m-l-10">
						<button id="btn_search" class="btn btn-primary">快速查找</button>
					</div>
				</form>
				
				当没有最近使用分类的时候，以下内容可隐藏
				<div class="clear"></div>
				<div class="simple-form-field m-t-10">
					<div class="form-group">
						<label class="control-label">
							<span>最近使用的分类：</span>
						</label>
						<div class="form-control-wrap">
							
							<select id="used_cat_list" class="form-control chosen-select" style="display: none;">
								<option value="0">--请选择--</option>
								<option value="353" class="category-name" data-cat-ids="271,308,353" data-type="1" data-search="true" data-id="353" data-is-parent="0" data-level="3">生鲜食品&nbsp;&gt;&gt;&nbsp;猪牛羊肉&nbsp;&gt;&gt;&nbsp;羊肉</option>
								
								
								
								<option value="351" class="category-name" data-cat-ids="271,307,351" data-type="1" data-search="true" data-id="351" data-is-parent="0" data-level="3">生鲜食品&nbsp;&gt;&gt;&nbsp;海鲜水产&nbsp;&gt;&gt;&nbsp;特色水产</option>
								
								
								
								<option value="340" class="category-name" data-cat-ids="271,307,340" data-type="1" data-search="true" data-id="340" data-is-parent="0" data-level="3">生鲜食品&nbsp;&gt;&gt;&nbsp;海鲜水产&nbsp;&gt;&gt;&nbsp;虾</option>
								
								
								
								<option value="343" class="category-name" data-cat-ids="271,307,343" data-type="1" data-search="true" data-id="343" data-is-parent="0" data-level="3">生鲜食品&nbsp;&gt;&gt;&nbsp;海鲜水产&nbsp;&gt;&gt;&nbsp;贝</option>
								
							</select>
						</div>
					</div>
				</div>
				
			</div> -->