<!DOCTYPE html>
<html lang="zh-CN">
	@include('common.link')
	<body class="style-seller">
	<!-- 头部模板 -->
	@include('common.header')

	<!--中间内容-->
	<div class="seller-center">
		<div class="wrapper">
			<!-- 左侧导航 -->
			@include('common.slider')
			<!--右侧内容-->
			<div class="seller-rihgt">
				<div class="seller-page">
					<div class="seller-page-bg"></div>
					<!--在这里调用内容-->
					<div class="page">
						<div class="fixed-bar">
							<div class="item-title">
								<div class="subject">
									<h3>
										<span class="action">商品管理 - 列表</span>
										<!--帮助教程-->
						                <!--<a class="help-href" href="javascript:;" data-toggle="tooltip" data-placement="auto bottom" title="点击跳转到该模块教程页面"><i class="help-icon"></i></a>-->
						                <!-- -->
									</h3>
									<h5>
										<span class="action-span">
											<a href="/goods/list/batch-edit.html" class="btn btn-warning click-loading">
												<i class="fa fa-cloud-upload"></i>
												批量更新商品价格、库存
											</a>
										</span>
										<span class="action-span">
											<a href="/goods/list/batch-add.html" class="btn btn-warning click-loading">
												<i class="fa fa-cloud-upload"></i>
												批量上传商品
											</a>
										</span>
									</h5>
								</div>
							</div>
						</div>
						<!-- 温馨提示 -->
	
						<!--搜索-->
						<div class="search-term m-b-10">
							<form id="SearchModel" name="SearchModel" action="/goods/list/index.html" method="POST">
								@csrf
								<div class="simple-form-field">
									<div class="form-group">
										<label class="control-label">
											<span>条形码：</span>
										</label>
										<div class="form-control-wrap">
											<input type="text" id="searchmodel-goods_barcode" class="form-control" name="goods_barcode" placeholder="请输入正确的条形码">
										</div>
									</div>
								</div>
								<div class="simple-form-field">
									<div class="form-group">
										<label class="control-label">
											<span>关键字：</span>
										</label>
										<div class="form-control-wrap">
											
											<input type="text" id="searchmodel-keyword" class="form-control" name="keyword" placeholder="商品ID/货号/名称">
											
										</div>
									</div>
								</div>
								<div class="simple-form-field">
									<div class="form-group">
										<label class="control-label">
											<span>分类：</span>
										</label>
										<div class="form-control-wrap">
											@include('common.select')
										</div>
									</div>
								</div>
								<div class="simple-form-field toggle hide">
									<div class="form-group">
										<label class="control-label">
											<span>隶属网点：</span>
										</label>
										<div class="form-control-wrap">
											<div class="chosen-container chosen-container-single" title="" style="width: 120px;" id="searchmodel_store_id_chosen">
												<a class="chosen-single" tabindex="-1">
													<span>请选择</span>
													<div>
														<b></b>
													</div>
												</a>
												<div class="chosen-drop">
													<div class="chosen-search">
														<input type="text" autocomplete="off">
													</div>
													<ul class="chosen-results"></ul>
												</div>
											</div>
											<select id="searchmodel-store_id" class="form-control chosen-select" name="store_id" data-width="120" style="display: none;">
												<option value="">请选择</option>
												<option value="41">三只松鼠网点</option>
											</select>
										</div>
									</div>
								</div>
								@include('goods.dianpucate')
								<!--新加 start-->
								<div class="simple-form-field toggle hide" style="display:none">
									<div class="form-group">
										<label class="control-label">
											<span>预售商品：</span>
										</label>
										<div class="form-control-wrap">
											<select class="form-control">
								            	<option value="0">请选择</option>
								                <option value="1">是</option>
								                <option value="2">否</option>
								            </select>
										</div>
									</div>
								</div>
								<div class="simple-form-field toggle hide">
									<div class="form-group">
										<label class="control-label">
											<span>销售模式：</span>
										</label>
										<div class="form-control-wrap">
											<select id="searchmodel-sales_model" class="form-control" name="sales_model" data-width="120">
												<option value="">全部</option>
												<option value="0">零售</option>
												<option value="1">批发</option>
											</select>
										</div>
									</div>
								</div>
								<div class="simple-form-field toggle hide">
									<div class="form-group">
										<label class="control-label">
											<span>库存：</span>
										</label>
										<div class="form-control-wrap">
											
											<input type="text" id="searchmodel-start_stock" class="form-control small" name="start_stock">
											-
											<input type="text" id="searchmodel-end_stock" class="form-control small" name="end_stock">
											
										</div>
									</div>
								</div>
								<!--新加 end-->
								<div class="simple-form-field">
									<input type="button" id="btn_search" value="搜索" class="btn btn-primary m-r-5">
										
									<input type="button" id="btn_export" value="导出" class="btn btn-default m-r-5">
									
									<a id="searchMore" class="btn-link">更多筛选条件</a>
									</div>
								</form>
								<script type="text/javascript">
									$().ready(function() {
										$("input[name=goods_barcode]").focus();
										//条形码扫描触发事件
										$("input[type=text]").bind("keypress", function(event) {
											if (event.keyCode == "13") {
												$("#btn_search").click();
											}
										});
									})
								</script>
								</div>
								<!-- 工具栏（列表名称、列表显示项设置） -->
								<div class="common-title">
									<div class="ftitle">
										<h3>商品列表</h3>
										<h5>
										<!-- data-total-record="true" -->
											(共<span>{{$procount}}</span>条记录)
										</h5>		
									</div>
									<div class="operate m-l-20">
										<a class="reload" href="javascript:tablelist.load();" data-toggle="tooltip" data-placement="auto bottom" title="" data-original-title="刷新数据">
											<i class="fa fa-refresh"></i>
										</a>
									</div>
								</div>
	<!--列表内容-->
	<table id="table_list" class="table table-hover">
		<thead>
			<tr>
				<th class="tcheck">
					<input type="checkbox" class="table-list-checkbox-all" title="全选/全不选">
				</th>
				<th class="text-c" data-sortname="goods_id" data-sortorder="asc" style="cursor: pointer;">编号<span class="sort"></span></th>
				<th data-sortname="goods_name" data-sortorder="asc" style="cursor: pointer;">商品名称<span class="sort"></span></th>
				<th data-sortname="goods_price" data-sortorder="asc" style="cursor: pointer;">本店价（元）<span class="sort"></span></th>
				<th data-sortname="goods_number" data-sortorder="asc" style="cursor: pointer;">库存<span class="sort"></span></th>
				<th class="text-c" data-sortname="goods_status" data-sortorder="asc" style="cursor: pointer;">状态<span class="sort"></span></th>
				<th data-sortname="add_time" data-sortorder="asc" style="cursor: pointer;">发布时间<span class="sort"></span></th>
				<th class="handle">操作</th>
			</tr>
		</thead>
		<tbody>
			@foreach ($productlist as $val)
			<tr>
				<td class="tcheck">
					<input type="checkbox" class="checkbox table-list-checkbox" value="40099">
				</td>
				<td class="text-c">{{$val->id}}</td>
				<td>
					<div class="goodsPicBox pull-left m-r-10">
						<a href="http://www.68dsw.com/goods-40099.html" target="_blank">
							<!-- 图片缩略图 -->
							<img src="{{$val->goods_image}}" class="goods-thumb">
							<!-- 虚拟商品 -->
						</a>
					</div>
					<div class="ng-binding goods-message">
						<div class="name">
							<a href="#" class="goods_name editable editable-click" target="_blank">{{$val->goods_name}}</a>
							
							<!-- <a href="javascript:void(0);" class="goods_name_controller c-blue m-l-5">修改</a> -->
						</div>
						<div class="active">
							<!--判断是否发布手机端宝贝详情：
						                		默认、未发布（为灰色小图标）：默认的给class值goods-mobile      
						                        已发布（为蓝色小图标）:在默认的基础上追加class值open   
						                        注意：在已发布及未发布的小图标鼠标经过的title值有所不同                         
						        -->
						    @if ($val->mobile_status === '6')
							<div class="goods-mobile open">
								<a href="javascript:void(0);" data-toggle="tooltip" data-placement="auto bottom" title="" data-original-title="此宝贝尚未发布手机端宝贝详情">
									<i class="fa fa-tablet"></i>
								</a>
							</div>
							@else
							<div class="goods-mobile">
								<a href="javascript:void(0);" data-toggle="tooltip" data-placement="auto bottom" title="" data-original-title="此宝贝尚未发布手机端宝贝详情">
									<i class="fa fa-tablet"></i>
								</a>
							</div>
							@endif
							
							<div class="QR-code popover-box">
								<a href="javascript:;" class="qrcode">
									<i class="fa fa-qrcode"></i>
								</a>
								<div class="code-info popover-info">
									<i class="fa fa-caret-left"></i>
									<a href="{{$val->goods_qrcode}}">商品二维码</a>
									<p>
										<img src="{{$val->goods_qrcode}}" data-src="{{$val->goods_qrcode}}">
									</p>
								</div>
							</div>
							<!--新加批发 start-->
							<div class="pull-left">
								
								<label class="model-label blue">零售</label>
								
							</div>
							<!--新加 end-->
							<!--以下为区分不同的活动，分别给不同的活动名称不同的背景颜色(对注释下面的div追加以下class名)：
							                		积分： exchange
							                        拍卖： auction
							                		预售： pre-sale
							                        0元购：zero-buy
							                        众筹： crowdfund
							                        促销活动: pro-sale                                       
               					
								<div class="goods-active pre-sale">
									<a href="" target="_blank" title="该商品参与XX预售活动，点击进入商品详情页查看">预售</a>
								</div>
								 -->
						</div>
						<div>
							<!--新加产品库-->
						</div>
					</div>
				</td>
				<td>{{$val->storeprice}}</td>
				
				<td>
					<a href="javascript:void(0);" class="goods_number editable editable-click" data-goods_id="40099">{{$val->stock}}</a>
				</td>
				<td class="text-c">
					<!-- 审核未通过的商品不显示商品状态 -->
					<font class="c-green">
						出售中
					</font>
				</td>
				<td>
					{{date('Y-m-d', $val->publish_time)}}
					<br />
					{{date('H:i:s', $val->publish_time)}}
				</td>
				<td class="handle">
					<a href="javascript:void(0);" class="sku-list" data-goods-id="40099">SKU</a>
					<span>|</span>
					<a href="http://www.68dsw.com/goods-40099.html" target="_blank">查看</a>
					<span>|</span>
					<!-- 店铺品可以设置会员价 -->
					
					<a href="javascript:void(0);" class="sku_member" data-goods-id="40099">会员价</a>
					
					
					<br>
					<a href="/goods/publish/edit?id=40099&amp;scid=0" target="_blank">编辑</a>
					<!-- <span>|</span>
						<a href="javascript:void(0);">复制</a> -->
					
					
					<span>|</span>
					<a href="javascript:void(0);" data-id="40099" class="offsale-goods del">下架</a>
					
					<span>|</span>
					<a href="javascript:void(0);" data-id="40099" class="del border-none delete-goods">删除</a>
					<span>|</span>
					<a href="javascript:void(0);" class="remark" data-id="40099">备注</a>
				</td>
			</tr>
			
			<!--
				<tr>
					<td colspan="9" class="table-merge">
						<div class="border-dashed"></div>
						<div class="labelBox">
							<span class="label-item add-label">+添加标签</span>
							<span class="label-item">
								新品
								<i class="fa">×</i>
							</span>
							<span class="label-item">
								精品
								<i class="fa">×</i>
							</span>
							<span class="label-item">
								热销
								<i class="fa">×</i>
							</span>
						</div>
					</td>
				</tr>
				-->
			@endforeach

		</tbody>
		<tfoot>
			<tr>
				<td class="text-c w10">
					<input type="checkbox" class="checkBox table-list-checkbox-all" title="全选/全不选">
				</td>
				<td colspan="7">
					<div class="pull-left">
						<div class="btn-group dropup m-r-2">
							<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
								批量操作
								<span class="caret m-l-5"></span>
							</button>
							<ul class="dropdown-menu" role="menu">
								<li>
									<a class="onsale-goods">商品上架</a>
								</li>
								<li>
									<a class="offsale-goods">商品下架</a>
								</li>
								<li>
									<a class="move-goods">转移商城商品分类</a>
								</li>
								<li>
									<a class="move-shop-goods">转移店铺商品分类</a>
								</li>
								<li class="divider"></li>
								<li>
									<a class="goods-unit">商品单位</a>
								</li>
								<li>
									<a class="goods-pricing-mode">计价方式</a>
								</li>
								<li>
									<a class="goods-moq">最小起订量</a>
								</li>
								<li>
									<a class="invoice-type">开具发票</a>
								</li>
								<li>
									<a class="goods-layout">详情版式</a>
								</li>
								<li>
									<a class="contract">服务保障</a>
								</li>
								<li>
									<a class="sku-member">会员价</a>
								</li>
								<li>
									<a class="goods-freight">运费设置</a>
								</li>
							</ul>
						</div>
						<input type="button" class="btn btn-danger m-r-2 delete-goods" value="批量删除">
						<!--当没有选中任何所操作的项，按钮为禁用状态，将按钮样式btn-danger替换为disabled-->
					</div>
					<div class="pull-right page-box">
						
						
<div id="pagination">
	<script data-page-json="true" type="text">
	{"page_key":"page","page_id":"pagination","default_page_size":10,"cur_page":1,"page_size":10,"page_size_list":[10,50,500,1000],"record_count":121,"page_count":13,"offset":0,"url":null,"sql":null}
</script>
	
	
	<div class="pagination-info">
		共{{$procount}}条记录，每页显示：
		<select class="select m-r-5" data-page-size="10">
			<option value="10" selected="selected">10</option>			
			<option value="50">50</option>
			<option value="500">500</option>
			<option value="1000">1000</option>
		</select>
		条
	</div>
	{!! $productlist->render() !!}
	
	<!-- <ul class="pagination">
		<li class="disabled" style="display: none;">
			<a class="fa fa-angle-double-left" data-go-page="1" title="第一页"></a>
		</li>
		
		<li class="disabled">
			<a class="fa fa-angle-left" title="上一页"></a>
		</li>
		<li class="active">
			<a data-cur-page="1">1</a>
		</li>
		<li>
			<a href="javascript:void(0);" data-go-page="2">2</a>
		</li>
		<li>
			<a href="javascript:void(0);" data-go-page="3">3</a>
		</li>
		
		<li>
			<a href="javascript:void(0);" data-go-page="4">4</a>
		</li>
		<li>
			<a href="javascript:void(0);" data-go-page="5">5</a>
		</li>
		<li>
			<a href="javascript:void(0);" data-go-page="6" title="快速向后翻页">...</a>
		</li>
		<li>
			<a href="javascript:void(0);" data-go-page="13" title="最后一页">13</a>
		</li>
		
		
		<li>
			<a class="fa fa-angle-right" data-go-page="2" title="下一页"></a>
		</li>
		
		<li class="" style="display: none;">
			<a class="fa fa-angle-double-right" data-go-page="13" title="最后一页"></a>
		</li>
	</ul> -->
	
	<div class="pagination-goto">
		<input class="ipt form-control goto-input" type="text">
		<button class="btn btn-default goto-button" title="点击跳转到指定页面">GO</button>
		<a class="goto-link" data-go-page="" style="display: none;"></a>
	</div>
	<script type="text/javascript">
		$().ready(function() {
			$(".pagination-goto > .goto-input").keyup(function(e) {
				$(".pagination-goto > .goto-link").attr("data-go-page", $(this).val());
				if (e.keyCode == 13) {
					$(".pagination-goto > .goto-link").click();
				}
			});
			$(".pagination-goto > .goto-button").click(function() {
				var page = $(".pagination-goto > .goto-link").attr("data-go-page");
				if ($.trim(page) == '') {
					return false;
				}
				$(".pagination-goto > .goto-link").attr("data-go-page", page);
				$(".pagination-goto > .goto-link").click();
				return false;
			});
		});
	</script>
	
</div>
					</div>
				</td>
			</tr>
		</tfoot>
	</table>
	

</div>

<script type="text/javascript">
	var tablelist = null;
	$().ready(function() {
		tablelist = $("#table_list").tablelist();

		$("#btn_export").click(function() {
			var url = "/goods/list/export.html";
			url += "?goods_barcode=" + $("#searchmodel-goods_barcode").val();
			url += "&keyword=" + $("#searchmodel-keyword").val();
			url += "&cat_id=" + $("#searchmodel-cat_id").val();
			url += "&status=" + $("#searchmodel-status").val();
			url += "&brand_id=" + $("#searchmodel-brand_id").val();
			url += "&store_id=" + $("#searchmodel-store_id").val();
			url += "&scid=" + $("#searchmodel-scid").val();

			url += "&pricing_mode=" + $("#searchmodel-pricing_mode").val();
			url += "&sales_model=" + $("#searchmodel-sales_model").val();
			url += "&start_stock=" + $("#searchmodel-start_stock").val();
			url += "&end_stock=" + $("#searchmodel-end_stock").val();

			if (tablelist.sortname != null && tablelist.sortorder != null) {
				url += "&sortname=" + tablelist.sortname;
				url += "&sortorder=" + tablelist.sortorder;
			}

			$.go(url, "_blank", false);
		});

		// 查看SKU信息
		$("body").on("click", ".sku-list", function() {
			var goods_id = $(this).data("goods-id");

			$.loading.start();

			$.open({
				title: "商品 #" + goods_id + " 的SKU列表",
				ajax: {
					url: '/goods/list/sku-list.html',
					data: {
						goods_id: goods_id
					}
				},
				width: "980px",
				end: function(index, object) {
					// 判断SKU信息是否发生变化
					if ($(document).data("sku-change")) {
						tablelist.load();
					}
					$(document).data("sku-change", false);
				}
			});
		});
		// 设置SKU会员价格
		$("body").on("click", ".sku_member", function() {
			var goods_id = $(this).data("goods-id");

			$.loading.start();

			$.open({
				title: "自定义会员价",
				ajax: {
					url: '/goods/list/sku-member.html',
					data: {
						goods_id: goods_id
					}
				},
				width: "980px",
				end: function(index, object) {
					// 判断SKU信息是否发生变化
					if ($(document).data("sku-change")) {
						tablelist.load();
					}
					$(document).data("sku-change", false);
				}
			});
		});

		//设置阶梯价格
		$("body").on("click", ".sku_step_price", function() {
			var goods_id = $(this).data("goods-id");

			$.loading.start();

			$.open({
				title: "自定义阶梯价",
				ajax: {
					url: '/goods/list/sku-step-price.html',
					data: {
						goods_id: goods_id
					}
				},
				width: "840px",
				end: function(index, object) {
					// 判断SKU信息是否发生变化
					if ($(document).data("sku-change")) {
						tablelist.load();
					}
					$(document).data("sku-change", false);
				}
			});
		});

		$("body").on("click", ".offsale-goods", function() {
			var ids = $(this).data("id");

			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}

			if (!ids || ids.length == 0) {
				$.msg("请选择要下架的商品");
				return;
			}

			$.confirm("您确定要下架此商品吗？", {}, function() {
				$.post("/goods/publish/offsale", {
					ids: ids
				}, function(result) {
					if (result.code == 0) {
						$.msg(result.message);
						tablelist.load();
					} else {
						$.msg(result.message, {
							time: 5000
						});
					}
				}, "json");
			});
		});

		$("body").on("click", ".onsale-goods", function() {
			var ids = $(this).data("id");

			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}

			if (!ids) {
				$.msg("请选择要上架的商品");
				return;
			}

			$.post("/goods/publish/onsale", {
				ids: ids
			}, function(result) {
				if (result.code == 0) {
					tablelist.load();
					$.msg(result.message);
				} else {
					$.msg(result.message, {
						time: 5000
					});
				}
			}, "json");
		});

		$("body").on("click", ".delete-goods", function() {

			var ids = $(this).data("id");

			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}

			if (!ids) {
				$.msg("请选择要删除的商品");
				return;
			}

			$.confirm("您确定要删除此商品吗？", function() {
				$.post('/goods/publish/delete', {
					ids: ids
				}, function(result) {
					if (result.code == 0) {
						$.msg(result.message);
						tablelist.load();
					} else {
						$.msg(result.message, {
							time: 5000
						});
					}
				}, "json");
			});
		})

		//转移商城商品分类
		$("body").on("click", ".move-goods", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要转移分类的商品");
				return;
			}
			$.modal({
				// 标题  
				title: '转移商城商品分类',
				width: 900,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/move-goods-cat',
					data: {
						ids: ids
					}
				},
			});
		});

		//转移店铺商品分类
		$("body").on("click", ".move-shop-goods", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要转移分类的商品");
				return;
			}
			$.modal({
				// 标题  
				title: '转移店铺商品分类',
				width: 350,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/show-shop-goods-cat',
					data: {
						ids: ids
					}
				},
			});
		});

		//商品单位
		$("body").on("click", ".goods-unit", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要设置单位的商品");
				return;
			}
			$.modal({
				// 标题  
				title: '商品单位设置',
				width: 500,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/set-goods-unit',
					data: {
						ids: ids
					}
				},
			});
		});
		//计价方式
		$("body").on("click", ".goods-pricing-mode", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要设置计价方式的商品");
				return;
			}
			$.modal({
				// 标题  
				title: '计价方式设置',
				width: 500,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/set-goods-pricing-mode',
					data: {
						ids: ids
					}
				}
			});
		});
		//最小起订量
		$("body").on("click", ".goods-moq", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要设置最小起订量的商品");
				return;
			}
			$.modal({
				// 标题  
				title: '最小起订量设置',
				width: 500,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/set-goods-moq-modal',
					data: {
						ids: ids
					}
				},
			});
		});
		//开具发票
		$("body").on("click", ".invoice-type", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要开具发票的商品");
				return;
			}
			$.modal({
				// 标题  
				title: '开具发票设置',
				width: 800,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/set-goods-invoice-type',
					data: {
						ids: ids
					}
				},
			});
		});
		//详情版式
		$("body").on("click", ".goods-layout", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要设置详情版式的商品");
				return;
			}
			$.modal({
				// 标题  
				title: '详情版式',
				width: 500,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/set-goods-layout',
					data: {
						ids: ids
					}
				},
			});
		});
		//服务保障
		$("body").on("click", ".contract", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要设置服务保障的商品");
				return;
			}
			$.modal({
				// 标题  
				title: '服务保障',
				width: 500,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/set-goods-contract',
					data: {
						ids: ids
					}
				},
			});
		});
		//会员价
		$("body").on("click", ".sku-member", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要设置自定义会员价的商品");
				return;
			}
			$.loading.start();
			$.open({
				title: "自定义会员价",
				ajax: {
					url: '/goods/list/batch-sku-member',
					data: {
						ids: ids
					}
				},
				width: "980px",
				end: function(index, object) {
					// 判断SKU信息是否发生变化
					if ($(document).data("sku-change")) {
						tablelist.load();
					}
					$(document).data("sku-change", false);
				}
			});
		});
		//运费模板
		$("body").on("click", ".goods-freight", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要设置运费模板的商品");
				return;
			}

			$.modal({
				// 标题  
				title: '运费设置',
				width: 550,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/set-goods-freight',
					data: {
						ids: ids
					}
				},
			});
		});
		$("#btn_search").click(function() {
			var data = $("#SearchModel").serializeJson();
			tablelist.load(data);
		});

		$("body").on("mouseover", ".QR-code", function() {
			if ($(this).data("loading")) {
				return;
			}
			var target = $(this).find("img");
			var src = $(target).data("src");
			var img = new Image();
			img.src = src;
			img.onload = function() {
				$(target).attr("src", src);
			};
			$(this).data("loading", true);
		});

		$("body").on("mouseover", ".goods-reason", function() {
			$.tips($(this).data("goods-reason"), $(this));
		});

		$("body").on("mouseout", ".goods-reason", function() {
			$.closeAll("tips");
		});

		// 备注
		$("body").on("click", ".remark", function() {
			var id = $(this).data("id");
			var tablelist = $("#table_list").tablelist();
			$.open({
				title: "备注",
				ajax: {
					url: '/goods/list/remark',
					data: {
						id: id
					}
				},
				width: "600px",
				btn: ['确定', '取消'],
				yes: function(index, container) {

					var data = $(container).serializeJson();
					var value = $("#remark").val().trim();
					if (value == "") {
						$("#error").show();
						return;
					}
					$.loading.start();
					$.post('/goods/list/remark', data, function(result) {
						$.loading.stop();
						if (result.code == 0) {
							tablelist.load();
							layer.close(index);
							$.msg(result.message);
						} else {
							$.msg(result.message, {
								time: 5000
							})
						}
					}, "json");
				}
			});
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function() {

		// 图片懒加载
		$("img.lazy").lazyload({
			skip_invisible: false,
			effect: 'fadeIn',
			failurelimit: $.imgloading.settings.failurelimit,
			threshold: $.imgloading.settings.threshold,
			data_attribute: $.imgloading.settings.data_attribute,
			load: function() {
				$(this).removeClass('lazy');
				// 删除背景图片
				$(this).parent('a').css("background", "");
				if ($(this).hasClass('square')) {
					if ($(this).height() != $(this).width()) {
						$(this).height($(this).width());
					} else {
						$(this).removeClass('square');
					}
				}
			}
		});

		// toggle `popup` / `inline` mode
		// $.fn.editable.defaults.mode = "inline";

		// 商品价格
		$(".goods_price").editable({
			type: "text",
			url: "/goods/list/edit-goods-info",
			pk: 1,
			// title: "本店价（元）",
			ajaxOptions: {
				type: "post"
			},
			params: function(params) {
				params.goods_id = $(this).data("goods_id");
				params.title = 'goods_price';
				return params;
			},
			/* validate: function(value) {
				value = $.trim(value);
				if (!value) {
					return '商品价格不能为空。';
				} else if (isNaN(value)) {
					return '商品价格必须是一个数字。';
				} else if (value < 0.01) {
					return '价格必须是0.01~9999999之间的数字。';
				} else if (value > 9999999) {
					return '价格必须是0.01~9999999之间的数字。';
				}
			}, */
			success: function(response, newValue) {
				var response = eval('(' + response + ')');
				// 错误处理
				if (response.code == -1) {
					return response.message;
				}
			},
			display: function(value, sourceData) {
				// 保留两位小数
				$(this).html((Number(value)).toFixed(2));
			}
		});

		// 商品库存
		$(".goods_number").editable({
			type: "text",
			url: "/goods/list/edit-goods-info",
			pk: 1,
			// title: "商品库存",
			ajaxOptions: {
				type: "post"
			},
			params: function(params) {
				params.goods_id = $(this).data("goods_id");
				params.title = 'goods_number';
				return params;
			},
			/* validate: function(value) {
				value = $.trim(value);
				var ex = /^\d+$/;
				if (!value) {
					return '商品库存不能为空。';
				} else if (!ex.test(value)) {
					return '商品库存必须是正整数。';
				} else if (value > 999999999) {
					return '商品库存不能大于999999999';
				}
			}, */
			success: function(response, newValue) {
				var response = eval('(' + response + ')');
				// 错误处理
				if (response.code == -1) {
					return response.message;
				}
			},
			display: function(value, sourceData) {
				// 显示整数
				$(this).html((Number(value)).toFixed(0));
			}
		});

		$('.goods_name_controller').click(function(e) {
			e.stopPropagation();
			$(this).parent().children(":first").editable('toggle');
		});

		// 商品名称
		$(".goods_name").editable({
			type: "text",
			url: "/goods/list/edit-goods-info",
			pk: 1,
			// title: "商品名称",
			ajaxOptions: {
				type: "post"
			},
			params: function(params) {
				params.goods_id = $(this).data("goods_id");
				params.title = 'goods_name';
				return params;
			},
			/* validate: function(value) {
				value = $.trim(value);
				if (!value) {
					return '商品名称不能为空。';
				} else if (value.length < 3) {
					return '商品名称应该包含至少3个字。';
				} else if (value.length > 60) {
					return '商品名称只能包含至多60个字。';
				}
			}, */
			success: function(response, newValue) {
				var response = eval('(' + response + ')');
				// 错误处理
				if (response.code == -1) {
					return response.message;
				}
			},
			display: function(value, sourceData) {
				if (value.length > 28) {
					$(this).html(value.substring(0, 28) + '...');
				} else {
					$(this).html(value);
				}
			}
		});
	});
</script>
					
				</div>
			</div>
		</div>
		<!--底部内容-->
		<div class="footer">
			<div class="wrapper">
				<p class="footer-link">
					
					<!---->
					
					<a href="http://www.68dsw.com/https://www.68mall.com/company" target="_blank">公司简介</a>
					
					
					<!---->
					
					<em>|</em>
					
					<a href="http://www.68dsw.com/https://www.68mall.com/help/4.html" target="_blank">联系我们</a>
					
					
					<!---->
					
					<em>|</em>
					
					<a href="http://bbs.68mall.com/" target="_blank">官网论坛</a>
					
					
					<!---->
					
					<em>|</em>
					
					<a href="http://www.68dsw.com/https://www.68mall.com/agent.html" target="_blank">代理合作</a>
					
					
					<!---->
					
					<em>|</em>
					
					<a href="http://www.68dsw.com/help/2.html" target="_blank">帮助中心</a>
					
					
					<!---->
					
					<em>|</em>
					
					<a href="http://www.68dsw.com/shop/apply.html" target="_blank">商家入驻</a>
					
					
					<!---->
					
					<em>|</em>
					
					<a href="http://www.68dsw.com/https://www.68mall.com/company" target="_blank">联系我们</a>
					
					
				</p>
				<font>
					Copyright  秦皇岛商之翼(www.68mall.com) 版权所有
					<a class="c-ccc m-l-10" href="javascript:;" target="_blank">冀ICP备07501206号-2</a>
				</font>
				
				<p><!--<span class="vol">
	<b>Powered by</b>
	<a style="color: #4FC0E8;" href="http://www.68mall.com" target="_blank">商之翼</a>
	· 翼商城
</span>-->
</p><div class="copyright">
	<p>
		<a href="http://www.68mall.com/statistics.html?product_type=shop&amp;domain=http://www.68dsw.com" target="_blank" class="copyright-logo">
			<img src="./images/power-by-logo.png">
			提供技术支持
		</a>
	</p>
</div>
<p></p>
				
			</div>
		</div>

		<!--返回顶部-->
		<a class="totop animation" href="javascript:;">
			<i class="fa fa-angle-up"></i>
		</a>
	</div>

	<form id="__SZY_TO_URL_FORM__" method="GET"></form>

	<!--右下角消息提醒弹窗-->
	<div class="message-pop-box down">
		<div class="message-title">
			<h5>
				<i class="news-icon"></i>
				消息提醒
			</h5>
			<a class="close" href="javascript:void(0);">×</a>
		</div>
		<div class="message-info">
			<div class="message-icon"></div>
			<h5>
				<span id="message-pop-text"></span>
			</h5>
			<a class="btn btn-primary btn-sm message-btn" href="javascript:void(0);" target="_blank">立即处理</a>
		</div>
	</div>
	<!-- 店铺即将到期提醒弹框，宽度给600即可-->
	<div class="modal-body" style="display: none">
		<div class="f14 p-10">
			<p class="m-b-5">
				欢迎是用xxx商城系统，您的店铺服务将于
				<span class="c-red">2017-02-30</span>
				日到期/已过期，将影响您店铺的正常运营，建议尽快进行续费！

			</p>
			<p class="m-b-5">
				续费流程：前往
				<span class="c-red">
					“店铺 -&gt; 店铺信息 -&gt;
					<a href="/goods/shop/shop-info/renew-list">续签列表</a>
					”
				</span>
				进行线上提交续签申请，线下联系平台方管理员进行缴纳费用！
			</p>

		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-primary" data-dismiss="modal">确定</button>
		</div>
	</div>

	<!--店铺关闭提示-->
	<div class="store-close-box hide">
		<a class="store-close">×</a>
		<span class="store-mark">店铺已关闭，请联系平台管理员</span>
	</div>



<script type="text/javascript">
function toFirst(target){
	var url = $(target).parents("li").find(".sub-list").find("li:first").find("a").attr("href");
	$.go(url);
}
function to(url, target){
	
}

function clearCache(){
	// 缓载
	$.loading.start();
	$.post("/site/clear-cache", {}, function(result){
		if(result.code == 0){
			$.msg(result.message);
		}else{
			$.msg(result.message, {
				time: 5000
			});
		}
	}).always(function(){
		$.loading.stop();
	});
}
// 登录成功关闭弹出框
$.login.success = function(){
	// 关闭并销毁登录窗口
	$.login.close(true);
}
</script>

<script type="text/javascript">
	// setInterval("auto_print()",10000);
	function auto_print(order_id)
	{
		$.ajax({
			type: "GET",
			url: "/site/auto-print",
			dataType: "json",
			data: {
				order_id: order_id
			},
			success: function(result) {
				if(result.code == 0)
				{
					lodop_print_html(result.print_title, result.data,result.printer);
				}
			}
		});
	}
</script>

<!-- 加载消息监听js-->
<script src="/static/newjs/message.js"></script>
<script src="/static/newjs/messageWS.js"></script>
<script type="text/javascript">
//声音监听
WS_AddUser({
	'user_id': 'shop_1717',
	'url': "ws://push.yunmall.68mall.com:7272",
	'type': "add_user"
}); 
//右下角消息提醒弹窗js
function open_message_box(data) {
	if (!data) {    
		data = {};
    }
	
	var src = window.location.href;
	
	// 如果当前框架中的链接地址和弹框的链接地址一致则不弹框
	if(data.auto_refresh == 1 && data.link && src.indexOf(data.link) != -1){
		
		var contentWindow = window;
		
		if(contentWindow.tablelist){
			contentWindow.tablelist.load({
				page: {
					cur_page: 1
				}
			});
		}else{
			contentWindow.location.reload();
		}
		
		return;
	}
	
	$('.message-pop-box').find('#message-pop-text').html(data.content);
	
	if(data.link){
		$('.message-pop-box').find('.message-btn').attr('href', data.link).show();
	}else{
		$('.message-pop-box').find('.message-btn').hide();
	}
	
	if(data.content || data.link){
		$('.message-pop-box').removeClass('down').addClass('up');
	}
	
	try {
		if(refresh_order && typeof(refresh_order) == "function") { 
			refresh_order();
        } 
    } catch(e) {}
}
$('.message-pop-box .close').click(function() {
	$('.message-pop-box').removeClass('up').addClass('down');
});
//用户信息
$(".admin").mouseenter(function() {
	window.focus();
	$("#admin-panel").show();
}).mouseleave(function() {
	$("#admin-panel").hide();
});
</script>
<script type="text/javascript">
	var clipboard = new Clipboard('.btn-copy');
    clipboard.on('success', function(e) {
        $.msg('复制成功');
    });
    clipboard.on('error', function(e) {
    	$.msg('复制失败');
    });
 	// 更新后台主框架消息弹窗
	function update_message() {
		// 是否重新获取数据
		if ($("#message-panel").html().length > 0) {
			// if (parseInt($("#counts_all").val()) != 0) {
			var time_step = 5; // 最小刷新间隔，单位：秒
			var this_time = new Date();
			if ((parseInt($("#counts_time").val()) + parseInt(time_step)) > parseInt(this_time.getTime() / 1000)) {
				return true;
			}
			// }
		}
		$.ajax({
			type: 'GET',
			url: '/site/update-message.html',
			data: {},
			dataType: 'json',
			success: function(result) {
				if (result.code == 0) {
					$("#message-panel").html(result.data);
				} else if (result.code == 1) {
				} else {
					$.msg(result.message);
				}
			}
		});
	}
	// 消息通知
	$("#message-box").mouseenter(function() {
		update_message();
		window.focus();
		$("#message-panel").show();
	}).mouseleave(function() {
		$("#message-panel").hide();
	}).find(".close").click(function() {
		$("#message-panel").hide();
	});
</script>



</body></html>