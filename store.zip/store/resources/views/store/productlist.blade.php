<!DOCTYPE html>
<html lang="zh-CN">
	@include('common.link')
	<body class="style-seller">
	<!-- 头部模板 -->
	@include('common.header')

	<!--中间内容-->
	<div class="seller-center">
		<div class="wrapper">
			<!-- 左侧导航 -->
			@include('common.slider')
			<!--右侧内容-->
			<div class="seller-rihgt">
				<div class="seller-page">
					<div class="seller-page-bg"></div>
					<!--在这里调用内容-->
					<div class="page">
						<div class="fixed-bar">
							<div class="item-title">
								<div class="subject">
									<h3>
										<span class="action">商品管理 - 列表</span>
										<!--帮助教程-->
						                <!--<a class="help-href" href="javascript:;" data-toggle="tooltip" data-placement="auto bottom" title="点击跳转到该模块教程页面"><i class="help-icon"></i></a>-->
						                <!-- -->
									</h3>
									<!-- <h5>
										<span class="action-span">
											<a href="/goods/list/batch-edit.html" class="btn btn-warning click-loading">
												<i class="fa fa-cloud-upload"></i>
												批量更新商品价格、库存
											</a>
										</span>
										<span class="action-span">
											<a href="/goods/list/batch-add.html" class="btn btn-warning click-loading">
												<i class="fa fa-cloud-upload"></i>
												批量上传商品
											</a>
										</span>
									</h5> -->
								</div>
							</div>
						</div>
						<!-- 温馨提示 -->
	
						<!--搜索-->
						
								<!-- 工具栏（列表名称、列表显示项设置） -->
								<div class="common-title">
									<div class="ftitle">
										<h3>商品列表</h3>
										<h5>
										<!-- data-total-record="true" -->
											(共<span>{{$procount}}</span>条记录)
										</h5>		
									</div>
									<div class="operate m-l-20">
										<a class="reload" href="javascript:tablelist.load();" data-toggle="tooltip" data-placement="auto bottom" title="" data-original-title="刷新数据">
											<i class="fa fa-refresh"></i>
										</a>
									</div>
								</div>
	<!--列表内容-->
	<table id="table_list" class="table table-hover">
		<thead>
			<tr>
				<th class="tcheck">
					<input type="checkbox" class="table-list-checkbox-all" title="全选/全不选">
				</th>
				<th class="text-c" data-sortname="goods_id" data-sortorder="asc" style="cursor: pointer;">编号<span class="sort"></span></th>
				<th data-sortname="goods_name" data-sortorder="asc" style="cursor: pointer;">商品名称<span class="sort"></span></th>
				<th data-sortname="goods_price" data-sortorder="asc" style="cursor: pointer;">本店价（元）<span class="sort"></span></th>
				<th data-sortname="goods_number" data-sortorder="asc" style="cursor: pointer;">库存<span class="sort"></span></th>
				<th class="text-c" data-sortname="goods_status" data-sortorder="asc" style="cursor: pointer;">状态<span class="sort"></span></th>
				<th data-sortname="add_time" data-sortorder="asc" style="cursor: pointer;">发布时间<span class="sort"></span></th>
				<th class="handle">操作</th>
			</tr>
		</thead>
		<tbody>
			@foreach ($productlist as $val)
			<tr>
				<td class="tcheck">
					<input type="checkbox" class="checkbox table-list-checkbox" value="40099">
				</td>
				<td class="text-c">{{$val->id}}</td>
				<td>
					<div class="goodsPicBox pull-left m-r-10">
						<a href="#" target="_blank">
							<!-- 图片缩略图 -->
							<img src="{{$val->pic1}}" class="goods-thumb">
							<!-- 虚拟商品 -->
						</a>
					</div>
					<div class="ng-binding goods-message">
						<div class="name">
							<a href="#" class="goods_name editable editable-click" target="_blank">{{$val->name}}</a>
							
							<!-- <a href="javascript:void(0);" class="goods_name_controller c-blue m-l-5">修改</a> -->
						</div>
						<div class="active">
						</div>
						<div>
							<!--新加产品库-->
						</div>
					</div>
				</td>
				<td>{{$val->price2}}</td>
				
				<td>
					<a href="javascript:void(0);" class="goods_number" data-goods_id="{{$val->id}}">{{$val->kucun}}</a>
				</td>
				<td class="text-c">
					<!-- 审核未通过的商品不显示商品状态 -->
					<font class="c-green">
						出售中
					</font>
				</td>
				<td>
					{{date('Y-m-d', $val->publish_time)}}
					<br />
					{{date('H:i:s', $val->publish_time)}}
				</td>
				<td class="handle">
					<!-- <a href="javascript:void(0);" class="sku-list" data-goods-id="40099">SKU</a>
					<span>|</span>
					<a href="http://www.68dsw.com/goods-40099.html" target="_blank">查看</a>
					<span>|</span> -->
					<!-- 店铺品可以设置会员价 -->
					
					<!-- <a href="javascript:void(0);" class="sku_member" data-goods-id="40099">会员价</a> -->
					
					
					<br>
					<a href="{{url('store/goods/edit',$val->id)}}" target="_blank">编辑</a>
					<!-- <span>|</span>
						<a href="javascript:void(0);">复制</a> -->
					
					
					<!-- <span>|</span>
					<a href="javascript:void(0);" data-id="40099" class="offsale-goods del">下架</a> -->
					
					<span>|</span>
					<a href="javascript:void(0);" data-id="{{$val->id}}" class="del border-none delete-goods">删除</a>
					<!-- <span>|</span>
					<a href="javascript:void(0);" class="remark" data-id="40099">备注</a> -->
				</td>
			</tr>
			@endforeach
			
		</tbody>
		</table>

					<div class="pull-right page-box">
						
						
<div id="pagination">
	
	
	
	<div class="pagination-info">
		共{{$procount}}条记录<!-- ，每页显示：
		<select class="select m-r-5" data-page-size="10">
			<option value="10" selected="selected">10</option>			
			<option value="50">50</option>
			<option value="500">500</option>
			<option value="1000">1000</option>
		</select>
		条 -->
	</div>
	@if($procount>10)
		{!! $productlist->links() !!}
	@endif
	
	
	<!-- <ul class="pagination">
		<li class="disabled" style="display: none;">
			<a class="fa fa-angle-double-left" data-go-page="1" title="第一页"></a>
		</li>
		
		<li class="disabled">
			<a class="fa fa-angle-left" title="上一页"></a>
		</li>
		<li class="active">
			<a data-cur-page="1">1</a>
		</li>
		<li>
			<a href="javascript:void(0);" data-go-page="2">2</a>
		</li>
		<li>
			<a href="javascript:void(0);" data-go-page="3">3</a>
		</li>
		
		<li>
			<a href="javascript:void(0);" data-go-page="4">4</a>
		</li>
		<li>
			<a href="javascript:void(0);" data-go-page="5">5</a>
		</li>
		<li>
			<a href="javascript:void(0);" data-go-page="6" title="快速向后翻页">...</a>
		</li>
		<li>
			<a href="javascript:void(0);" data-go-page="13" title="最后一页">13</a>
		</li>
		
		
		<li>
			<a class="fa fa-angle-right" data-go-page="2" title="下一页"></a>
		</li>
		
		<li class="" style="display: none;">
			<a class="fa fa-angle-double-right" data-go-page="13" title="最后一页"></a>
		</li>
	</ul> -->
	
	<div class="pagination-goto">
		<input class="ipt form-control goto-input" type="text">
		<button class="btn btn-default goto-button" title="点击跳转到指定页面">GO</button>
		<a class="goto-link" data-go-page="" style="display: none;"></a>
	</div>
	<script type="text/javascript">
		$().ready(function() {
			$(".pagination-goto > .goto-input").keyup(function(e) {
				$(".pagination-goto > .goto-link").attr("data-go-page", $(this).val());
				if (e.keyCode == 13) {
					$(".pagination-goto > .goto-link").click();
				}
			});
			$(".pagination-goto > .goto-button").click(function() {
				var page = $(".pagination-goto > .goto-link").attr("data-go-page");
				if ($.trim(page) == '') {
					return false;
				}
				$(".pagination-goto > .goto-link").attr("data-go-page", page);
				$(".pagination-goto > .goto-link").click();
				return false;
			});
		});
	</script>
	
</div>
					</div>
				</td>
			</tr>
		</tfoot>
	</table>
	

</div>

<script type="text/javascript">
	var tablelist = null;
	$().ready(function() {
		tablelist = $("#table_list").tablelist();

		$("#btn_export").click(function() {
			var url = "/goods/list/export.html";
			url += "?goods_barcode=" + $("#searchmodel-goods_barcode").val();
			url += "&keyword=" + $("#searchmodel-keyword").val();
			url += "&cat_id=" + $("#searchmodel-cat_id").val();
			url += "&status=" + $("#searchmodel-status").val();
			url += "&brand_id=" + $("#searchmodel-brand_id").val();
			url += "&store_id=" + $("#searchmodel-store_id").val();
			url += "&scid=" + $("#searchmodel-scid").val();

			url += "&pricing_mode=" + $("#searchmodel-pricing_mode").val();
			url += "&sales_model=" + $("#searchmodel-sales_model").val();
			url += "&start_stock=" + $("#searchmodel-start_stock").val();
			url += "&end_stock=" + $("#searchmodel-end_stock").val();

			if (tablelist.sortname != null && tablelist.sortorder != null) {
				url += "&sortname=" + tablelist.sortname;
				url += "&sortorder=" + tablelist.sortorder;
			}

			$.go(url, "_blank", false);
		});

		// 查看SKU信息
		$("body").on("click", ".sku-list", function() {
			var goods_id = $(this).data("goods-id");

			$.loading.start();

			$.open({
				title: "商品 #" + goods_id + " 的SKU列表",
				ajax: {
					url: '/goods/list/sku-list.html',
					data: {
						goods_id: goods_id
					}
				},
				width: "980px",
				end: function(index, object) {
					// 判断SKU信息是否发生变化
					if ($(document).data("sku-change")) {
						tablelist.load();
					}
					$(document).data("sku-change", false);
				}
			});
		});
		// 设置SKU会员价格
		$("body").on("click", ".sku_member", function() {
			var goods_id = $(this).data("goods-id");

			$.loading.start();

			$.open({
				title: "自定义会员价",
				ajax: {
					url: '/goods/list/sku-member.html',
					data: {
						goods_id: goods_id
					}
				},
				width: "980px",
				end: function(index, object) {
					// 判断SKU信息是否发生变化
					if ($(document).data("sku-change")) {
						tablelist.load();
					}
					$(document).data("sku-change", false);
				}
			});
		});

		//设置阶梯价格
		$("body").on("click", ".sku_step_price", function() {
			var goods_id = $(this).data("goods-id");

			$.loading.start();

			$.open({
				title: "自定义阶梯价",
				ajax: {
					url: '/goods/list/sku-step-price.html',
					data: {
						goods_id: goods_id
					}
				},
				width: "840px",
				end: function(index, object) {
					// 判断SKU信息是否发生变化
					if ($(document).data("sku-change")) {
						tablelist.load();
					}
					$(document).data("sku-change", false);
				}
			});
		});

		$("body").on("click", ".offsale-goods", function() {
			var ids = $(this).data("id");

			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}

			if (!ids || ids.length == 0) {
				$.msg("请选择要下架的商品");
				return;
			}

			$.confirm("您确定要下架此商品吗？", {}, function() {
				$.post("/goods/publish/offsale", {
					ids: ids
				}, function(result) {
					if (result.code == 0) {
						$.msg(result.message);
						tablelist.load();
					} else {
						$.msg(result.message, {
							time: 5000
						});
					}
				}, "json");
			});
		});

		$("body").on("click", ".onsale-goods", function() {
			var ids = $(this).data("id");

			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}

			if (!ids) {
				$.msg("请选择要上架的商品");
				return;
			}

			$.post("/goods/publish/onsale", {
				ids: ids
			}, function(result) {
				if (result.code == 0) {
					tablelist.load();
					$.msg(result.message);
				} else {
					$.msg(result.message, {
						time: 5000
					});
				}
			}, "json");
		});

		$("body").on("click", ".delete-goods", function() {

			var ids = $(this).data("id");

			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}

			if (!ids) {
				$.msg("请选择要删除的商品");
				return;
			}

			$.confirm("您确定要删除此商品吗？", function() {
				$.post('/store/goods/delete', {
					ids: ids
				}, function(result) {
					if (result.code == 0) {
						$.msg(result.message);
						//tablelist.load();
						$.go('/store/goods/list');
					} else {
						$.msg(result.message, {
							time: 5000
						});
					}
				}, "json");
			});
		})

		//转移商城商品分类
		$("body").on("click", ".move-goods", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要转移分类的商品");
				return;
			}
			$.modal({
				// 标题  
				title: '转移商城商品分类',
				width: 900,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/move-goods-cat',
					data: {
						ids: ids
					}
				},
			});
		});

		//转移店铺商品分类
		$("body").on("click", ".move-shop-goods", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要转移分类的商品");
				return;
			}
			$.modal({
				// 标题  
				title: '转移店铺商品分类',
				width: 350,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/show-shop-goods-cat',
					data: {
						ids: ids
					}
				},
			});
		});

		//商品单位
		$("body").on("click", ".goods-unit", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要设置单位的商品");
				return;
			}
			$.modal({
				// 标题  
				title: '商品单位设置',
				width: 500,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/set-goods-unit',
					data: {
						ids: ids
					}
				},
			});
		});
		//计价方式
		$("body").on("click", ".goods-pricing-mode", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要设置计价方式的商品");
				return;
			}
			$.modal({
				// 标题  
				title: '计价方式设置',
				width: 500,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/set-goods-pricing-mode',
					data: {
						ids: ids
					}
				}
			});
		});
		//最小起订量
		$("body").on("click", ".goods-moq", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要设置最小起订量的商品");
				return;
			}
			$.modal({
				// 标题  
				title: '最小起订量设置',
				width: 500,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/set-goods-moq-modal',
					data: {
						ids: ids
					}
				},
			});
		});
		//开具发票
		$("body").on("click", ".invoice-type", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要开具发票的商品");
				return;
			}
			$.modal({
				// 标题  
				title: '开具发票设置',
				width: 800,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/set-goods-invoice-type',
					data: {
						ids: ids
					}
				},
			});
		});
		//详情版式
		$("body").on("click", ".goods-layout", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要设置详情版式的商品");
				return;
			}
			$.modal({
				// 标题  
				title: '详情版式',
				width: 500,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/set-goods-layout',
					data: {
						ids: ids
					}
				},
			});
		});
		//服务保障
		$("body").on("click", ".contract", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要设置服务保障的商品");
				return;
			}
			$.modal({
				// 标题  
				title: '服务保障',
				width: 500,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/set-goods-contract',
					data: {
						ids: ids
					}
				},
			});
		});
		//会员价
		$("body").on("click", ".sku-member", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要设置自定义会员价的商品");
				return;
			}
			$.loading.start();
			$.open({
				title: "自定义会员价",
				ajax: {
					url: '/goods/list/batch-sku-member',
					data: {
						ids: ids
					}
				},
				width: "980px",
				end: function(index, object) {
					// 判断SKU信息是否发生变化
					if ($(document).data("sku-change")) {
						tablelist.load();
					}
					$(document).data("sku-change", false);
				}
			});
		});
		//运费模板
		$("body").on("click", ".goods-freight", function() {
			var ids = $(this).data("id");
			if (!ids) {
				ids = tablelist.checkedValues();
				ids = ids.join(",");
			}
			if (!ids || ids.length == 0) {
				$.msg("请选择要设置运费模板的商品");
				return;
			}

			$.modal({
				// 标题  
				title: '运费设置',
				width: 550,
				trigger: $(this),
				// ajax加载的设置  
				ajax: {
					url: '/goods/list/set-goods-freight',
					data: {
						ids: ids
					}
				},
			});
		});
		$("#btn_search").click(function() {
			var data = $("#SearchModel").serializeJson();
			tablelist.load(data);
		});

		$("body").on("mouseover", ".QR-code", function() {
			if ($(this).data("loading")) {
				return;
			}
			var target = $(this).find("img");
			var src = $(target).data("src");
			var img = new Image();
			img.src = src;
			img.onload = function() {
				$(target).attr("src", src);
			};
			$(this).data("loading", true);
		});

		$("body").on("mouseover", ".goods-reason", function() {
			$.tips($(this).data("goods-reason"), $(this));
		});

		$("body").on("mouseout", ".goods-reason", function() {
			$.closeAll("tips");
		});

		// 备注
		$("body").on("click", ".remark", function() {
			var id = $(this).data("id");
			var tablelist = $("#table_list").tablelist();
			$.open({
				title: "备注",
				ajax: {
					url: '/goods/list/remark',
					data: {
						id: id
					}
				},
				width: "600px",
				btn: ['确定', '取消'],
				yes: function(index, container) {

					var data = $(container).serializeJson();
					var value = $("#remark").val().trim();
					if (value == "") {
						$("#error").show();
						return;
					}
					$.loading.start();
					$.post('/goods/list/remark', data, function(result) {
						$.loading.stop();
						if (result.code == 0) {
							tablelist.load();
							layer.close(index);
							$.msg(result.message);
						} else {
							$.msg(result.message, {
								time: 5000
							})
						}
					}, "json");
				}
			});
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function() {

		// 图片懒加载
		$("img.lazy").lazyload({
			skip_invisible: false,
			effect: 'fadeIn',
			failurelimit: $.imgloading.settings.failurelimit,
			threshold: $.imgloading.settings.threshold,
			data_attribute: $.imgloading.settings.data_attribute,
			load: function() {
				$(this).removeClass('lazy');
				// 删除背景图片
				$(this).parent('a').css("background", "");
				if ($(this).hasClass('square')) {
					if ($(this).height() != $(this).width()) {
						$(this).height($(this).width());
					} else {
						$(this).removeClass('square');
					}
				}
			}
		});

		// toggle `popup` / `inline` mode
		// $.fn.editable.defaults.mode = "inline";

		// 商品价格
		$(".goods_price").editable({
			type: "text",
			url: "/goods/list/edit-goods-info",
			pk: 1,
			// title: "本店价（元）",
			ajaxOptions: {
				type: "post"
			},
			params: function(params) {
				params.goods_id = $(this).data("goods_id");
				params.title = 'goods_price';
				return params;
			},
			/* validate: function(value) {
				value = $.trim(value);
				if (!value) {
					return '商品价格不能为空。';
				} else if (isNaN(value)) {
					return '商品价格必须是一个数字。';
				} else if (value < 0.01) {
					return '价格必须是0.01~9999999之间的数字。';
				} else if (value > 9999999) {
					return '价格必须是0.01~9999999之间的数字。';
				}
			}, */
			success: function(response, newValue) {
				var response = eval('(' + response + ')');
				// 错误处理
				if (response.code == -1) {
					return response.message;
				}
			},
			display: function(value, sourceData) {
				// 保留两位小数
				$(this).html((Number(value)).toFixed(2));
			}
		});

		// 商品库存
		$(".goods_number").editable({
			type: "text",
			url: "/goods/list/edit-goods-info",
			pk: 1,
			// title: "商品库存",
			ajaxOptions: {
				type: "post"
			},
			params: function(params) {
				params.goods_id = $(this).data("goods_id");
				params.title = 'goods_number';
				return params;
			},
			/* validate: function(value) {
				value = $.trim(value);
				var ex = /^\d+$/;
				if (!value) {
					return '商品库存不能为空。';
				} else if (!ex.test(value)) {
					return '商品库存必须是正整数。';
				} else if (value > 999999999) {
					return '商品库存不能大于999999999';
				}
			}, */
			success: function(response, newValue) {
				var response = eval('(' + response + ')');
				// 错误处理
				if (response.code == -1) {
					return response.message;
				}
			},
			display: function(value, sourceData) {
				// 显示整数
				$(this).html((Number(value)).toFixed(0));
			}
		});

		$('.goods_name_controller').click(function(e) {
			e.stopPropagation();
			$(this).parent().children(":first").editable('toggle');
		});

		// 商品名称
		$(".goods_name").editable({
			type: "text",
			url: "/goods/list/edit-goods-info",
			pk: 1,
			// title: "商品名称",
			ajaxOptions: {
				type: "post"
			},
			params: function(params) {
				params.goods_id = $(this).data("goods_id");
				params.title = 'goods_name';
				return params;
			},
			/* validate: function(value) {
				value = $.trim(value);
				if (!value) {
					return '商品名称不能为空。';
				} else if (value.length < 3) {
					return '商品名称应该包含至少3个字。';
				} else if (value.length > 60) {
					return '商品名称只能包含至多60个字。';
				}
			}, */
			success: function(response, newValue) {
				var response = eval('(' + response + ')');
				// 错误处理
				if (response.code == -1) {
					return response.message;
				}
			},
			display: function(value, sourceData) {
				if (value.length > 28) {
					$(this).html(value.substring(0, 28) + '...');
				} else {
					$(this).html(value);
				}
			}
		});
	});
</script>
					
				</div>
			</div>
		</div>
		<!--底部内容-->
		@include('common.footer')


<script type="text/javascript">
function toFirst(target){
	var url = $(target).parents("li").find(".sub-list").find("li:first").find("a").attr("href");
	$.go(url);
}
function to(url, target){
	
}

function clearCache(){
	// 缓载
	$.loading.start();
	$.post("/site/clear-cache", {}, function(result){
		if(result.code == 0){
			$.msg(result.message);
		}else{
			$.msg(result.message, {
				time: 5000
			});
		}
	}).always(function(){
		$.loading.stop();
	});
}
// 登录成功关闭弹出框
$.login.success = function(){
	// 关闭并销毁登录窗口
	$.login.close(true);
}
</script>

<script type="text/javascript">
	// setInterval("auto_print()",10000);
	function auto_print(order_id)
	{
		$.ajax({
			type: "GET",
			url: "/site/auto-print",
			dataType: "json",
			data: {
				order_id: order_id
			},
			success: function(result) {
				if(result.code == 0)
				{
					lodop_print_html(result.print_title, result.data,result.printer);
				}
			}
		});
	}
</script>

<!-- 加载消息监听js-->
<script src="/static/newjs/message.js"></script>
<script src="/static/newjs/messageWS.js"></script>
<script type="text/javascript">
//声音监听
WS_AddUser({
	'user_id': 'shop_1717',
	'url': "ws://push.yunmall.68mall.com:7272",
	'type': "add_user"
}); 
//右下角消息提醒弹窗js
function open_message_box(data) {
	if (!data) {    
		data = {};
    }
	
	var src = window.location.href;
	
	// 如果当前框架中的链接地址和弹框的链接地址一致则不弹框
	if(data.auto_refresh == 1 && data.link && src.indexOf(data.link) != -1){
		
		var contentWindow = window;
		
		if(contentWindow.tablelist){
			contentWindow.tablelist.load({
				page: {
					cur_page: 1
				}
			});
		}else{
			contentWindow.location.reload();
		}
		
		return;
	}
	
	$('.message-pop-box').find('#message-pop-text').html(data.content);
	
	if(data.link){
		$('.message-pop-box').find('.message-btn').attr('href', data.link).show();
	}else{
		$('.message-pop-box').find('.message-btn').hide();
	}
	
	if(data.content || data.link){
		$('.message-pop-box').removeClass('down').addClass('up');
	}
	
	try {
		if(refresh_order && typeof(refresh_order) == "function") { 
			refresh_order();
        } 
    } catch(e) {}
}
$('.message-pop-box .close').click(function() {
	$('.message-pop-box').removeClass('up').addClass('down');
});
//用户信息
$(".admin").mouseenter(function() {
	window.focus();
	$("#admin-panel").show();
}).mouseleave(function() {
	$("#admin-panel").hide();
});
</script>
<script type="text/javascript">
	var clipboard = new Clipboard('.btn-copy');
    clipboard.on('success', function(e) {
        $.msg('复制成功');
    });
    clipboard.on('error', function(e) {
    	$.msg('复制失败');
    });
 	// 更新后台主框架消息弹窗
	function update_message() {
		// 是否重新获取数据
		if ($("#message-panel").html().length > 0) {
			// if (parseInt($("#counts_all").val()) != 0) {
			var time_step = 5; // 最小刷新间隔，单位：秒
			var this_time = new Date();
			if ((parseInt($("#counts_time").val()) + parseInt(time_step)) > parseInt(this_time.getTime() / 1000)) {
				return true;
			}
			// }
		}
		$.ajax({
			type: 'GET',
			url: '/site/update-message.html',
			data: {},
			dataType: 'json',
			success: function(result) {
				if (result.code == 0) {
					$("#message-panel").html(result.data);
				} else if (result.code == 1) {
				} else {
					$.msg(result.message);
				}
			}
		});
	}
	// 消息通知
	$("#message-box").mouseenter(function() {
		update_message();
		window.focus();
		$("#message-panel").show();
	}).mouseleave(function() {
		$("#message-panel").hide();
	}).find(".close").click(function() {
		$("#message-panel").hide();
	});
</script>



</body></html>