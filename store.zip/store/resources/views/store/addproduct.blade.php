<!DOCTYPE html>
<!-- saved from url=(0046)http://seller.68dsw.com/goods/publish/add.html -->
<html lang="zh-CN">
@include('common.link')
<body class="style-seller">
	@include('common.header')
	<!--中间内容-->
	<div class="seller-center">
		<div class="wrapper">
			@include('common.slider')
			
			<!--右侧内容-->
			<div class="seller-rihgt">
				<div class="seller-page">
					<div class="seller-page-bg"></div>
					<!--在这里调用内容-->
					<link rel="stylesheet" href="/static/css/styles.css">
					<div class="page">
						<div class="fixed-bar">
							<div class="item-title">
								<div class="subject">
									<h3>
										<span class="action">发布商品 - 选择商品分类</span>
										<!--帮助教程-->
						                <!--<a class="help-href" href="javascript:;" data-toggle="tooltip" data-placement="auto bottom" title="点击跳转到该模块教程页面"><i class="help-icon"></i></a>-->
						                <!---->
									</h3>
								</div>
							</div>
						</div>
						<div class="table-content">
							<!--步骤-->
							<ul class="add-goods-step">
								<li id="step_1" class="current">
									<i class="fa fa-list-alt step"></i>
									<h6>STEP.1</h6>
									<h2>选择商品分类</h2>
									<i class="fa fa-angle-right"></i>
								</li>
								<li id="step_2">
									<i class="fa fa-edit step"></i>
									<h6>STEP.2</h6>
									<h2>填写商品详情</h2>
									<i class="fa fa-angle-right"></i>
								</li>
								<li id="step_3">
									<i class="fa fa-image step"></i>
									<h6>STEP.3</h6>
									<h2>上传商品图片</h2>
									<i class="fa fa-angle-right"></i>
								</li>
								<li id="step_4">
									<i class="fa fa-check-square-o step"></i>
									<h6>STEP.4</h6>
									<h2>商品发布成功</h2>
								</li>
							</ul>
							<script type="text/javascript">
							$().ready(function(){
								$("#step_1").addClass("current");
							});
							</script>
							<!-- 搜索 -->
							<div class="content">
								@include('goods.cate_search')
								<!-- 选择区域 -->
								<div class="goods-info-one">
									<div class="choose-category">
										<div class="final-catgory">
											<dl>
												<dt>您当前选择的是：</dt>
												<dd id="current-choose-category"></dd>
											</dl>
										</div>
										<div class="choose-category-list">
											<div class="grade-category-list">
												<div class="category-list">
													<div class="category-info-search">
														<i class="fa fa-search"></i>
														<input type="text" name="category_search" data-level="1" class="form-control" placeholder="输入名称/拼音首字母">
													</div>
													<ul class="category-list-name category-level-1">
														
														@foreach ($oneparent as $oneparent)
														<li class="">
															<a href="javascript:void(0);" class="category-name" data-is-parent="1" data-search="{{$oneparent->category}}" data-id="{{$oneparent->id}}" data-level="1">
																<i class="fa fa-angle-right"></i>
																{{$oneparent->category}}
															</a>
														</li>
														@endforeach
													</ul>
												</div>
											</div>
										</div>
										<div class="choose-category-list">
											<div class="grade-category-list">
												<div class="category-list category-list-two">
													<div class="category-info-search">
														<i class="fa fa-search"></i>
														<input type="text" name="category_search" data-level="2" class="form-control" placeholder="输入名称/拼音首字母">
													</div>
													<ul class="category-list-name category-level-2">
													</ul>
												</div>
											</div>
										</div>
					<div class="choose-category-list choose-category-list-last">
						<div class="grade-category-list">
							<div class="category-list category-list-two">
								<div class="category-info-search">
									<i class="fa fa-search"></i>
									<input name="category_search" data-level="3" class="form-control" type="text" placeholder="输入名称/拼音首字母">
								</div>
								<ul class="category-list-name category-level-3">
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="choose-category-search-list" style="display: none;"></div>
			</div>
			
			
			
			<form id="catForm" action="{{url('store/goods/nextpublish')}}" method="GET">
				<input type="hidden" id="cat_id" name="cat_id" value="">
				<div class="goods-next p-b-30 text-c p-l-0">
					<button id="btn_next_step" class="btn disabled" disabled="disabled">下一步，填写商品信息</button>
				</div>
			</form>
		</div>
	</div>
</div>
<script type="text/javascript">
	$().ready(function() {

		function scrollTo(container, target) {
			//动画效果
			$(container).scrollTop($(target).offset().top - $(container).offset().top + $(container).scrollTop());
		}

		//滚动条
		$("body").on("click", ".choose-category-search-close", function() {
			$(".choose-category").show();
			$(".choose-category-search-list").hide();

			$("#btn_next_step").prop("disabled", true);
			$("#btn_next_step").addClass("btn-primary").addClass('disabled');

			$("#cat_id").val("");
			$("#cat_id").data(undefined);
		});

		// 搜索
		$("#btn_search").click(function() {
			var cat_name = $("#searchForm").find("#cat_name").val();

			if ($.trim(cat_name) == "") {
				$.msg("请输入商品分类名称！");
				$("#searchForm").find("#cat_name").focus();
				return false;
			}

			$("#btn_next_step").prop("disabled", true);
			$("#btn_next_step").addClass("btn-primary").addClass('disabled');

			$("#cat_id").val("");
			$("#cat_id").data(undefined);

			$.loading.start();

			$.get("/goods/publish/cat-search.html", {
				cat_name: cat_name
			}, function(result) {
				if (result.code == 0) {
					$(".choose-category-search-list").html(result.data);
					$(".choose-category").hide();
					$(".choose-category-search-list").show();
				} else {
					$.msg(result.message, {
						time: 3000
					});
				}
			}, "JSON").always(function() {
				$.loading.stop();
			});

			return false;
		});

		// 双击
		$("body").on("dblclick", ".category-search-item", function() {
			var cat_id = $(this).data("id");
			var is_parent = $(this).data("is-parent");
			var cat_level = $(this).data("level");
			var cat_ids = $(this).data("cat-ids") + "";

			if (is_parent == 1) {
				$(".choose-category").show();
				$(".choose-category-search-list").hide();
				cat_level = 1;
				cat_ids = cat_ids.split(",");
				cat_id = cat_ids[0];

				var container = $(".category-level-" + cat_level);
				var target = $(container).find(".category-name[data-id='" + cat_id + "']");
				// 触发点击
				$(target).trigger("click", [cat_ids]);
				// 滚动定位
				scrollTo(container, target);
			} else {
				$("#btn_next_step").prop("disabled", false);
				$("#btn_next_step").addClass("btn-primary").removeClass('disabled');
				$("#cat_id").val(cat_id);
				$("#catForm").submit();
			}

			return false;
		});

		// 单击分类名称事件
		$("body").on("click", ".category-name", function(event, cat_ids) {

			var cat_id = $(this).data("id");
			var is_parent = $(this).data("is-parent");
			var cat_level = $(this).data("level");

			if (cat_ids == undefined || cat_ids == null) {
				cat_ids = $(this).data("cat-ids");
			} else if ($.isArray(cat_ids) == false) {
				cat_ids = cat_ids + "";
			}

			var type = $(this).data("type");

			// type
			// 0-默认点击
			// 1-搜索
			// 2-历史
			if (type == 0) {
				$(this).parents("ul").find(".selected").removeClass("selected");
				$(this).addClass("selected");

				$("#btn_next_step").prop("disabled", false);
				$("#btn_next_step").addClass("btn-primary").removeClass('disabled');

				$("#cat_id").val(cat_id);
				$("#cat_id").data($(this).data());

				return;
			} else if (type == 1) {

				$(".choose-category").show();
				$(".choose-category-search-list").hide();

				if (typeof cat_ids == 'number') {
					cat_ids = new String(cat_ids);
				}

				cat_level = 1;
				cat_ids = cat_ids.split(",");
				if (cat_ids.length > 1) {
					is_parent = 1;
				}
				cat_id = cat_ids[0];

				$(".category-level-" + cat_level).find(".classDivClick").removeClass("classDivClick");
				$(".category-level-" + cat_level).find(".category-name[data-id='" + cat_id + "']").addClass("classDivClick");
			} else {
				$(".category-level-" + cat_level).find(".classDivClick").removeClass("classDivClick");
				$(this).addClass("classDivClick");
			}

			if (type > 0 && cat_level && cat_id) {
				var container = $(".category-level-" + cat_level);
				var target = $(container).find(".category-name[data-id='" + cat_id + "']");
				// 滚动定位
				scrollTo(container, target);
			}

			// 取消已经选择的内容
			for (var i = 3; i > cat_level; i--) {
				$(".category-level-" + i).html("");
			}

			if (is_parent == 1) {

				$("#btn_next_step").prop("disabled", true);
				$("#btn_next_step").addClass("disabled").removeClass('btn-primary');
				$("#cat_id").val("");

				var data = $(document).data("cat_data_" + cat_id);

				if (data) {
					$.loading.start();

					$(".category-level-" + (cat_level + 1)).html(data);

					if (cat_ids != undefined) {
						cat_id = cat_ids[cat_level];
						if (cat_id != undefined) {
							var container = $(".category-level-" + (cat_level + 1));
							var target = $(container).find(".category-name[data-id='" + cat_id + "']");
							// 触发点击
							$(target).trigger("click", [cat_ids]);
							// 滚动定位
							scrollTo(container, target);
						}
					}

					$.loading.stop();
				} else {
					$.loading.start();

					$.get('/store/goods/cat-list', {
						id: cat_id
					}, function(result) {
						$(".category-level-" + (cat_level + 1)).html(result);
						// 缓存
						$(document).data("cat_data_" + cat_id, result);

						if (cat_ids != undefined) {
							cat_id = cat_ids[cat_level];
							if (cat_id != undefined) {
								var container = $(".category-level-" + (cat_level + 1));
								var target = $(container).find(".category-name[data-id='" + cat_id + "']");
								// 触发点击
								$(target).trigger("click", [cat_ids]);
								// 滚动定位
								scrollTo(container, target);
							}
						}

					}).always(function() {
						$.loading.stop();
					});
				}
			} else {
				$("#btn_next_step").prop("disabled", false);
				$("#btn_next_step").addClass("btn-primary").removeClass('disabled');
				$("#cat_id").val($(this).data("id"));

				$("#cat_id").data($(this).data());
			}

			// 改变当前选择的分类内容
			var cat_names = [];
			var cat_id = null;

			$(".choose-category-list").find(".classDivClick").each(function() {
				cat_names.push($(this).text());
				if ($(this).data("is-parent") == 0) {
					cat_id = $(this).data("id");
				}
			});

			cat_names = cat_names.join('<i class="fa fa-angle-right"></i>');

			$("#current-choose-category").data("cat_id", cat_id);
			$("#current-choose-category").html(cat_names);
		});

		// 搜索功能的实现
		$("[name=category_search]").keyup(function() {
			// 搜索内容
			var text = $(this).val();
			// 绑定的级别
			var level = $(this).data("level");

			if (text == '') {
				$(".category-level-" + level).find("li").show();
			} else {
				$(".category-level-" + level).find("li").hide();
				$(".category-level-" + level).find("[data-search*=" + text + "]").parents("li").show();
			}
		});

		$("#used_cat_list").change(function() {
			$(this).find("option:selected").click();
		})

		//点击下一步
		$("#btn_next_step").click(function() {

			var target = $("#cat_id");

			var cat_id = $(target).data("id");
			var is_parent = $(target).data("is-parent");
			var cat_level = $(target).data("level");
			var cat_ids = $(target).data("cat-ids") + "";

			if (is_parent == 1) {
				$(".choose-category").show();
				$(".choose-category-search-list").hide();
				cat_level = 1;
				cat_ids = cat_ids.split(",");
				cat_id = cat_ids[0];

				var container = $(".category-level-" + cat_level);
				var target = $(container).find(".category-name[data-id='" + cat_id + "']");
				// 触发点击
				$(target).trigger("click", [cat_ids]);
				// 滚动定位
				scrollTo(container, target);
			} else {
				if ($("#cat_id").val() == "") {
					$("#cat_id").val(cat_id);
				}

				if ($("#cat_id").val() == "") {
					$("#cat_id").val($("#current-choose-category").data("cat_id"));
				}

				if ($("#cat_id").val() == "") {
					$.msg("请选择分类！");
				}

				$("#catForm").submit();
			}

			return false;
		});
	});
</script>
					
				</div>
			</div>
		</div>
		<!--底部内容-->
		@include('common.footer')



<script type="text/javascript">
function toFirst(target){
	var url = $(target).parents("li").find(".sub-list").find("li:first").find("a").attr("href");
	$.go(url);
}
function to(url, target){
	
}

function clearCache(){
	// 缓载
	$.loading.start();
	$.post("/site/clear-cache", {}, function(result){
		if(result.code == 0){
			$.msg(result.message);
		}else{
			$.msg(result.message, {
				time: 5000
			});
		}
	}).always(function(){
		$.loading.stop();
	});
}
// 登录成功关闭弹出框
$.login.success = function(){
	// 关闭并销毁登录窗口
	$.login.close(true);
}
</script>

<script type="text/javascript">
	// setInterval("auto_print()",10000);
	function auto_print(order_id)
	{
		$.ajax({
			type: "GET",
			url: "/site/auto-print",
			dataType: "json",
			data: {
				order_id: order_id
			},
			success: function(result) {
				if(result.code == 0)
				{
					lodop_print_html(result.print_title, result.data,result.printer);
				}
			}
		});
	}
</script>

<!-- 加载消息监听js-->
<script src="./newjs/message.js"></script>
<script src="./newjs/messageWS.js"></script>
<script type="text/javascript">
//声音监听
WS_AddUser({
	'user_id': 'shop_1717',
	'url': "ws://push.yunmall.68mall.com:7272",
	'type': "add_user"
}); 
//右下角消息提醒弹窗js
function open_message_box(data) {
	if (!data) {    
		data = {};
    }
	
	var src = window.location.href;
	
	// 如果当前框架中的链接地址和弹框的链接地址一致则不弹框
	if(data.auto_refresh == 1 && data.link && src.indexOf(data.link) != -1){
		
		var contentWindow = window;
		
		if(contentWindow.tablelist){
			contentWindow.tablelist.load({
				page: {
					cur_page: 1
				}
			});
		}else{
			contentWindow.location.reload();
		}
		
		return;
	}
	
	$('.message-pop-box').find('#message-pop-text').html(data.content);
	
	if(data.link){
		$('.message-pop-box').find('.message-btn').attr('href', data.link).show();
	}else{
		$('.message-pop-box').find('.message-btn').hide();
	}
	
	if(data.content || data.link){
		$('.message-pop-box').removeClass('down').addClass('up');
	}
	
	try {
		if(refresh_order && typeof(refresh_order) == "function") { 
			refresh_order();
        } 
    } catch(e) {}
}
$('.message-pop-box .close').click(function() {
	$('.message-pop-box').removeClass('up').addClass('down');
});
//用户信息
$(".admin").mouseenter(function() {
	window.focus();
	$("#admin-panel").show();
}).mouseleave(function() {
	$("#admin-panel").hide();
});
</script>
<script type="text/javascript">
	var clipboard = new Clipboard('.btn-copy');
    clipboard.on('success', function(e) {
        $.msg('复制成功');
    });
    clipboard.on('error', function(e) {
    	$.msg('复制失败');
    });
 	// 更新后台主框架消息弹窗
	function update_message() {
		// 是否重新获取数据
		if ($("#message-panel").html().length > 0) {
			// if (parseInt($("#counts_all").val()) != 0) {
			var time_step = 5; // 最小刷新间隔，单位：秒
			var this_time = new Date();
			if ((parseInt($("#counts_time").val()) + parseInt(time_step)) > parseInt(this_time.getTime() / 1000)) {
				return true;
			}
			// }
		}
		$.ajax({
			type: 'GET',
			url: '/site/update-message.html',
			data: {},
			dataType: 'json',
			success: function(result) {
				if (result.code == 0) {
					$("#message-panel").html(result.data);
				} else if (result.code == 1) {
				} else {
					$.msg(result.message);
				}
			}
		});
	}
	// 消息通知
	$("#message-box").mouseenter(function() {
		update_message();
		window.focus();
		$("#message-panel").show();
	}).mouseleave(function() {
		$("#message-panel").hide();
	}).find(".close").click(function() {
		$("#message-panel").hide();
	});
</script>



</body></html>