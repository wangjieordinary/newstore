<!DOCTYPE html>
<!--[if IE 8]> <html lang="zh-CN" class="ie8"> <![endif]-->
<html lang="zh-CN">
@include('common.link')
<body class="style-seller">
	
	@include('common.header')
	
	<!--中间内容-->
	<div class="seller-center">
		<div class="wrapper">
			
			@include('common.slider')
			
			<!--右侧内容-->
			<div class="seller-rihgt">
				<div class="seller-page">
					<div class="seller-page-bg"></div>
					<!--在这里调用内容-->
					<link rel="stylesheet" href="/assets/d2eace91/css/styles.css?v=20181020"/>
<div class="page">
	<div class="fixed-bar">
	<div class="item-title">
		<div class="subject">
			<h3>
				<span class="action">店铺商品分类 - 编辑</span>
				<!--帮助教程-->
                <!--<a class="help-href" href="javascript:;" data-toggle="tooltip" data-placement="auto bottom" title="点击跳转到该模块教程页面"><i class="help-icon"></i></a>-->
                <!---->
			</h3>
			
			<h5>
				
								
								<span class="action-span">
					
										
					<a  href="list.html" class="btn btn-warning click-loading">
						<i class="fa fa-reply"></i>
						返回商品分类列表
					</a>
				</span>
				
			</h5>
			
					</div>
	</div>
</div>
 
	<!-- 温馨提示 -->
	
	<div class="table-content m-t-30 clearfix">
		<form id="form1" class="form-horizontal" name="ShopCategory" action="{{url('store/category/doadd')}}" method="POST">
			@csrf
		<!-- 隐藏域 -->
		<input type="hidden" id="shopcategory-cat_id" class="form-control" name="cat_id" value="289">
		<!-- 分类名称 -->
		<div class="simple-form-field" >
<div class="form-group">
<label for="shopcategory-cat_name" class="col-sm-4 control-label">
<span class="text-danger ng-binding">*</span>
<span class="ng-binding">分类名称：</span>
</label>
<div class="col-sm-8">
<div class="form-control-box">

		
		<input type="text" id="shopcategory-cat_name" class="form-control" name="cate_name" placeholder="请输入商品分类名称！" value="">
		
		
</div>

<div class="help-block help-block-t"><div class="help-block help-block-t">1~30个字符，支持中、英文、数字及符号</div></div>
</div>
</div>
</div>
		<!-- 上级分类ID -->
		<div class="simple-form-field" >
<div class="form-group">
<label for="shopcategory-parent_id" class="col-sm-4 control-label">

<span class="ng-binding">上级分类：</span>
</label>
<div class="col-sm-8">
<div class="form-control-box">

		
		<select id="shopcategory-parent_id" class="form-control chosen-select" name="parent_id">
			<option value="0" selected>未选择</option>
		@foreach($catelist as $parent)
			<option value="{{$parent->id}}">
				{{$parent->cate_name}}
			</option>
		@endforeach
			<!-- <option value="296">肉干肉脯</option>
			<option value="301">果干蜜饯</option>
			<option value="307">水果生鲜</option>
			<option value="312">休闲零食</option> -->
		</select>
		
		
</div>

<div class="help-block help-block-t"><div class="help-block help-block-t">如果不选择上级分类，则新增的分类为顶级分类</div></div>
</div>
</div>
</div>
		<!-- 是否显示 -->
		<div class="simple-form-field" >
<div class="form-group">
<label for="shopcategory-is_show" class="col-sm-4 control-label">

<span class="ng-binding">是否显示：</span>
</label>
<div class="col-sm-8">
<div class="form-control-box">

		
		<label class="control-label control-label-switch">
<div class="switch bootstrap-switch bootstrap-switch-mini sm-nav-switch">
<input type="hidden" name="is_show" value="0"><label><input type="checkbox" id="shopcategory-is_show" class="form-control b-n" name="is_show" value="1" checked data-on-text="是" data-off-text="否"> </label>
</div>
</label>
		
		
</div>

<div class="help-block help-block-t"><div class="help-block help-block-t">控制前台店铺首页，店铺商品分类是否展示</div></div>
</div>
</div>
</div>
		<!-- 排序 -->
		<div class="simple-form-field" >
<div class="form-group">
<label for="shopcategory-cat_sort" class="col-sm-4 control-label">
<span class="text-danger ng-binding">*</span>
<span class="ng-binding">排序：</span>
</label>
<div class="col-sm-8">
<div class="form-control-box">

		
		<input type="text" id="shopcategory-cat_sort" class="form-control small m-r-10" name="cat_sort" value="255">
		
		
</div>

<div class="help-block help-block-t"><div class="help-block help-block-t">数字范围为0~255，数字越小越靠前</div></div>
</div>
</div>
</div>
		<!-- 确认提交 -->
		<div class="simple-form-field" >
<div class="form-group">
<label for="" class="col-sm-4 control-label">


</label>
<div class="col-sm-8">
<div class="form-control-box">

		
		<input type="button" id='btn_submit' value='确认提交' class="btn btn-primary" />
		
		
</div>

<div class="help-block help-block-t"></div>
</div>
</div>
</div>
		
		</form>
	</div>
</div>
<!-- 表单验证 -->
<script src="/assets/d2eace91/js/validate/jquery.validate.js?v=20180027"></script>
<script src="/assets/d2eace91/js/validate/jquery.validate.custom.js?v=20180027"></script>
<script src="/assets/d2eace91/js/validate/messages_zh.js?v=20180027"></script>
<!-- 验证规则 -->
<script id="client_rules" type="text">
[{"id": "shopcategory-cat_name", "name": "ShopCategory[cat_name]", "attribute": "cat_name", "rules": {"required":true,"messages":{"required":"分类名称不能为空。"}}},{"id": "shopcategory-cat_sort", "name": "ShopCategory[cat_sort]", "attribute": "cat_sort", "rules": {"required":true,"messages":{"required":"排序不能为空。"}}},{"id": "shopcategory-parent_id", "name": "ShopCategory[parent_id]", "attribute": "parent_id", "rules": {"integer":{"pattern":"/^\\s*[+-]?\\d+\\s*$/"},"messages":{"integer":"上级分类必须是整数。"}}},{"id": "shopcategory-is_show", "name": "ShopCategory[is_show]", "attribute": "is_show", "rules": {"integer":{"pattern":"/^\\s*[+-]?\\d+\\s*$/"},"messages":{"integer":"是否显示必须是整数。"}}},{"id": "shopcategory-cat_sort", "name": "ShopCategory[cat_sort]", "attribute": "cat_sort", "rules": {"integer":{"pattern":"/^\\s*[+-]?\\d+\\s*$/"},"messages":{"integer":"排序必须是整数。"}}},{"id": "shopcategory-cat_name", "name": "ShopCategory[cat_name]", "attribute": "cat_name", "rules": {"string":true,"messages":{"string":"分类名称必须是一条字符串。","maxlength":"分类名称只能包含至多30个字符。"},"maxlength":30}},{"id": "shopcategory-keywords", "name": "ShopCategory[keywords]", "attribute": "keywords", "rules": {"string":true,"messages":{"string":"Keywords必须是一条字符串。","maxlength":"Keywords只能包含至多255个字符。"},"maxlength":255}},{"id": "shopcategory-cat_desc", "name": "ShopCategory[cat_desc]", "attribute": "cat_desc", "rules": {"string":true,"messages":{"string":"Cat Desc必须是一条字符串。","maxlength":"Cat Desc只能包含至多255个字符。"},"maxlength":255}},{"id": "shopcategory-cat_sort", "name": "ShopCategory[cat_sort]", "attribute": "cat_sort", "rules": {"integer":{"pattern":"/^\\s*[+-]?\\d+\\s*$/"},"messages":{"integer":"排序必须是整数。","min":"排序必须不小于0。","max":"排序必须不大于255。"},"min":0,"max":255}},]
</script>
<script type="text/javascript">
	$().ready(function() {
		var validator = $("#form1").validate();
		// 验证规则，此验证规则会影响编辑器中JavaScript的的格式化操作
		$.validator.addRules($("#client_rules").html());
		$("#btn_submit").click(function() {
			if (!validator.form()) {
				return;
			}
			//加载提示
			$.loading.start();

			var url = $("#form1").attr("action");
			var data = $("#form1").serializeJson();
			$.post(url, data, function(result) {
				if (result.code == 0) {
					$.msg(result.message);
					$.go('list');
				} else {
					$.msg(result.message, {
						time: 5000
					});
				}
			}, "json").always(function() {
				$.loading.stop();
			});

		});
	});
</script>
					
				</div>
			</div>
		</div>
		<!--底部内容-->
		@include('common.footer')

</body>

<script type="text/javascript">
function toFirst(target){
	var url = $(target).parents("li").find(".sub-list").find("li:first").find("a").attr("href");
	$.go(url);
}
function to(url, target){
	
}

function clearCache(){
	// 缓载
	$.loading.start();
	$.post("/site/clear-cache", {}, function(result){
		if(result.code == 0){
			$.msg(result.message);
		}else{
			$.msg(result.message, {
				time: 5000
			});
		}
	}).always(function(){
		$.loading.stop();
	});
}
// 登录成功关闭弹出框
$.login.success = function(){
	// 关闭并销毁登录窗口
	$.login.close(true);
}
</script>

<script type="text/javascript">
	// setInterval("auto_print()",10000);
	function auto_print(order_id)
	{
		$.ajax({
			type: "GET",
			url: "/site/auto-print",
			dataType: "json",
			data: {
				order_id: order_id
			},
			success: function(result) {
				if(result.code == 0)
				{
					lodop_print_html(result.print_title, result.data,result.printer);
				}
			}
		});
	}
</script>

<!-- 加载消息监听js-->
<script src="/assets/d2eace91/js/message/message.js?v=20180027"></script>
<script src="/assets/d2eace91/js/message/messageWS.js?v=20180027"></script>
<script type="text/javascript">
//声音监听
WS_AddUser({
	'user_id': 'shop_1717',
	'url': "ws://push.yunmall.68mall.com:7272",
	'type': "add_user"
}); 
//右下角消息提醒弹窗js
function open_message_box(data) {
	if (!data) {    
		data = {};
    }
	
	var src = window.location.href;
	
	// 如果当前框架中的链接地址和弹框的链接地址一致则不弹框
	if(data.auto_refresh == 1 && data.link && src.indexOf(data.link) != -1){
		
		var contentWindow = window;
		
		if(contentWindow.tablelist){
			contentWindow.tablelist.load({
				page: {
					cur_page: 1
				}
			});
		}else{
			contentWindow.location.reload();
		}
		
		return;
	}
	
	$('.message-pop-box').find('#message-pop-text').html(data.content);
	
	if(data.link){
		$('.message-pop-box').find('.message-btn').attr('href', data.link).show();
	}else{
		$('.message-pop-box').find('.message-btn').hide();
	}
	
	if(data.content || data.link){
		$('.message-pop-box').removeClass('down').addClass('up');
	}
	
	try {
		if(refresh_order && typeof(refresh_order) == "function") { 
			refresh_order();
        } 
    } catch(e) {}
}
$('.message-pop-box .close').click(function() {
	$('.message-pop-box').removeClass('up').addClass('down');
});
//用户信息
$(".admin").mouseenter(function() {
	window.focus();
	$("#admin-panel").show();
}).mouseleave(function() {
	$("#admin-panel").hide();
});
</script>
<script type="text/javascript">
	var clipboard = new Clipboard('.btn-copy');
    clipboard.on('success', function(e) {
        $.msg('复制成功');
    });
    clipboard.on('error', function(e) {
    	$.msg('复制失败');
    });
 	// 更新后台主框架消息弹窗
	function update_message() {
		// 是否重新获取数据
		if ($("#message-panel").html().length > 0) {
			// if (parseInt($("#counts_all").val()) != 0) {
			var time_step = 5; // 最小刷新间隔，单位：秒
			var this_time = new Date();
			if ((parseInt($("#counts_time").val()) + parseInt(time_step)) > parseInt(this_time.getTime() / 1000)) {
				return true;
			}
			// }
		}
		$.ajax({
			type: 'GET',
			url: '/site/update-message.html',
			data: {},
			dataType: 'json',
			success: function(result) {
				if (result.code == 0) {
					$("#message-panel").html(result.data);
				} else if (result.code == 1) {
				} else {
					$.msg(result.message);
				}
			}
		});
	}
	// 消息通知
	$("#message-box").mouseenter(function() {
		update_message();
		window.focus();
		$("#message-panel").show();
	}).mouseleave(function() {
		$("#message-panel").hide();
	}).find(".close").click(function() {
		$("#message-panel").hide();
	});
</script>

</html>

