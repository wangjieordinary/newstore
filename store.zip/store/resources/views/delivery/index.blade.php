<!DOCTYPE html>
<!--[if IE 8]> <html lang="zh-CN" class="ie8"> <![endif]-->
<html lang="zh-CN">
@include('common.link')
<body class="style-seller">
	
	@include('common.header')
	
	<!--中间内容-->
	<div class="seller-center">
		<div class="wrapper">
			
			<!--左侧部分-->
			@include('order.slider')
			
			<!--右侧内容-->
			<div class="seller-rihgt">
				<div class="seller-page">
					<div class="seller-page-bg"></div>
					<!--在这里调用内容-->
					
<link rel="stylesheet" href="/static/css/styles.css?v=20181020"/>
<link rel="stylesheet" href="/static/css/bootstrap-datetimepicker.min.css?v=20181020"/>
<!-- 日历控件-->
<script src="/static/js/bootstrap-datetimepicker.min.js?v=20180027"></script>
<script src="/static/js/locales/bootstrap-datetimepicker.zh-CN.js?v=20180027"></script>
<div class="page">
	<div class="fixed-bar">
	<div class="item-title">
		<div class="subject">
			<h3>
				<span class="action">发货单管理 - 发货单列表</span>
				<!--帮助教程-->
                <!--<a class="help-href" href="javascript:;" data-toggle="tooltip" data-placement="auto bottom" title="点击跳转到该模块教程页面"><i class="help-icon"></i></a>-->
                <!--- -->
			</h3>
			
					</div>
	</div>
</div>
 
	
	
<div class="explanation m-b-10">
	<div class="title explain-checkZoom" title="">
		<i class="fa fa-bullhorn"></i>
		<h4>温馨提示</h4>
	</div>
	<ul class="explain-panel">
				<li>
			<span>一笔订单，拆单发货，则会生成多个发货单。卖家对订单发货选择第三方物流，则发货单列表中才会展示打印快递单按钮</span>
		</li>
				<li>
			<span>卖家对订单进行发货，在发货页面，点击确认发货后，发货单状态则变为"已发货"。如果卖家对订单进行发货，在发货页面，未点击确认发货，将发货页面关闭，此时也会生成发货单，发货单的状态是"待发货"，待发货状态的发货单，卖家可以进行取消发货单和继续发货操作。取消发货单，则发货单被删除</span>
		</li>
		
	</ul>
</div>

	<!--搜索-->
	<div class="search-term m-b-10">
		<form id="searchForm" action="/trade/delivery/list.html" method="GET">
		<div class="simple-form-field">
			<div class="form-group">
				<div class="form-control-wrap">
					<select id="keywords_type" name="keywords_type" class="form-control w100 m-r-5">
						<option value="">请选择</option>
						<option value="1">买家账号/买家姓名</option>
						<option value="2">订单编号</option>
						<option value="3">发货单编号</option>
					</select>
					<input type="text" id="keywords" class="form-control" name="keywords" placeholder="请输入关键字">
				</div>
			</div>
		</div>
		<div class="simple-form-field">
			<div class="form-group">
				<label class="control-label">
					<span>发货单状态：</span>
				</label>
				<div class="form-control-wrap"><select id="delivery_status" class="form-control" name="delivery_status">
<option value="">全部</option>
<option value="unshipped">待发货</option>
<option value="shipped">已发货</option>
</select></div>
			</div>
		</div>
		<div class="simple-form-field toggle hide">
			<div class="form-group">
				<label class="control-label">
					<span>下单时间：</span>
				</label>
				<div class="form-control-wrap">
					<input type="text" id="add_time_begin" class="form-control form_datetime ipt" name="add_time_begin" placeholder="开始时间">
					<span class="ctime">至</span>
					<input type="text" id="add_time_end" class="form-control form_datetime ipt" name="add_time_end" placeholder="结束时间">
				</div>
			</div>
		</div>
		<div class="simple-form-field toggle hide">
			<div class="form-group">
				<label class="control-label">
					<span>发货时间：</span>
				</label>
				<div class="form-control-wrap">
					<input type="text" id="send_time_begin" class="form-control form_datetime ipt" name="send_time_begin" placeholder="开始时间">
					<span class="ctime">至</span>
					<input type="text" id="send_time_end" class="form-control form_datetime ipt" name="send_time_end" placeholder="结束时间">
				</div>
			</div>
		</div>
		<div class="simple-form-field">
			<button class="btn btn-primary m-r-5">搜索</button>
			
			<input type="button" id="btn_export" class="btn btn-default m-r-5" value="导出" />
			
			<a id="searchMore" class="btn-link">更多筛选条件</a>
		</div>
		</form>
	</div>
	

	<div id="table_list">
		
<div class="common-title">
	<div class="ftitle">
		<h3>发货单列表</h3>
		
		<h5>
			(&nbsp;共
			<span data-total-record=true>4</span>
			条记录&nbsp;)
		</h5>
		
	</div>
	<div class="operate m-l-20">
		
		<a class="reload" href="javascript:tablelist.load();" data-toggle="tooltip" data-placement="auto bottom" title="刷新数据">
			<i class="fa fa-refresh"></i>
		</a>
		
		
		
	</div>
</div>

		<!--列表内容-->
		<div class="item-list-hd">
	<ul class="item-list-tabs">
		<li id="all" class="tabs-t current">
			<a>全部发货单（<span id="delivery-all"></span>）</a>
		</li>
		<li id="unshipped" class="tabs-t">
			<a>等待发货（<span id="delivery-unshipped"></span>）</a>
		</li>
		<li id="shipped" class="tabs-t last">
			<a>已发货（<span id="delivery-shipped"></span>）</a>
		</li>
	</ul>
</div>
<script type="text/javascript">
	$().ready(function() {
		$("li[class^='tabs-']").click(function() {
			$("li[class^='tabs-']").removeClass('current');
			$(this).addClass('current');

			$("#delivery_status").val($(this).attr("id"));

			tablelist = $("#table_list").tablelist({
				params: $("#searchForm").serializeJson()
			});
			tablelist.load();
		});

		var url = '/store/delivery/get-delivery-counts';
		var data = $("#searchForm").serializeJson();
		$.ajax({
			url: url,
			dataType: 'json',
			type: 'POST',
			data: data,
			success: function(data) {
				$("#delivery-all").html(data.all);
				$("#delivery-unshipped").html(data.unshipped);
				$("#delivery-shipped").html(data.shipped);
			}
		});
	});
</script>

		<div class="table-responsive order">

			<table class="table">
				<colgroup>
					<col class="item-list-col0">
					</col>


					<!--商品信息-->
					<col class="w250">
					</col>


					<!--单价（元）-->
					<col class="item-list-col2">
					</col>


					<!--数量-->
					<col class="item-list-col3">
					</col>


					<!--买家信息-->
					<col class="item-list-col5">
					</col>


					<!--交易状态-->
					<col class="item-list-col6">
					</col>


					<!--操作-->
					<col class="item-list-col9">
					</col>

				</colgroup>
				<thead>
					<tr>
						<!--复选框列样式tcheck，一般复选框样式checkBox,全选复选框样式在一般复选框样式后再新加allCheckBox样式-->
						<th class="tcheck">
							<input type="checkbox" class="checkBox allCheckBox">
							</input>
						</th>
						<!--排序样式sort默认，asc升序，desc降序-->
						<th>
							商品信息
							<span class=""></span>
						</th>
						<th>
							单价（元）
							<span class=""></span>
						</th>
						<th class="text-c">
							数量
							<span class=""></span>
						</th>
						<th class="text-c">
							买家
							<span class=""></span>
						</th>
						<th class="text-c">
							发货单状态
							<span class=""></span>
						</th>
						<!--操作列样式handle-->
						<th class="handle">操作</th>
					</tr>
				</thead>
								<!--以下为循环内容-->
								<tbody class="order">
					<tr class="sep-row">
						<td colspan="7"></td>
					</tr>
					<!--订单编号-->
					<tr class="order-hd">
						<td class="tcheck">
							<input name="delivery_id_box" type="checkbox" class="checkBox" value="1133" />
						</td>
						<td colspan="6">
							<div class="basic-info" >
								<span class="invoice-num">发货单编号：20171214023764762</span>
								<span class="deal-time">发货时间：2017-12-14 10:37:51</span>
								<span class="order-num">
									订单编号：
									<a href="/trade/order/info.html?id=4831" target="_blank" title="点击查看订单详情">20171213052924918910</a>
								</span>
								<span class="deal-time">下单时间：2017-12-13 13:29:24</span>
								
							</div>
							
							
						</td>
					</tr>
					<!--订单内容-->
										<tr class="order-item">
						<td class="item" colspan="2">
							<div class="pic-info">
								<a href="http://www.68dsw.com/goods-39764.html" data-sku_id="44144" class="goods-thumb" title="查看商品详情" target="_blank">
									<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/16/14949021557219.jpg?x-oss-process=image/resize,m_pad,limit_0,h_80,w_80" alt="查看商品详情"></img>
								</a>
							</div>
							<div class="txt-info">
								<div class="desc">
									<a class="goods-name" href="http://www.68dsw.com/goods-39764.html" target="_blank" title="查看商品详情">
																				
										智利进口鸡胸1kg鸡胸肉新鲜鸡脯肉冷冻鸡大胸非即食
									</a>
									<!-- <a class="snap">【交易快照】</a> -->
								</div>
								<div class="props">
																		<span></span>
									
								</div>
								
								<!-- 
							<div class="icon">
								<a class="icon-7day" href="javascript:;" target="_blank" title="7天退货" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/7day_60.gif">
								</a>
								<a class="icon-pz" href="javascript:;" target="_blank" title="品质保证" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/pz_60.gif">
								</a>
								<a class="icon-jswl" href="javascript:;" target="_blank" title="破损补寄" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/jswl_60.gif">
								</a>
								<a class="icon-psbf" href="javascript:;" target="_blank" title="急速物流" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/psbf_60.gif">
								</a>
							</div> -->
							</div>
						</td>
						<!--单价-->
						<td class="price">
							<div class="price m-b-3">¥98.00元</div>
							
							
							
							 							
														
							
														
														
							
						</td>
						<!--数量-->
						<td class="num text-c">1</td>

												<!-- 公共部分开始 -->
						<!--买家信息-->
						<td class="contact" rowspan="1">
							<div class="ng-binding">
								<span class="text-c popover-box buyer">
									<a class="nickname">汽车管家旗舰店店长</a>
									<div class="popover-info" style="left: auto; right:-280px">
										<i class="fa fa-caret-left"></i>
										<ul>
											<li>
												<h3>
													<i class="fa fa-user"></i>
													联系信息
												</h3>
											</li>
											<li>
												<div class="dt">
													<span>姓名：</span>
												</div>
												<div class="dd">ces</div>
											</li>
											<li>
												<div class="dt">
													<span>电话：</span>
												</div>
												<div class="dd">18103352079</div>
											</li>
											<li>
												<div class="dt">
													<span>地址：</span>
												</div>
												<div class="dd">河北省-秦皇岛市-海港区-森林逸城 xxxxxxxx</div>
											</li>
											<li>
												<div class="dt">
													<span>留言：</span>
												</div>
												<div class="dd"></div>
											</li>
										</ul>
									</div>
								</span>
								<span class="text-c">
									<a class="btn btn-info btn-xs c-fff" href="/trade/order/list?uid=8" target="_blank">查看所有订单</a>
								</span>
															</div>
						</td>
						<!--交易状态-->
						<td class="trade-status pos-r" rowspan="1">
							<div class="ng-binding">
								<span class="text-c">
									
									<font class="c-red">待发货</font>
									
								</span>
								<span class="text-c">普通快递</span>
								
							</div>
							
						</td>
						<!--查看物流现在点击跳转到订单详情页面，直接定位到物流模块-->

						<!--操作-->
						<td class="handle" rowspan="1">
							<div class="ng-binding">
								<span class="text-c">
									<a href="info?id=1133">发货单详情</a>
								</span>
								<span class="text-c">
									<a href="/trade/order/print.html?did=1133" target="_blank">打印发货单</a>
								</span>

								
								
								
								<span class="text-c">
									<a href="/trade/delivery/to-shipping?id=1133" class="active">去发货</a>
								</span>
								
								
							</div>
						</td>
						<!-- 公共部分结束 -->
											</tr>
					
				</tbody>

								<tbody class="order">
					<tr class="sep-row">
						<td colspan="7"></td>
					</tr>
					<!--订单编号-->
					<tr class="order-hd">
						<td class="tcheck">
							<input name="delivery_id_box" type="checkbox" class="checkBox" value="915" />
						</td>
						<td colspan="6">
							<div class="basic-info" style="max-width: 850px;">
								<span class="invoice-num">发货单编号：20170612075350866</span>
								<span class="deal-time">发货时间：2017-06-12 15:53:04</span>
								<span class="order-num">
									订单编号：
									<a href="/trade/order/info.html?id=4022" target="_blank" title="点击查看订单详情">20170610013926967160</a>
								</span>
								<span class="deal-time">下单时间：2017-06-10 09:39:26</span>
								
							</div>
							
							<a class="btn c-fff btn-warning btn-xs m-r-10 pull-right print-sheet" data-id="915" data-code='ANE'>打印电子面单</a>
							
							
							<a class="btn c-fff btn-warning btn-xs m-r-10 pull-right" href="/trade/delivery/print?id=915" target="_blank">打印快递单</a>
							
						</td>
					</tr>
					<!--订单内容-->
										<tr class="order-item">
						<td class="item" colspan="2">
							<div class="pic-info">
								<a href="http://www.68dsw.com/goods-39761.html" data-sku_id="44141" class="goods-thumb" title="查看商品详情" target="_blank">
									<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/taobao-yun-images/526008527210/TB1VKvbKFXXXXX4XVXXXXXXXXXX_!!0-item_pic.jpg?x-oss-process=image/resize,m_pad,limit_0,h_80,w_80" alt="查看商品详情"></img>
								</a>
							</div>
							<div class="txt-info">
								<div class="desc">
									<a class="goods-name" href="http://www.68dsw.com/goods-39761.html" target="_blank" title="查看商品详情">
																				
										顺意生 新鲜蔬菜 新鲜小油菜 精品蔬菜油菜500g 保鲜配送
									</a>
									<!-- <a class="snap">【交易快照】</a> -->
								</div>
								<div class="props">
																		<span></span>
									
								</div>
								
								<!-- 
							<div class="icon">
								<a class="icon-7day" href="javascript:;" target="_blank" title="7天退货" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/7day_60.gif">
								</a>
								<a class="icon-pz" href="javascript:;" target="_blank" title="品质保证" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/pz_60.gif">
								</a>
								<a class="icon-jswl" href="javascript:;" target="_blank" title="破损补寄" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/jswl_60.gif">
								</a>
								<a class="icon-psbf" href="javascript:;" target="_blank" title="急速物流" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/psbf_60.gif">
								</a>
							</div> -->
							</div>
						</td>
						<!--单价-->
						<td class="price">
							<div class="price m-b-3">¥9.90元</div>
							
							
							
							 							
														
							
														
														
							
						</td>
						<!--数量-->
						<td class="num text-c">3</td>

												<!-- 公共部分开始 -->
						<!--买家信息-->
						<td class="contact" rowspan="2">
							<div class="ng-binding">
								<span class="text-c popover-box buyer">
									<a class="nickname"></a>
									<div class="popover-info" style="left: auto; right:-280px">
										<i class="fa fa-caret-left"></i>
										<ul>
											<li>
												<h3>
													<i class="fa fa-user"></i>
													联系信息
												</h3>
											</li>
											<li>
												<div class="dt">
													<span>姓名：</span>
												</div>
												<div class="dd">商之翼员工</div>
											</li>
											<li>
												<div class="dt">
													<span>电话：</span>
												</div>
												<div class="dd">15986352445</div>
											</li>
											<li>
												<div class="dt">
													<span>地址：</span>
												</div>
												<div class="dd">河北省-秦皇岛市-海港区 金屋秦皇半岛二区物业楼51号3层 秦皇岛商之翼网络科技有限公司</div>
											</li>
											<li>
												<div class="dt">
													<span>留言：</span>
												</div>
												<div class="dd"></div>
											</li>
										</ul>
									</div>
								</span>
								<span class="text-c">
									<a class="btn btn-info btn-xs c-fff" href="/trade/order/list?uid=1656" target="_blank">查看所有订单</a>
								</span>
															</div>
						</td>
						<!--交易状态-->
						<td class="trade-status pos-r" rowspan="2">
							<div class="ng-binding">
								<span class="text-c">
									
									<font class="c-green">已发货</font>
									
								</span>
								<span class="text-c">普通快递</span>
								
								<span class="text-c">
									<a class="view-logistics" href="/trade/delivery/info?id=915">查看物流</a>
								</span>
								
							</div>
							
						</td>
						<!--查看物流现在点击跳转到订单详情页面，直接定位到物流模块-->

						<!--操作-->
						<td class="handle" rowspan="2">
							<div class="ng-binding">
								<span class="text-c">
									<a href="info?id=915">发货单详情</a>
								</span>
								<span class="text-c">
									<a href="/trade/order/print.html?did=915" target="_blank">打印发货单</a>
								</span>

								
								
								
								
							</div>
						</td>
						<!-- 公共部分结束 -->
											</tr>
										<tr class="order-item">
						<td class="item" colspan="2">
							<div class="pic-info">
								<a href="http://www.68dsw.com/goods-39763.html" data-sku_id="44143" class="goods-thumb" title="查看商品详情" target="_blank">
									<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/taobao-yun-images/539647949179/TB1CSTZPVXXXXb2XFXXXXXXXXXX_!!0-item_pic.jpg?x-oss-process=image/resize,m_pad,limit_0,h_80,w_80" alt="查看商品详情"></img>
								</a>
							</div>
							<div class="txt-info">
								<div class="desc">
									<a class="goods-name" href="http://www.68dsw.com/goods-39763.html" target="_blank" title="查看商品详情">
																				
										大西冷澳洲进口新鲜牛腩粒切块冷冻批发新鲜包邮
									</a>
									<!-- <a class="snap">【交易快照】</a> -->
								</div>
								<div class="props">
																		<span></span>
									
								</div>
								
								<!-- 
							<div class="icon">
								<a class="icon-7day" href="javascript:;" target="_blank" title="7天退货" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/7day_60.gif">
								</a>
								<a class="icon-pz" href="javascript:;" target="_blank" title="品质保证" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/pz_60.gif">
								</a>
								<a class="icon-jswl" href="javascript:;" target="_blank" title="破损补寄" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/jswl_60.gif">
								</a>
								<a class="icon-psbf" href="javascript:;" target="_blank" title="急速物流" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/psbf_60.gif">
								</a>
							</div> -->
							</div>
						</td>
						<!--单价-->
						<td class="price">
							<div class="price m-b-3">¥69.00元</div>
							
							
							
							 							
														
							
														
														
							
						</td>
						<!--数量-->
						<td class="num text-c">2</td>

											</tr>
					
				</tbody>

								<tbody class="order">
					<tr class="sep-row">
						<td colspan="7"></td>
					</tr>
					<!--订单编号-->
					<tr class="order-hd">
						<td class="tcheck">
							<input name="delivery_id_box" type="checkbox" class="checkBox" value="914" />
						</td>
						<td colspan="6">
							<div class="basic-info" style="max-width: 850px;">
								<span class="invoice-num">发货单编号：20170612075016250</span>
								<span class="deal-time">发货时间：2017-06-12 15:50:55</span>
								<span class="order-num">
									订单编号：
									<a href="/trade/order/info.html?id=4027" target="_blank" title="点击查看订单详情">20170612071859137930</a>
								</span>
								<span class="deal-time">下单时间：2017-06-12 15:18:59</span>
								
							</div>
							
							<a class="btn c-fff btn-warning btn-xs m-r-10 pull-right print-sheet" data-id="914" data-code='ANE'>打印电子面单</a>
							
							
							<a class="btn c-fff btn-warning btn-xs m-r-10 pull-right" href="/trade/delivery/print?id=914" target="_blank">打印快递单</a>
							
						</td>
					</tr>
					<!--订单内容-->
										<tr class="order-item">
						<td class="item" colspan="2">
							<div class="pic-info">
								<a href="http://www.68dsw.com/goods-39794.html" data-sku_id="44187" class="goods-thumb" title="查看商品详情" target="_blank">
									<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/06/12/14972376079884.jpg?x-oss-process=image/resize,m_pad,limit_0,h_80,w_80" alt="查看商品详情"></img>
								</a>
							</div>
							<div class="txt-info">
								<div class="desc">
									<a class="goods-name" href="http://www.68dsw.com/goods-39794.html" target="_blank" title="查看商品详情">
																				
										康师傅冰红茶苹果味550ml
									</a>
									<!-- <a class="snap">【交易快照】</a> -->
								</div>
								<div class="props">
																		<span></span>
									
								</div>
								
								<!-- 
							<div class="icon">
								<a class="icon-7day" href="javascript:;" target="_blank" title="7天退货" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/7day_60.gif">
								</a>
								<a class="icon-pz" href="javascript:;" target="_blank" title="品质保证" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/pz_60.gif">
								</a>
								<a class="icon-jswl" href="javascript:;" target="_blank" title="破损补寄" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/jswl_60.gif">
								</a>
								<a class="icon-psbf" href="javascript:;" target="_blank" title="急速物流" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/psbf_60.gif">
								</a>
							</div> -->
							</div>
						</td>
						<!--单价-->
						<td class="price">
							<div class="price m-b-3">¥3.00元</div>
							
							
							
							 							
														
							
														
														
							
						</td>
						<!--数量-->
						<td class="num text-c">1</td>

												<!-- 公共部分开始 -->
						<!--买家信息-->
						<td class="contact" rowspan="1">
							<div class="ng-binding">
								<span class="text-c popover-box buyer">
									<a class="nickname"></a>
									<div class="popover-info" style="left: auto; right:-280px">
										<i class="fa fa-caret-left"></i>
										<ul>
											<li>
												<h3>
													<i class="fa fa-user"></i>
													联系信息
												</h3>
											</li>
											<li>
												<div class="dt">
													<span>姓名：</span>
												</div>
												<div class="dd">商之翼员工</div>
											</li>
											<li>
												<div class="dt">
													<span>电话：</span>
												</div>
												<div class="dd">15986352445</div>
											</li>
											<li>
												<div class="dt">
													<span>地址：</span>
												</div>
												<div class="dd">河北省-秦皇岛市-山海关区 金屋秦皇半岛二区物业楼51号3层 秦皇岛商之翼网络科技有限公司</div>
											</li>
											<li>
												<div class="dt">
													<span>留言：</span>
												</div>
												<div class="dd"></div>
											</li>
										</ul>
									</div>
								</span>
								<span class="text-c">
									<a class="btn btn-info btn-xs c-fff" href="/trade/order/list?uid=1656" target="_blank">查看所有订单</a>
								</span>
															</div>
						</td>
						<!--交易状态-->
						<td class="trade-status pos-r" rowspan="1">
							<div class="ng-binding">
								<span class="text-c">
									
									<font class="c-green">已发货</font>
									
								</span>
								<span class="text-c">普通快递</span>
								
								<span class="text-c">
									<a class="view-logistics" href="/trade/delivery/info?id=914">查看物流</a>
								</span>
								
							</div>
							
						</td>
						<!--查看物流现在点击跳转到订单详情页面，直接定位到物流模块-->

						<!--操作-->
						<td class="handle" rowspan="1">
							<div class="ng-binding">
								<span class="text-c">
									<a href="info?id=914">发货单详情</a>
								</span>
								<span class="text-c">
									<a href="/trade/order/print.html?did=914" target="_blank">打印发货单</a>
								</span>

								
								
								
								
							</div>
						</td>
						<!-- 公共部分结束 -->
											</tr>
					
				</tbody>

								<tbody class="order last">
					<tr class="sep-row">
						<td colspan="7"></td>
					</tr>
					<!--订单编号-->
					<tr class="order-hd">
						<td class="tcheck">
							<input name="delivery_id_box" type="checkbox" class="checkBox" value="913" />
						</td>
						<td colspan="6">
							<div class="basic-info" >
								<span class="invoice-num">发货单编号：20170612071632296</span>
								<span class="deal-time">发货时间：2017-06-12 15:16:36</span>
								<span class="order-num">
									订单编号：
									<a href="/trade/order/info.html?id=4025" target="_blank" title="点击查看订单详情">20170612065436860270</a>
								</span>
								<span class="deal-time">下单时间：2017-06-12 14:54:36</span>
								
							</div>
							
							
						</td>
					</tr>
					<!--订单内容-->
										<tr class="order-item">
						<td class="item" colspan="2">
							<div class="pic-info">
								<a href="http://www.68dsw.com/goods-39794.html" data-sku_id="44187" class="goods-thumb" title="查看商品详情" target="_blank">
									<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/06/12/14972376079884.jpg?x-oss-process=image/resize,m_pad,limit_0,h_80,w_80" alt="查看商品详情"></img>
								</a>
							</div>
							<div class="txt-info">
								<div class="desc">
									<a class="goods-name" href="http://www.68dsw.com/goods-39794.html" target="_blank" title="查看商品详情">
																				
										康师傅冰红茶苹果味550ml
									</a>
									<!-- <a class="snap">【交易快照】</a> -->
								</div>
								<div class="props">
																		<span></span>
									
								</div>
								
								<!-- 
							<div class="icon">
								<a class="icon-7day" href="javascript:;" target="_blank" title="7天退货" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/7day_60.gif">
								</a>
								<a class="icon-pz" href="javascript:;" target="_blank" title="品质保证" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/pz_60.gif">
								</a>
								<a class="icon-jswl" href="javascript:;" target="_blank" title="破损补寄" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/jswl_60.gif">
								</a>
								<a class="icon-psbf" href="javascript:;" target="_blank" title="急速物流" data-toggle="tooltip" data-placement="auto bottom">
									<img src="/images/common/psbf_60.gif">
								</a>
							</div> -->
							</div>
						</td>
						<!--单价-->
						<td class="price">
							<div class="price m-b-3">¥3.00元</div>
							
							
							
							 							
														
							
														
														
							
						</td>
						<!--数量-->
						<td class="num text-c">1</td>

												<!-- 公共部分开始 -->
						<!--买家信息-->
						<td class="contact" rowspan="1">
							<div class="ng-binding">
								<span class="text-c popover-box buyer">
									<a class="nickname"></a>
									<div class="popover-info" style="left: auto; right:-280px">
										<i class="fa fa-caret-left"></i>
										<ul>
											<li>
												<h3>
													<i class="fa fa-user"></i>
													联系信息
												</h3>
											</li>
											<li>
												<div class="dt">
													<span>姓名：</span>
												</div>
												<div class="dd">商之翼员工</div>
											</li>
											<li>
												<div class="dt">
													<span>电话：</span>
												</div>
												<div class="dd">15986352445</div>
											</li>
											<li>
												<div class="dt">
													<span>地址：</span>
												</div>
												<div class="dd">河北省-秦皇岛市-海港区 金屋秦皇半岛二区物业楼51号3层 秦皇岛商之翼网络科技有限公司</div>
											</li>
											<li>
												<div class="dt">
													<span>留言：</span>
												</div>
												<div class="dd"></div>
											</li>
										</ul>
									</div>
								</span>
								<span class="text-c">
									<a class="btn btn-info btn-xs c-fff" href="/trade/order/list?uid=1656" target="_blank">查看所有订单</a>
								</span>
															</div>
						</td>
						<!--交易状态-->
						<td class="trade-status pos-r" rowspan="1">
							<div class="ng-binding">
								<span class="text-c">
									
									<font class="c-red">待发货</font>
									
								</span>
								<span class="text-c">普通快递</span>
								
							</div>
							
						</td>
						<!--查看物流现在点击跳转到订单详情页面，直接定位到物流模块-->

						<!--操作-->
						<td class="handle" rowspan="1">
							<div class="ng-binding">
								<span class="text-c">
									<a href="info?id=913">发货单详情</a>
								</span>
								<span class="text-c">
									<a href="/trade/order/print.html?did=913" target="_blank">打印发货单</a>
								</span>

								
								
								
								<span class="text-c">
									<a href="/trade/delivery/to-shipping?id=913" class="active">去发货</a>
								</span>
								
								
							</div>
						</td>
						<!-- 公共部分结束 -->
											</tr>
					
				</tbody>

				
				
								<tfoot>
					<tr>
						<td class="text-c w10">
							<input type="checkbox" class="allCheckBox checkBox">
							</input>
						</td>
						<td colspan="6">
							<div class="pull-left">
								<a class="btn btn-default" href="javascript:;" onclick="batch_print()">批量打印</a>
								<!-- 
							<a class="btn btn-danger m-l-5" href="javascript:;">批量删除</a>
							 -->
								<!--当没有选中任何所操作的项，按钮为禁用状态，将按钮样式btn-danger替换为disabled-->
							</div>
							<div id="pagination" class="pull-right page-box">
								
								
<div id="pagination">
	<script data-page-json="true" type="text">
	{"page_key":"page","page_id":"pagination","default_page_size":10,"cur_page":1,"page_size":10,"page_size_list":[10,50,500,1000],"record_count":4,"page_count":1,"offset":0,"url":null,"sql":null}
</script>
	
	
	<div class="pagination-info">
		共4条记录，每页显示：
		<select class="select m-r-5" data-page-size="10">
			
			
			<option value="10" selected="selected">10</option>
			
			
			
			<option value="50">50</option>
			
			
			
			<option value="500">500</option>
			
			
			
			<option value="1000">1000</option>
			
			
		</select>
		条
	</div>
	
	<ul class="pagination">
		<li class="disabled" style="display: none;">
			<a class="fa fa-angle-double-left" data-go-page="1" title="第一页"></a>
		</li>
		
		<li class="disabled">
			<a class="fa fa-angle-left" title="上一页"></a>
		</li>
		
		
		
		
		
		
		
		
		<!--   -->
		
		<li class="active">
			<a data-cur-page="1">1</a>
		</li>
		
		
		
		
		
		
		
		<li class="disabled">
			<a class="fa fa-angle-right" title="下一页"></a>
		</li>
		
		<li class="disabled" style="display: none;">
			<a class="fa fa-angle-double-right" data-go-page="1" title="最后一页"></a>
		</li>
	</ul>
	
	<div class="pagination-goto">
		<input class="ipt form-control goto-input" type="text">
		<button class="btn btn-default goto-button" title="点击跳转到指定页面">GO</button>
		<a class="goto-link" data-go-page="" style="display: none;"></a>
	</div>
	<script type="text/javascript">
		$().ready(function() {
			$(".pagination-goto > .goto-input").keyup(function(e) {
				$(".pagination-goto > .goto-link").attr("data-go-page", $(this).val());
				if (e.keyCode == 13) {
					$(".pagination-goto > .goto-link").click();
				}
			});
			$(".pagination-goto > .goto-button").click(function() {
				var page = $(".pagination-goto > .goto-link").attr("data-go-page");
				if ($.trim(page) == '') {
					return false;
				}
				$(".pagination-goto > .goto-link").attr("data-go-page", page);
				$(".pagination-goto > .goto-link").click();
				return false;
			});
		});
	</script>
	
</div>
							</div>
						</td>
					</tr>
				</tfoot>
			</table>

			
		</div>
	</div>
</div>

<script type="text/javascript">
	var tablelist = null;
	$().ready(function() {

		tablelist = $("#table_list").tablelist({
			params: $("#searchForm").serializeJson(),
		});

		$("#searchForm").submit(function() {
			// 序列化表单为JSON对象
			var data = $(this).serializeJson();
			// console.info(data);
			// Ajax加载数据
			tablelist.load(data);
			// 阻止表单提交
			return false;
		});

		$("#btn_export").click(function() {
			var url = "/trade/delivery/export.html";
			url += "?keywords_type=" + $("#keywords_type").val();
			url += "&keywords=" + $("#keywords").val();
			url += "&delivery_status=" + $("#delivery_status").val();
			url += "&add_time_begin=" + $("#add_time_begin").val();
			url += "&add_time_end=" + $("#add_time_end").val();
			url += "&send_time_begin=" + $("#send_time_begin").val();
			url += "&send_time_end=" + $("#send_time_end").val();

			if (tablelist.sortname != null && tablelist.sortorder != null) {
				url += "&sortname=" + tablelist.sortname;
				url += "&sortorder=" + tablelist.sortorder;
			}

			$.go(url, null, false);
		});

		$("body").on("click", ".edit-order", function() {
			var type = $(this).data("type");
			var id = $(this).data("id");

			if (type == 'delivery') {
				title = "修改运单";
				width = 480;
			}

			if ($.modal($(this))) {
				$.modal($(this)).show();
			} else {
				$.modal({
					// 标题  
					title: title,
					width: width,
					trigger: $(this),
					// ajax加载的设置  
					ajax: {
						url: '/trade/delivery/edit-order?from=list',
						data: {
							type: type,
							id: id
						}
					},
				});
			}

		});
	});

	$("body").on("click", ".print-sheet", function() {
		var delivery_id = $(this).data("id");
		var shipping_code = $(this).data("code");
		$.loading.start();
		$.ajax({
			type: 'GET',
			url: '/trade/delivery/check-print.html',
			data: {
				delivery_id: delivery_id,
				shipping_code: shipping_code
			},
			dataType: 'json',
			success: function(result) {
				if (result.code == 0) {
					$.go('/trade/delivery/print-sheet.html?did=' + delivery_id + '&code=' + shipping_code, '_blank');
				} else {
					$.msg(result.message, {
						time: 5000
					});
				}
			}
		}).always(function() {
			$.loading.stop();
		});
	});

	function batch_print() {
		var delivery_ids = document.getElementsByName("delivery_id_box");
		var delivery_id = "";

		for (var i = 0; i < delivery_ids.length; i++) {
			if (delivery_ids[i].checked == true) {
				delivery_id += delivery_ids[i].value + ",";
			}
		}

		delivery_id = delivery_id.slice(0, -1);

		if (delivery_id.length <= 0) {
			$.msg("请勾选待打印发货单！");
			return false;
		}

		$.go('/trade/order/print.html?did=' + delivery_id, '_blank');
	}
</script>

<script type='text/javascript'>
	$('.form_datetime').datetimepicker({
		language: 'zh-CN',
		weekStart: 1,
		todayBtn: 1,
		autoclose: 1,
		todayHighlight: 1,
		startView: 2,
		minView: 2, // 精确度：默认为时分秒，2：年月日
		forceParse: 0,
		showMeridian: 1,
		format: 'yyyy-mm-dd',
	});
</script>
					
				</div>
			</div>
		</div>
		<!--底部内容-->
		@include('common.footer')

</body>

<script type="text/javascript">
function toFirst(target){
	var url = $(target).parents("li").find(".sub-list").find("li:first").find("a").attr("href");
	$.go(url);
}
function to(url, target){
	
}

function clearCache(){
	// 缓载
	$.loading.start();
	$.post("/site/clear-cache", {}, function(result){
		if(result.code == 0){
			$.msg(result.message);
		}else{
			$.msg(result.message, {
				time: 5000
			});
		}
	}).always(function(){
		$.loading.stop();
	});
}
// 登录成功关闭弹出框
$.login.success = function(){
	// 关闭并销毁登录窗口
	$.login.close(true);
}
</script>

<script type="text/javascript">
	// setInterval("auto_print()",10000);
	function auto_print(order_id)
	{
		$.ajax({
			type: "GET",
			url: "/site/auto-print",
			dataType: "json",
			data: {
				order_id: order_id
			},
			success: function(result) {
				if(result.code == 0)
				{
					lodop_print_html(result.print_title, result.data,result.printer);
				}
			}
		});
	}
</script>

<!-- 加载消息监听js-->
<script src="/assets/d2eace91/js/message/message.js?v=20180027"></script>
<script src="/assets/d2eace91/js/message/messageWS.js?v=20180027"></script>
<script type="text/javascript">
//声音监听
WS_AddUser({
	'user_id': 'shop_1717',
	'url': "ws://push.yunmall.68mall.com:7272",
	'type': "add_user"
}); 
//右下角消息提醒弹窗js
function open_message_box(data) {
	if (!data) {    
		data = {};
    }
	
	var src = window.location.href;
	
	// 如果当前框架中的链接地址和弹框的链接地址一致则不弹框
	if(data.auto_refresh == 1 && data.link && src.indexOf(data.link) != -1){
		
		var contentWindow = window;
		
		if(contentWindow.tablelist){
			contentWindow.tablelist.load({
				page: {
					cur_page: 1
				}
			});
		}else{
			contentWindow.location.reload();
		}
		
		return;
	}
	
	$('.message-pop-box').find('#message-pop-text').html(data.content);
	
	if(data.link){
		$('.message-pop-box').find('.message-btn').attr('href', data.link).show();
	}else{
		$('.message-pop-box').find('.message-btn').hide();
	}
	
	if(data.content || data.link){
		$('.message-pop-box').removeClass('down').addClass('up');
	}
	
	try {
		if(refresh_order && typeof(refresh_order) == "function") { 
			refresh_order();
        } 
    } catch(e) {}
}
$('.message-pop-box .close').click(function() {
	$('.message-pop-box').removeClass('up').addClass('down');
});
//用户信息
$(".admin").mouseenter(function() {
	window.focus();
	$("#admin-panel").show();
}).mouseleave(function() {
	$("#admin-panel").hide();
});
</script>
<script type="text/javascript">
	var clipboard = new Clipboard('.btn-copy');
    clipboard.on('success', function(e) {
        $.msg('复制成功');
    });
    clipboard.on('error', function(e) {
    	$.msg('复制失败');
    });
 	// 更新后台主框架消息弹窗
	function update_message() {
		// 是否重新获取数据
		if ($("#message-panel").html().length > 0) {
			// if (parseInt($("#counts_all").val()) != 0) {
			var time_step = 5; // 最小刷新间隔，单位：秒
			var this_time = new Date();
			if ((parseInt($("#counts_time").val()) + parseInt(time_step)) > parseInt(this_time.getTime() / 1000)) {
				return true;
			}
			// }
		}
		$.ajax({
			type: 'GET',
			url: '/site/update-message.html',
			data: {},
			dataType: 'json',
			success: function(result) {
				if (result.code == 0) {
					$("#message-panel").html(result.data);
				} else if (result.code == 1) {
				} else {
					$.msg(result.message);
				}
			}
		});
	}
	// 消息通知
	$("#message-box").mouseenter(function() {
		update_message();
		window.focus();
		$("#message-panel").show();
	}).mouseleave(function() {
		$("#message-panel").hide();
	}).find(".close").click(function() {
		$("#message-panel").hide();
	});
</script>

</html>

