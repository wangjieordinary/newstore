<div class="header-top">
	<div class="header-box">
		<!-- 站点 -->
		<!--站点 start-->
		<div class="SZY-SUBSITE">
		</div>
		<!--站点 end-->
		<!-- 登录信息 -->
		@if($userinfo == null)
		<font id="login-info" class="login-info SZY-USER-NOT-LOGIN">
			<!--<em>欢迎来到翼商城-测试站点! </em>-->
			<a class="login color" href="/login" target="_top">请登录</a>
			<a class="register" href="/register" target="_top">免费注册</a>
		</font>
		@else
		<font id="login-info" class="login-info">
			<em>
				<a href="/user" target="_blank" class="color SZY-USER-NAME">{{$userinfo->telephone}}</a>
				<!--欢迎您回来!-->
			</em>
			<a href="/logout" data-method="post">退出</a>
		</font>
		@endif
		<ul>
			<li>
				<a class="menu-hd home" href="#" target="_top">
					<i class="iconfont color">&#xe6a3;</i>
					商城首页
				</a>
			</li>
			<li class="menu-item">
				<div class="menu">
					<a class="menu-hd myinfo" href="#" target="_blank">
						<i class="iconfont color">&#xe6a5;</i>
						我的商城
						<b></b>
					</a>
					<div id="menu-2" class="menu-bd">
						<span class="menu-bd-mask"></span>
						<div class="menu-bd-panel">
							<a href="/user/order.html" target="_blank">已买到的宝贝</a>
							<a href="/user/address.html" target="_blank">我的地址管理</a>
							<a href="/user/collect/goods.html" target="_blank">我收藏的宝贝</a>
							<a href="/user/collect/shop.html" target="_blank">我收藏的店铺</a>
						</div>
					</div>
				</div>
			</li>
			<li class="menu-item cartbox">
				<div class="menu">
					<a class="menu-hd cart" href="/cart.html" target="_top">
						<i class="iconfont color">&#xe6a8;</i>
						购物车
						<span class="SZY-CART-COUNT">0</span>
						<b></b>
					</a>
					<div id="menu-4" class="menu-bd cart-box-main">
						<span class="menu-bd-mask"></span>
						<div class="dropdown-layer">
							<div class="spacer"></div>
							<div class="dropdown-layer-con cartbox-goods-list">
								
								
<!-- 正在加载 -->
<div class="cart-type">
	<i class="cart-type-icon"></i>
</div>

								
							</div>
						</div>
					</div>
				</div>
			</li>
			<li>
				<a class="menu-hd" href="/store" target="_blank">卖家中心</a>
			</li>
			
			<li class="menu-item">
				<div class="menu">
					<a class="menu-hd we-chat" href="javascript:;" target="_top">
						<i class="iconfont color">&#xe6a4;</i>
						关注商城
						<b></b>
					</a>
					<div id="menu-5" class="menu-bd we-chat-qrcode">
						<span class="menu-bd-mask"></span>
						<a target="_top">
							<img src="/static/storeindex/images/mall_wx_qrcode_0.png" alt="官方微信" />
						</a>
						<p class="font-14">关注官方微信</p>
					</div>
				</div>
			</li>
			
			
			<li class="menu-item">
				<div class="menu">
					<a class="menu-hd mobile" href="javascript:;" target="_top">
						<i class="iconfont color">&#xe60b;</i>
						手机版
						<b></b>
					</a>
					<div id="menu-6" class="menu-bd qrcode">
						<span class="menu-bd-mask"></span>
						<a target="_top">
							<img src="/static/storeindex/images/app_download_qrcode.png" alt="手机客户端" />
						</a>
						<p>手机客户端</p>
					</div>
				</div>
			</li>
			
			
			<li class="menu-item">
				<div class="menu">
					<a href="javascript:;" class="menu-hd site-nav">
						商家支持
						<b></b>
					</a>
					<div id="menu-7" class="menu-bd site-nav-main">
						<span class="menu-bd-mask"></span>
						<div class="menu-bd-panel">
							<div class="site-nav-con">
								
								<a href="#" target="_blank"  title="新手帮助">新手帮助</a>
								
								<a href="#" target="_blank"  title="入驻说明">入驻说明</a>
								
							</div>
						</div>
					</div>
				</div>
			</li>
			
		</ul>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function() {
		$(".SZY-SEARCH-BOX-TOP .SZY-SEARCH-BOX-SUBMIT-TOP").click(function() {
			if ($(".search-li-top.curr").attr('num') == 0) {
				var keyword_obj = $(this).parents(".SZY-SEARCH-BOX-TOP").find(".SZY-SEARCH-BOX-KEYWORD");

				var keywords = $(keyword_obj).val();
				if ($.trim(keywords).length == 0 || $.trim(keywords) == "请输入关键词") {
					keywords = $(keyword_obj).data("searchwords");
				}
				$(keyword_obj).val(keywords);
			}
			$(this).parents(".SZY-SEARCH-BOX-TOP").find(".SZY-SEARCH-BOX-FORM").submit();
		});
	});
</script>


<div class="header">
	<div class="w1210 clearfix">
		<div class="logo-info">
			<a href="http://www.68dsw.com" class="logo">
				
				<img src="/static/storeindex/images/storelogo.png" />
				
			</a>
		</div>
		<div class="shop-info">
			<div class="shop">
				<div class="shop-name ">
					<a href="{{url('storeindex',$storeinfo->id)}}" title="{{$storeinfo->store_name}}">{{$storeinfo->store_name}}</a>
				</div>
				
				<p>
					<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/system/credit/2016/12/26/14827402454984.gif" title="二星" />
				</p>
				

			</div>
			<div class="shop-main">
				
				<div class="shop-score-box">
					<div class="shop-score-item">
						<div class="shop-score-title">描 述</div>
						<div class="score color">
							<span>4.00</span>
						</div>
					</div>
					<div class="shop-score-item">
						<div class="shop-score-title">服 务</div>
						<div class="score color">
							<span>5.00</span>
						</div>
					</div>
					<div class="shop-score-item">
						<div class="shop-score-title">发 货</div>
						<div class="score color">
							<span>5.00</span>
						</div>
					</div>
				</div>
			</div>
			<a class="slogo-triangle">
				<i class="icon-triangle"></i>
			</a>
			<div class="extra-info">
				<div class="hd">
					<p class="shop-collect">
						<a href="{{url('storeindex',$storeinfo->id)}}" title="{{$storeinfo->store_name}}" class="shop-logo">
							<img src="{{$storeinfo->storelogo}}">
						</a>
						<a href="javascript:void(0);" onClick="toggleShop({{$storeinfo->id}},this)" class="collect-btn bg-color">收藏本店</a>
					</p>
					<p class="collect-count" style="display: none;">
						<em id="collect-count">0</em>
					</p>
					<p class="collect-tip" style="display: none;">收藏</p>
					<!-- 店铺二维码 _start -->
					<p class="shop-qr-code">
						<img src="https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=gQEu8DwAAAAAAAAAAS5odHRwOi8vd2VpeGluLnFxLmNvbS9xLzAyenNlM1JFektkZTAxMDAwMGcwM24AAgQ0agFZAwQAAAAA" alt="店铺二维码" />
					</p>
					<!-- 店铺二维码 end -->
				</div>
				<div class="bd">
					
					<div class="shop-rate">
						<h4>店铺动态评分</h4>
						<ul>
							<li>
								描述相符：
								<a target="_blank" href="javascript:void(0);">
									<em class="count color" title="">4.00</em>
								</a>
							</li>
							<li>
								服务态度：
								<a target="_blank" href="javascript:void(0);">
									<em class="count color" title="">5.00</em>
								</a>
							</li>
							<li>
								发货速度：
								<a target="_blank" href="javascript:void(0);">
									<em class="count color" title="">5.00</em>
								</a>
							</li>
						</ul>
					</div>
					
					<div class="extend ">
						<h4 class="extend-title">店铺服务</h4>
						<ul>
							<li>
								<label>店铺掌柜：</label>
								<div class="extend-right">
									<a href="{{url('storeindex',$storeinfo->id)}}" class="color">{{$storeinfo->telephone}}</a>
								</div>
							</li>
							
							
							<li>
								<label>开店时长：</label>
								<div class="extend-right">
									<span class="duration-time">1年</span>
								</div>
							</li>
							
							<li class="locus">
								<label>所在地：</label>
								<div class="extend-right">
									<span>上海市 上海市 嘉定区江桥镇曹安公路2038号华拓大厦</span>
								</div>
							</li>

							
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- 
		<div class="mobile-shop">
			<div class="mobile-qr-code">
				<span>手机逛</span>
				<i class="qr-code"></i>
			</div>
			<a href="javascript:void(0);" class="arrow">
				<i class="down-up"></i>
			</a>
			<div class="mobile-qr-code-box">
				<img width="140" height="140" src="" />
				<p>扫一扫，手机逛起来</p>
			</div>
		</div>
		 -->
		<div class="search">
			<form class="search-form" method="get" name="" id="search-form" action="{{url('search',$shop_id)}}" onSubmit="">
				<!-- <input type='hidden' name='type' id="searchtype" value=""> -->
				<div class="search-info">
					<div class="search-box">
						<div class="search-box-con">
							<input class="search-box-input" name="keyword" id="keyword" tabindex="9" autocomplete="off" value="" onFocus="if( this.value=='请输入关键词'){ this.value=''; }else{ this.value=this.value; }" onBlur="if(this.value=='')this.value='请输入关键词'" type="text">
						</div>
					</div>
					<input type="button" onclick="search_all()" value="搜全站" class="button bg-color">
				</div>
				<input type="button" onclick="search_me()" value="搜本店" class="button button-spe">
			</form>
			<ul class="hot-query">
				<!-- 默认搜索词 -->
				
				<li class="first">
					<a href="/search.html?keyword=连衣裙" title="连衣裙">连衣裙</a>
				</li>
				
				<li >
					<a href="/search.html?keyword=电脑" title="电脑">电脑</a>
				</li>
				
				<li >
					<a href="/search.html?keyword=女装" title="女装">女装</a>
				</li>
				
				<li >
					<a href="/search.html?keyword=户外" title="户外">户外</a>
				</li>
				
				<li >
					<a href="/search.html?keyword=智能" title="智能">智能</a>
				</li>
				
				<li >
					<a href="/search.html?keyword=大家电" title="大家电">大家电</a>
				</li>
				
			</ul>
		</div>
	</div>
</div>
<!-- 右侧客服 _start-->
<div class="customer-service-box">
	<div class="box-content">
		<div class="box-small">

			
			<div class="phone-service">
				<span class="service-phone">
					<a class="phone" href="javascript:;"></a>
				</span>
				<span class="phone-text">电话</span>
			</div>
			
		</div>
		<div class="box-large">
			<ul>
				<li class="service-item">
					<a href="" rel="nofollow" class="color">{{$storeinfo->store_name}}</a>
					<span class="ww-light">
						<!-- 旺旺不在线 i 标签的 class="ww-offline" -->
						
					</span>
				</li>
				
				
				
				<li class="service-item">
					<h4>联系方式</h4>
					<ul class="service-info">
						<li>
							<span>联系电话：2342342</span>
						</li>
					</ul>
				</li>
				

			</ul>
		</div>
	</div>
</div>
<!-- 右侧客服_end -->

<div class="layout">
	
	<div class="shop-menu">
		<div class="shop-menu-box">
			<ul class="shop-menu-left">
				<li>
					<a href="{{url('storeindex',$shop_id)}}" target="">首页</a>
				</li>
				<li class="all-category">
					<a href="{{url('storeindex/list',$shop_id)}}" target="">
						全部分类
						<span class="arrow"></span>
					</a>
					<div class="all-category-coupon">

						<!-- 获取店铺内商品分类 -->
						<dl>
							<dt>
								<a href="{{url('goods/list',$shop_id)}}" target="_blank">全部商品 ></a>
							</dt>
							<dd>
								<ul>
									
									
								</ul>
							</dd>
						</dl>

						@foreach ($category as $category)
						<dl>
							<dt>
								<a href="{{url('/goods/list/')}}?shop_id={{$shop_id}}&cate_id={{$category->id}}" target="_blank">{{$category->cate_name}} ></a>
							</dt>
							<dd>
								<ul>
									
									@foreach ($category->children as $children)
									<li>
										<a href="{{url('/goods/list/')}}?shop_id={{$shop_id}}&cate_id={{$category->id}}" target="_blank">{{$children->cate_name}}</a>
									</li>
									@endforeach
								</ul>
							</dd>
						</dl>
						@endforeach
						
						
						
											</div>
				</li>
				<!-- 获取店铺导航 -->
			</ul>
			<ul class="shop-menu-right">
				<li class="shop-nav">
					
					<a href="/shop/309/list?cat_id=296"  target="_blank">肉干肉脯</a>
					
				</li>
				
				<li class="shop-nav">
					
					<a href="/shop/309/list?cat_id=302"  target="_blank">葡萄干</a>
					
				</li>
				
				<li class="shop-nav">
					
					<a href="/shop/309/list?cat_id=293"  target="_blank">开心果</a>
					
				</li>
				
				<li class="shop-nav">
					
					<a href="/shop/309/list?cat_id=292"  target="_blank">松子</a>
					
				</li>
				
				<li class="shop-nav">
					
					<a href="/shop/309/list?cat_id=291"  target="_blank">巴旦木</a>
					
				</li>
				
				<li class="shop-nav">
					
					<a href="/shop/309/list?cat_id=290"  target="_blank">夏威夷果</a>
					
				</li>
				
			</ul>
		</div>
	</div>
</div>
<script type='text/javascript'>
	function search_all() {
		
		document.getElementById('search-form').action = "{{url('search')}}";
		document.getElementById("search-form").submit();
	}
	function search_me() {
		
		document.getElementById('search-form').action = "{{url('storeindex/search',$shop_id)}}";
		document.getElementById("search-form").submit();
	}

	function toggleShop(shop_id, obj) {
		$.collect.toggleShop(shop_id, function(result) {
			if (result.code == 0) {
				$(".collect-count").html(result.collect_count);
				$(obj).parent().toggleClass("fav-shop-box-select");
				if ($(obj).html() == "收藏本店") {
					$(obj).html("取消收藏");
					$(".collect-tip").html("已收藏");
				} else {
					$(obj).html("收藏本店");
					$(".collect-tip").html("收藏");
				}
				
				if(result.show_collect_count == 1 && result.collect_count > 0){
					$(".collect-tip").show();
					$(".collect-count").show();
				}else{
					$(".collect-tip").hide();
					$(".collect-count").hide();
				}
			}
		}, true);
	}
</script>
<script type="text/javascript">
	$().ready(function() {
		$.ajax({
			url: '/shop/index/info?shop_id={{$shop_id}}',
			dataType: 'json',
			success: function(result) {
				var is_collect = result.data.is_collect;
				var collect_count = result.data.collect_count;
				var duration_time = result.data.duration_time;
				if (is_collect == false) {
					$(".collect-btn").html("收藏本店");
					$(".collect-tip").html("收藏");
				} else {
					$(".collect-btn").html("取消收藏");
					$(".collect-tip").html("已收藏");
				}
				
				$('.duration-time').html(duration_time);
				$(".collect-count").html(collect_count);
				
				if(result.data.show_collect_count == 1 && collect_count > 0){
					$(".collect-tip").show();
					$(".collect-count").show();
				}else{
					$(".collect-tip").hide();
					$(".collect-count").hide();
				}
			}
		});
			
		//加入购物车
		$('body').on('click', '.add-cart', function(event) {
			var goods_id = $(this).data('goods_id');
			var image_url = $(this).data('image_url');
			var buy_enable = $(this).data("buy-enable");
			if(buy_enable){
				$.msg(buy_enable);
				return false;
			}
			$.cart.add(goods_id, 1, {
				is_sku: false,
				image_url: image_url,
				event: event,
				callback: function() {
					var attr_list = $('.attr-list').height();
					$('.attr-list').css({
						"overflow": "hidden"
					});
					if (attr_list >= 200) {
						$('.attr-list').addClass("attr-list-border");
						$('.attr-list').css({
							"overflow-y": "auto"
						});
					}
				}
			});
			return false;
		});
	});
</script>