<!DOCTYPE html>
<!--[if IE 8]> <html lang="zh-CN" class="ie8"> <![endif]-->
<html lang="zh-CN">
@include('storeindex.common.link')
<body>
<!-- 引入头部文件 -->
<!-- 引入头部文件 -->
<script src="/static/storeindex/js/index.js?v=20180027"></script>
<script src="/static/storeindex/js/tabs.js?v=20180027"></script>
<script src="/static/storeindex/js/bubbleup.js?v=20180027"></script>
<script src="/static/storeindex/js/jquery.hiSlider.js?v=20180027"></script>
<script src="/static/storeindex/js/index_tab.js?v=20180027"></script>
<script src="/static/storeindex/js/jump.js?v=20180027"></script>
<script src="/static/storeindex/js/nav.js?v=20180027"></script>
<!-- 站点选择 -->
 @include('storeindex.common.header')

    <div class="layout"  style="min-height:400px;">
	<!-- 内容 -->
	<!--模块内容-->
<!-- #tpl_region_start -->
	<!--  店铺首页轮播广告模板  -->
	<!-- banner高度 -->
	
	
	
	
	
	<!-- banner模块 _start -->
	<div class="banner"  style='height: 400px;'>
		
		
		<ul id="fullScreenSlides" class="full-screen-slides"  style='height: 400px;'>
		
		 <li  style="display:list-item;" > 
            <a href="#" target="_blank" title="" style="background:url(http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/gallery/2017/05/03/14937939889595.jpg) no-repeat center center; background-size: auto 100%; height:400px;"></a>
          </li>
			
		</ul>

		<ul class="full-screen-slides-pagination">
		
			<li class="current">
				<a href="javascript:void(0);">0</a>
			</li>
			
		</ul>
		
	</div>
	<!-- banner模块 _end -->

	


	<!-- 默认缓载图片 -->
	<!-- 内容开始 -->
	<div class=" custom-box">
        <div class="custom">
            

            
                
                	
                    <div style="text-align:center;">
	<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/images/2017/05/04/14938841418142.png" width="1500" height="1572" alt="图片1" usemap="#map"/>
<map name="Map" id="Map">
    <area shape="rect" coords="7,3,1304,403" href="http://www.68dsw.com/goods-39720.html" target="_blank" />
    <area shape="rect" coords="12,421,1299,788" href="http://www.68dsw.com/goods-39730.html" target="_blank" />
    <area shape="rect" coords="12,800,1287,1187" href="http://www.68dsw.com/" target="_blank" />
    <area shape="rect" coords="11,1196,1290,1551" href="http://www.68dsw.com/" target="_blank" />
  </map>
</div>
                    
                
        	
        </div>
    </div>
	<!-- 内容结束 -->
	

	<!-- 默认缓载图片 -->
	<!-- 内容开始 -->
	<div class=" custom-box">
        <div class="custom">
            

            
                
                	
                    <div style="text-align:center;">
	<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/images/2017/05/04/14938824975667.jpg" width="1500" height="169" alt="图片2"  usemap="#Map2" />
<map name="Map2" id="Map2">
  <area shape="rect" coords="95,7,1327,152" href="http://www.68dsw.com/shop/309/list?cat_id=296" target="_blank" />
</map>
</div>
                    
                
        	
        </div>
    </div>
	<!-- 内容结束 -->
	

	<!-- 默认缓载图片 -->
	<!-- 内容开始 -->
	<div class=" custom-box">
        <div class="custom">
            

            
                
                	
                    <div style="text-align:center;">
	<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/shop/309/images/2017/05/04/14938864193254.png" width="1500" height="1969" alt="图片3" usemap="#Map3" /> 
	<map name="Map3" id="#Map3">
		<area shape="rect" coords="252,23,1238,431" href="http://www.68dsw.com/goods-39729.html" target="_blank" />
  <area shape="rect" coords="251,452,742,989" href="http://www.68dsw.com/goods-39724.html" target="_blank" />
  <area shape="rect" coords="755,454,1239,990" href="http://www.68dsw.com/goods-39710.html" target="_blank" />
  <area shape="rect" coords="1320,998,1321,999" href="#" />
  <area shape="rect" coords="251,1003,1240,1413" href="http://sh.68dsw.com/" target="_blank" />
  <area shape="rect" coords="255,1427,742,1956" href="http://sh.68dsw.com/" target="_blank" />
  <area shape="rect" coords="752,1427,1247,1959" href="http://sh.68dsw.com/" target="_blank" />
	</map>
</div>
                    
                
        	
        </div>
    </div>
	<!-- 内容结束 -->
	

	<!-- #tpl_region_end -->
<!-- 左侧楼层定位 _start-->
	<div class="elevator">
		<div class="elevator-floor">
		</div>
	</div>  





    </div>
    
	<!--底部footer-->
	
<!-- 右侧边栏 _start -->
<div class="right-sidebar-con">
	<div class="right-sidebar-main">
		<div class="right-sidebar-panel">
			<div id="quick-links" class="quick-links">
				<ul>
					<li class="quick-area quick-login sidebar-user-trigger">
						<!-- 用户 -->
						<a href="javascript:void(0);" class="quick-links-a">
	<i class="iconfont">&#xe6cc;</i>
</a>
<div class="sidebar-user quick-sidebar">
	<i class="arrow-right"></i>
	<div class="sidebar-user-info">
		<!-- 没有登录的情况 _start -->
		<div class="SZY-USER-NOT-LOGIN" style="display: none;">
			<div class="user-pic">
				<div class="user-pic-mask"></div>
				<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/system/config/default_image/default_user_portrait_0.png" />
			</div>
			<br />
			<p>
				你好！请
				<a href="javascript:void(0);" class="quick-login-a color ajax-login">登录</a>
				|
				<a href="http://www.68dsw.com/register.html" class="color">注册</a>
			</p>
		</div>
		<!-- 没有登录的情况 _end -->
		<!-- 有登录的情况 _start -->
		<div class="SZY-USER-ALREADY-LOGIN" style="display: none;">
			<div class="user-have-login">
				<div class="user-pic">
					<div class="user-pic-mask"></div>
					<img src="" class="SZY-USER-PIC" />
				</div>
				<div class="user-info">
					<p>
						用&nbsp;&nbsp;&nbsp;户：
						<span class="SZY-USER-NAME"></span>
					</p>
					<p class="SZY-USER-RANK" style="display: none;">
						等&nbsp;&nbsp;&nbsp;级：
						<img class="SZY-USER-RANK-IMG" />
						<span class="SZY-USER-RANK-NAME"></span>
					</p>
				</div>
			</div>
			<p class="m-t-10">
				<span class="prev-login">
					上次登录时间：
					<span class="SZY-USER-LAST-LOGIN"></span>
				</span>
				<a href="http://www.68dsw.com/user.html" class="btn account-btn" target="_blank">个人中心</a>
				<a href="http://www.68dsw.com/user/order.html" class="btn order-btn" target="_blank">订单中心</a>
			</p>
		</div>
		<!-- 有登录的情况 _end -->
	</div>
</div>
					</li>
					<li class="sidebar-tabs">
						<!-- 购物车 -->
						<div class="cart-list quick-links-a sidebar-cartbox-trigger">
							<i class="iconfont">&#xe6c5;</i>
							<div class="span">购物车</div>
							<span class="ECS_CARTINFO">
								<span class="cart_num SZY-CART-COUNT">0</span>
								<div class="sidebar-cart-box">
									<h3 class="sidebar-panel-header">
										<a href="javascript:void(0);" class="title">
											<i class="cart-icon"></i>
											<em class="title">购物车</em>
										</a>
										<span class="close-panel"></span>
									</h3>
								</div>
							</span>
						</div>
					</li>
					<li class="sidebar-tabs">
						<a href="javascript:void(0);" class="mpbtn_history quick-links-a sidebar-historybox-trigger">
							<i class="iconfont">&#xe76a;</i>
						</a>
						<div class="popup">
							<font id="mpbtn_histroy">我看过的</font>
							<i class="arrow-right"></i>
						</div>
					</li>
					<!-- 如果当前页面有对比功能 则显示对比按钮 _start-->
					<li class="sidebar-tabs">
						<a href="javascript:void(0);" class="mpbtn-contrast quick-links-a sidebar-comparebox-trigger">
							<i class="iconfont">&#xe8f8;</i>
						</a>
						<div class="popup">
							对比商品
							<i class="arrow-right"></i>
						</div>
					</li>
					<!-- 如果当前页面有对比功能 则显示对比按钮 _end-->
					<li>
						<a href="http://www.68dsw.com/user/collect/shop.html" target="_blank" class="mpbtn_stores quick-links-a">
							<i class="iconfont">&#xe6c8;</i>
						</a>
						<div class="popup">
							我收藏的店铺
							<i class="arrow-right"></i>
						</div>
					</li>
					<li id="collectGoods">
						<a href="http://www.68dsw.com/user/collect/goods.html" target="_blank" class="mpbtn_collect quick-links-a">
							<i class="iconfont">&#xe6b3;</i>
						</a>
						<div class="popup">
							我的收藏
							<i class="arrow-right"></i>
						</div>
					</li>
				</ul>
			</div>
			<div class="quick-toggle">
				<ul>
					
					<li class="quick-area">
						<a class="quick-links-a" href="javascript:void(0);">
							<i class="iconfont">&#xe6ad;</i>
						</a>
						<div class="sidebar-service quick-sidebar">
							<i class="arrow-right"></i>
							
							<div class="customer-service">
								<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=3152659060&site=qq&menu=yes">
									<i class="iconfont color">&#xe6cd;</i>
									QQ
								</a>
							</div>
							
							
							
							<div class="customer-service">
								<a href="javascript:void(0);" class="service-online">
									<i class="iconfont color">&#xe6ad;</i>
									在线客服
								</a>
							</div>
							
						</div>
					</li>
					
					
					<li class="quick-area">
						<a class="quick-links-a" href="javascript:void(0);">
							<i class="iconfont qr-code">&#xe6bc;</i>
						</a>
						<div class="sidebar-code quick-sidebar">
							<i class="arrow-right"></i>
							<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/system/config/mall/mall_wx_qrcode_0.png" />
						</div>
					</li>
					
					<li class="returnTop">
						<a href="javascript:void(0);" class="return_top quick-links-a">
							<i class="iconfont">&#xe6cb;</i>
						</a>
						<div class="popup">
							返回顶部
							<i class="arrow-right"></i>
						</div>
					</li>
				</ul>
			</div>
		</div>
		<div class="">
			<!--红包 start-->
			<!--红包 end-->
			<!--购物车 start-->
			
<div class="right-sidebar-panels sidebar-cartbox">
	<div class="sidebar-cart-box">
		<h3 class="sidebar-panel-header">
			<a href="javascript:void(0);" class="title" target="_blank">
				<i class="cart-icon"></i>
				<em class="title">购物车</em>
			</a>
			<span class="close-panel"></span>
		</h3>
		<div class="sidebar-cartbox-goods-list">
			
			<div class="cart-panel-main">
				<div class="cart-panel-content">
					
					<!-- 没有商品的展示形式 _start -->
					<div class="tip-box">
						<img src="/static/storeindex/images/noresult.png" class="tip-icon" />
						<div class="tip-text">
							您的购物车里什么都没有哦
							<br />
							<a class="color" href="http://www.68dsw.com" title="再去看看吧" target="_blank">再去看看吧</a>
						</div>
					</div>
					<!-- 没有商品的展示形式 _end-->
					
				</div>
			</div>
			
			
		</div>
	</div>
</div>
			<!--购物车 end-->
			<!--浏览历史 start-->
			<!---->
<div class="right-sidebar-panels sidebar-historybox">
	<h3 class="sidebar-panel-header">
		<a href="javascript:;" class="title">
			<i></i>
			<em class="title">我的足迹</em>
		</a>
		<span class="close-panel"></span>
	</h3>
	<div class="sidebar-panel-main">
		<div class="sidebar-panel-content sidebar-historybox-goods-list">
			<!---->
			<!---->
			<!-- 没有浏览历史的展示形式 _start -->
			<div class="tip-box">
				<img src="/static/storeindex/images/noresult.png" class="tip-icon" />
				<div class="tip-text">
					您还没有在商城留下任何足迹哦
					<br />
					<a class="color" href="./">赶快去看看吧</a>
				</div>
			</div>
			<!-- 没有浏览历史的展示形式 _end-->
			<!---->
			<!---->
		</div>
	</div>
</div>
<!---->
			<!--浏览历史 end-->
			<!--对比列表 start-->
			
<!--对比列表 start-->
<div class="right-sidebar-panels sidebar-comparebox">
	<h3 class="sidebar-panel-header">
		<a href="javascript:void(0);" class="title">
			<i class="compare-icon"></i>
			<em class="title">宝贝对比</em>
		</a>
		<span class="close-panel"></span>
	</h3>
	<div>
		<div class="sidebar-panel-main sidebar-comparebox-goods-list">
			
			<div class="sidebar-panel-content compare-panel-content">
				
				<!-- 没有对比商品的展示形式 _start -->
				<div class="tip-box">
					<img src="/static/storeindex/images/noresult.png" class="tip-icon" />
					<div class="tip-text">
						您还没有选择任何的对比商品哦 
						<br />
						<a class="color" href="./">再去看看吧</a>
					</div>
				</div>
				<!-- 没有对比商品的展示形式 _end-->
				
			</div>
		</div>
		
		
	</div>
</div>
<!--对比列表 end-->

			<!--对比列表 end-->
		</div>
	</div>
</div>
<!-- 右侧边栏 _end -->

<!-- 底部 _start-->



<div class="site-footer">
	
	

	

	
	
	<div class="footer-service"><div align="center">
	<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/backend/1/images/2016/11/28/14803038465459.jpg" alt="" height="110" width="1210" /><br />
</div></div>
	
	
	<div class="footer-related">
		
		

		


		
		
		<div class="footer-article w1210">
			<dl class="col-article col-article-spe">
				<dt class="phone color">400-078-5269</dt>
				<dd class="email color">szy@68ecshop.com</dd>
				
				<dd class="customer">
					<span>联系我们</span>
					
					<a href="javascript:void(0);" class="service-online">
						<em class="icon-yw service-online"></em>
					</a>
					
					
					
					<a href="http://wpa.qq.com/msgrd?v=3&uin=3152659060&site=qq&menu=yes" target="_blank">
						<em class="icon-kfqq"></em>
					</a>
					
				</dd>
				
			</dl>
			<!---->
			<dl class="col-article col-article-first">
				<dt>新手上路</dt>
				
				<dd>
					
					<a rel="nofollow" href="/help/2.html" target="_blank">购物流程</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/3.html" target="_blank">订单查询</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/4.html" target="_blank">常见问题</a>
					
				</dd>
				<!-- -->
			</dl>
			<!---->
			<dl class="col-article col-article-first">
				<dt>支付方式</dt>
				
				<dd>
					
					<a rel="nofollow" href="/help/5.html" target="_blank">网上支付</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/87.html" target="_blank">货到付款</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/88.html" target="_blank">公司转账</a>
					
				</dd>
				<!-- -->
			</dl>
			<!---->
			<dl class="col-article col-article-first">
				<dt>配送服务</dt>
				
				<dd>
					
					<a rel="nofollow" href="/help/6.html" target="_blank">配送范围及收费标准</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/7.html" target="_blank">订单进度查询</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/8.html" target="_blank">验货与签收</a>
					
				</dd>
				<!-- -->
			</dl>
			<!---->
			<dl class="col-article col-article-first">
				<dt>售后服务</dt>
				
				<dd>
					
					<a rel="nofollow" href="/help/9.html" target="_blank">退换货政策</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/10.html" target="_blank">退换货流程</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/11.html" target="_blank">退款说明</a>
					
				</dd>
				<!-- -->
			</dl>
			<!---->
			<dl class="col-article col-article-first">
				<dt>商家合作</dt>
				
				<dd>
					
					<a rel="nofollow" href="/help/13.html" target="_blank">商家入驻</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="/help/89.html" target="_blank">商家规则</a>
					
				</dd>
				
				<dd>
					
					<a rel="nofollow" href="http://help.68mall.com/info/110.html" target="_blank">入驻流程</a>
					<!--   -->
				</dd>
				<!-- -->
			</dl>
			<!---->

			<div class="QR-code fr">
				
				
				<ul class="tabs">
					
					<li class="current">APP</li>
					<li >微信</li>
					
				</ul>
				<div class="code-content">
					
					<div class="code">
						<img src="/staic/storeindex/images/app_download_qrcode.png">
					</div>
					
					
					<div class="code hide">
						<img src="/staic/storeindex/images/mall_wx_qrcode_0.png">
					</div>
					
				</div>
				
				
			</div>
		</div>
		
		
		
		

		
		
		<div class="footer-info">
			<div class="info-text">
				<!-- 底部导航 -->
				<p class="nav-bottom">
					
					
					<a href="#" target="_blank">公司简介</a>
					
					
					<em>|</em>
					
					<a href="#" target="_blank">联系我们</a>
					
					
					<em>|</em>
					
					<a href="#" target="_blank">官网论坛</a>
					
					
					<em>|</em>
					
					<a href="#" target="_blank">代理合作</a>
					
					
					<em>|</em>
					
					<a href="#" target="_blank">帮助中心</a>
					
					
					<em>|</em>
					
					<a href="/shop/apply.html" target="_blank">商家入驻</a>
					
					
					<em>|</em>
					
					<a href="#" target="_blank">联系我们</a>
					
				</p>
				<p>
					Copyright  中国农民自由贸易网 版权所有
					<a href="http://www.miibeian.gov.cn/" target="_blank">冀ICP备07501206号-2</a>
				</p>
				<p class="company-info" style="display: none;">秦皇岛市海港区秦皇半岛二区51号楼3层东侧</p>
				<p class="qualified">
					
					<a href="#" target="_blank">
						<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/backend/1/images/2016/11/10/14787661020127.png" alt="" />
					</a>
					
					<a href="http://www.68mall.com" target="_blank">
						<img src="http://68dsw.oss-cn-beijing.aliyuncs.com/images/backend/1/images/2016/11/10/14787669819785.png" alt="" />
					</a>
					
				</p>
			</div>
			
			<div class="info-text"></div>
			
			<!--<span class="vol">
	<b>Powered by</b>
	<a style="color: #4FC0E8;" href="http://www.68mall.com" target="_blank">商之翼</a>
	· 翼商城
</span>-->
<div class="copyright">
	<p>
		<a href="#" target="_blank" class="copyright-logo">
			<img src="http://www.68dsw.com/images/power-by-logo.png" />
			提供技术支持
		</a>
	</p>
</div>

			
		</div>
		
	</div>
</div>
<!-- 底部 _end-->


	
</body>
<script src="/static/storeindex/js/shop_index.js?v=20180027"></script>
<script src="/static/storeindex/js/jquery.fly.min.js?v=20180027"></script>
<script src="/static/storeindex/js/szy.cart.js?v=20180027"></script>
<script type="text/javascript">
$().ready(function(){
	// 缓载图片
	$.imgloading.loading();
	//图片预加载
	document.onreadystatechange = function() {
		 if (document.readyState == "complete") {
				$.imgloading.setting({
					threshold: 1000
				});
				$.imgloading.loading();
		 }
	}
});
</script>
</html>