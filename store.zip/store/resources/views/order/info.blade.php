<!DOCTYPE html>
<!--[if IE 8]> <html lang="zh-CN" class="ie8"> <![endif]-->
<html lang="zh-CN">
@include('common.link')
<body class="style-seller">
	
	@include('common.header')
	
	<!--中间内容-->
	<div class="seller-center">
		<div class="wrapper">
			
			<!--左侧部分-->
			@include('order.slider')
			
			<!--右侧内容-->
			<div class="seller-rihgt">
				<div class="seller-page">
					<div class="seller-page-bg"></div>
					<!--在这里调用内容-->
					<script src="/static/js/pic/imgPreview.js?v=20180027"></script>
<link rel="stylesheet" href="/static/css/styles.css?v=20181020"/>
<div class="page">
	<div class="fixed-bar">
	<div class="item-title">
		<div class="subject">
			<h3>
				<span class="action">欢迎页 - 订单详情</span>
				<!--帮助教程-->
                <!--<a class="help-href" href="javascript:;" data-toggle="tooltip" data-placement="auto bottom" title="点击跳转到该模块教程页面"><i class="help-icon"></i></a>-->
                <!--- -->
			</h3>
			
			<h5>
				
								
								<span class="action-span">
					
										
					<a  href="{{url('store/order/list')}}" class="btn btn-warning click-loading">
						<i class="fa fa-reply"></i>
						返回订单列表
					</a>
				</span>
								<!-- <span class="action-span">
													
										
													<a id='btn_print' href="javascript:void(0);" class="btn btn-warning ">
														<i class="fa fa-print"></i>
														打印订单
													</a>
												</span> -->
				
			</h5>
			
					</div>
	</div>
</div>
 
	<!--步骤-->
	<div class="order-step">
		<!--完成步骤为dl添加current样式，完成操作内容后会显示完成时间-->
				<dl class="current step-first">
			<dt>下单时间</dt>
			<dd class="bg"></dd>
						<dd class="date" title="">{{$orderinfo->goodslist[0]->atime}}</dd>
					</dl>
				<dl class="@if($orderinfo->etime!==null) current @endif">
			<dt>完成时间</dt>
			<dd class="bg"></dd>
						<dd class="date" title="">{{$orderinfo->etime}}</dd>
					</dl>
		
	</div>

	
	<!--订单详情信息-->
	<div class="order-info m-b-10">
		<!--操作部分-->
		<!--下单时间等-->
		<div class="order-infor">
			<h3>商家：{{$storeinfo->store_name}}</h3>
			<div class="order-infor-center">
				<dl>
					<dt>
						<span>订单编号：</span>
					</dt>
					<dd>
						<span>{{$orderinfo->ddh}}</span>
					</dd>
				</dl>
								
								<dl>
					<dt>
						<span>下单时间：</span>
					</dt>
					<dd>
						<span>{{$orderinfo->goodslist[0]->atime}}</span>
					</dd>
				</dl>
								
								
								<!-- <dl>
													<dt>
														<span>关闭时间：</span>
													</dt>
													<dd>
														<span>2018-11-06 21:39:11</span>
													</dd>
												</dl> -->
								
				
			</div>
		</div>
		<!--订单信息-->
		<div class="order-details">
			<div class="title">订单信息</div>
			<div class="content">
				
				
				<dl>
					<!---->
					<dt>&nbsp;收&nbsp;货&nbsp;人：</dt>
					<dd>{{$orderinfo->sname}}，{{$orderinfo->ssj}}， {{$orderinfo->sadd}} </dd>
					<!---->
				</dl>
				
				
				<dl>
					<dt>支付方式：</dt>
					<dd>@if($orderinfo->zflx=='1')
						积分
					@elseif($orderinfo->zflx=='2')
						现金
					@elseif($orderinfo->zflx=='3')
						微信
					@elseif($orderinfo->zflx=='7')
						余额+积分
					@elseif($orderinfo->zflx=='8')
						微信+积分
					@endif </dd>
				</dl>
				
				
				
				<dl>
					<dt>配送时间：</dt>
					<dd>立即配送</dd>
				</dl>

				
				<dl>
					<dt>配送方式：</dt>
					<!---->
					<dd>普通快递（ 免邮 ）</dd>
					
				</dl>
				
				
				
				
			</div>
		</div>

		
		<!--其它信息-->
		<!-- <div class="order-details">
			<div class="title">其它信息</div>
			<div class="content">
				
				<dl>
					<dt>买家留言：</dt>
					<dd></dd>
				</dl>
			</div>
		</div> -->
		
	</div>
	<!--商品信息-->
	<div class="table-responsive deliver">
		<table class="table">

			<thead>
				<tr>
					<th class="w200">商品</th>
					
					<th class="w100">商品条码</th>
					<th class="w100">属性</th>
					
					
					<th class="w70">单价（元）</th>
					
					<th class="w50">数量</th>
					
					
					<th class="w50">库存</th>
					
					<th class="w60 text-c">状态</th>
					
					<th class="w50">服务</th>
					<th class="w70">优惠</th>
					
					
				</tr>
			</thead>
			<tbody>
				<!--订单内容-->

				@foreach($orderinfo->goodslist as $goodslist)
				<tr class="order-item">
					<td class="item">
						<div class="pic-info">
							<a href="#" class="goods-thumb" title="查看商品详情" target="_blank">
								<img src="{{$goodslist->pic1}}" alt="查看商品详情"></img>
							</a>
						</div>
						<div class="txt-info w200">
							<div class="desc m-b-5">
								<a class="goods-name" href="#" target="_blank" title="查看商品详情">
									
									
									  {{$goodslist->name}}
								</a>
								<!-- -->
								<!-- <a class="snap">【交易快照】</a> -->
								<div class="icon">
									
								</div>
							</div>
							
							
							
														<!-- <div class="goods-active crowdfund">
																						<a>拼团</a>
																<span class="c-red m-l-15">【拼团失败，交易取消】</span>
															</div> -->
							 							
														
														
														
														 
							
							
													</div>
					</td>
					
					<td>
						
						
						
					</td>
					<td class="order-type">
						<div class="ng-binding order-type-info">
														<span></span>
							
						</div>
					</td>
					
					
					<td class="price">¥{{$goodslist->dj}}元</td>
					
					<td class="num">{{$goodslist->sl}}</td>
					
					
					<td class="stock">{{$goodslist->kucun}}</td>
					
					<td class="state text-c">@if($orderinfo->zt=='1')
							未付款
						@elseif($orderinfo->zt=='2')
							已付款
						@endif</td>
					
					<td class="service">
												<span class="c-green">正常</span>
											</td>
					<td class="order-discount">
						
						
					</td>
					
					
				</tr>
				@endforeach
				
				<!-- 订单满赠 -->
							</tbody>
		</table>
	</div>
	
	<div class="messageBox tfoot-info">
		<div class="address-info text-r">
			
			<p class="m-b-5">
				<span>商品总金额：¥{{$orderinfo->jine}}元</span>
				<em class="operator">+</em>
				<span>运费：¥0.00元</span>
				
				<em class="operator">-</em>
				<span>店铺红包：¥0.00元</span>
				<em class="operator">-</em>
				<span>平台红包：¥0.00元</span>
				
				
				<em class="operator">-</em>
				<span>卖家优惠：¥0.00元</span>
				
				<em class="operator">=</em>
				<span>
					<strong>订单总金额：¥{{$orderinfo->jine}}元</strong>
				</span>
			</p>
			
			
		</div>
	</div>
	@if($orderinfo->zt=='3')
	<div class="tabmenu m-t-20" id="logistics">
		<ul class="tab">
			<li class="active">
				<a href="#texpress1" data-toggle="tab">发货单物流</a>
			</li>
		</ul>
	</div>
	<div class="tab-content">
		<div id="texpress1" class="order-info logistics tab-pane fade in active">
			<div class="order-details">
				<div class="content">					
					<dl>
						<dt>物流方式：</dt>
						<dd>第三方物流</dd>
					</dl>
					<dl>
						<dt>物流公司：</dt>
						<dd>{{$orderinfo->wlmc}}</dd>
					</dl>
					<!-- <dl>
						<dt>物流编号：</dt>
						<dd>{{$orderinfo->kddh}}</dd>
					</dl> -->
					<dl>
						<dt>运单号码：</dt>
						<dd>{{$orderinfo->kddh}}</dd>
					</dl>

					
					<!-- <dl>
						<dt>物流跟踪：</dt>
						<dd>
							<ul class="express-log m-t-0">
								
																<li>2016-09-10 10:14:35 快件被快递员15973729985取出，请等待快递员与您联系，电话15973729985。</li>
																<li>2016-09-10 12:22:33 快件被快递员13938490827取出，请等待快递员与您联系，电话13938490827。</li>
																<li>2016-10-21 13:40:37 快件被快递员15942606757取出，请等待快递员与您联系，电话15942606757。</li>
																<li>2016-11-19 11:19:27 快件被快递员15538864520取出，请等待快递员与您联系，电话15538864520。</li>
																<li>2016-12-20 08:26:17 快件已被BJ天鹅湾F格格货栈【自提柜】代收，如有问题请联系派件员</li>
																<li>2016-12-20 12:18:30 快件被快递员17310929459取出，请等待快递员与您联系，电话17310929459。</li>
								
								
							</ul>
						</dd>
					</dl> -->
					

					
					
				</div>
			</div>
		</div>
	</div>
	@endif


	</div>
<script> var map; </script>
<script type="text/javascript" src="http://webapi.amap.com/maps?v=1.3&key=1349c560b5698ca640a70ee63e005a71"></script>
<script type="text/javascript">
	$().ready(function() {
		$("body").on("click", ".edit-order", function() {
			var type = $(this).data("type");
			var id = $(this).data("id");
			var oid = null;
			var url = '/trade/order/edit-order';
			var shop_address_count = "1";
			
			var print = false;
			if(type == "take-print"){
				type = "take";
				print = true;
			}
			
			title = width = '';
			if (type == 'order') {
				title = "修改订单价格";
				width = 860;
			}
			else if (type == 'delivery') {
				if(shop_address_count == 0) {
					$.msg("请先前往交易设置->发/退货地址库维护发货地址，再进行发货！");
					return false;
				}
				title = "拆单发货";
				width = 840;
			}
			else if (type == 'delay') {
				title = "延长收货时间";
			}
			else if (type == 'close') {
				title = "关闭订单";
			}
			else if (type == 'assign') {
				title = "订单指派网点";
				width = 800;
			}
			else if (type == 'address') {
				title = "收货人信息";
				width = '720px';
				height = '430px';
				url = "/trade/delivery/edit-order";
				oid = id;
				id = '';
			}
			
			if(type == "take"){
				// 接单
				$.post("/trade/order/edit-order.html", {
					type: type,
					id: id
				}, function(result){
					if(result.code == 0){
						$.msg(result.message, {
							time: 1000
						}, function(){
							// 打印订单
							if(print){
								$.alert("是否立即打印订单！", {
									btn: ['去打印', '取消'],
									// 关闭刷新当前页面
									end: function(){
										$.go();
									}
								}, function(){
									$.go('/trade/order/print.html?id=' + id, "_blank");
								});
							}else{
								$.go();
							}
						});
					}else{
						$.msg(result.message, {
							time: 5000
						});
					}
					console.info(result);
				}, "JSON");
			}else{
				if ($.modal($(this))) {
					$.modal($(this)).show();
				} else {
					$.modal({
						// 标题  
						title: title,
						trigger: $(this),
						width: width,
						// ajax加载的设置  
						ajax: {
							url: url,
							data: {
								type: type,
								id: id,
								oid: oid,
								from: "order-info"
							}
						},
					});
				}
			}
		});
		
		// 审核
		$("body").on("click", ".audit", function() {
			var id = $(this).data("id");
			$.open({
				title: "审核取消订单申请",
				ajax: {
					url: '/trade/order/audit',
					data: {
						id: id
					}
				},
				width: "600px",
				btn: ['确定', '取消'],
				yes: function(index, container) {

					var data = $(container).serializeJson();
					var order_cancel = $("input[name='order_cancel']:checked").val();
					var refuse_reason = $("#refuse_reason").val().trim();
					if (order_cancel == "3") {
						$("#error").hide();
						$("#error2").hide();
						if (refuse_reason == "") {
							$("#error").show();
							return;
						} else if (refuse_reason.length > 200) {
							$("#error2").show();
							return;
						}
					}
					$.loading.start();
					$.post('/trade/order/audit', data, function(result) {
						$.loading.stop();
						if (result.code == 0) {
							parent.location.reload();
							layer.close(index);
							$.msg(result.message);
						} else {
							$.msg(result.message, {
								time: 5000
							})
						}
					}, "json");
				}
			});
		});

		// 核销
		$("body").on("click", ".revision", function() {
			var url = $(this).data('url');
			var order_id = $(this).data('order_id');
			$.confirm("确定核销此订单?", function() {
				$.loading.start();
				$.post(url, {
					order_id: order_id
				}, function(result) {
					if (result.code == 0) {
						$.msg(result.message);
						window.location.reload();
					} else {
						$.msg(result.message);
					}
				}, 'json');
			});
		});
		
	});
	
	function getReceived(order_id)
	{
		layer.confirm('请确认收到货款后，再点击收到货款！否则您可能钱货两空！',function(){
			$.post('/trade/order/edit-order', {
				id: order_id,
				type: 'received',
			}, function(result) {
				$.msg(result.message);

				if (result.code == 0) {
					$.go("/trade/order/info?id=" + '5025');
				}
			}, 'json');
		});
	}
	
	function assignCancel(order_id)
	{
		layer.confirm('确定要取消此派单吗？',function(){
			$.post('/trade/order/assign-cancel', {
				id: order_id,
			}, function(result) {
				$.msg(result.message);

				if (result.code == 0) {
					$.go("/trade/order/info?id=" + '5025');
				}
			}, 'json');
		});
	}
	
	$("#btn_print").click(function(){
		var order_id = "5025";
		$.go('/trade/order/print.html?id=' + order_id, '_blank');
	});
	
	// 发货单tab切换事件
	$('#logistics').find('.tab').on('click', 'li', function() {
		var that = $(this);
		// 当前的索引值 从1 开始
		var idx = (that.index()) + 1;
		// 获取当前map 区域
		var $obj = $('#texpress' + idx).find('.express-log').nextAll('.map_'+ idx);
		// 获取发货单编号
		var sn = that.find('a').data('sn');
		// 获取当前tab中发货单的状态 如果是已发货不再显示
		var status = $obj.data('status');
		if ($obj.length == 1 && status != 1) 
		{
			// 如果地图已经被打开则不再重复打开操作
			if ($obj.is(":visible")) 
			{
				return;
			}
			var $nowContainer = $('#container_'+idx);
			// 达达物流
			if ($nowContainer.hasClass('dada'))
			{
				/**
				var delivery_lon = $nowContainer.data('lng');
				var delivery_lat = $nowContainer.data('lat');
				var position = [];
				position.push((parseFloat(delivery_lon).toFixed(6)));
				position.push((parseFloat(delivery_lat).toFixed(6)));
			  	//加载地图
				map = new AMap.Map('container_' + idx, {
					resizeEnable: true,
					zoom: 16
				});
				var img_src = "/assets/d2eace91/images/common/map-postmen-r.png";
			 	// 快递员标注marker
				marker = new AMap.Marker({
					map: map,
					position: position,
					offset: new AMap.Pixel(	-37, -83),
					icon: new AMap.Icon({	 
						size: new AMap.Size(63, 81),  //图标大小
						image: img_src,
					})	
				}) 
				map.panTo(position);
			 	// 显示地图区域
				$obj.show();
			 	**/
			}
			else
			{
				// 加载数据
				$.get('/trade/order/postmen-info.html', {
					delivery_sn: sn
				}, function(data) {
					if ( 0 == data.code)
					{
						// 快递员坐标
						var delivery_point = data.data.deliver_point;
						var delivery_arr = delivery_point.split(',');
						var delivery_lon = parseFloat(delivery_arr[0]);
						var delivery_lat = parseFloat(delivery_arr[1]);
						
						// 快递员坐标成数组参数
						var position = [];
						position.push(delivery_lon);
						position.push(delivery_lat);
						
						// 收货坐标
						var end_lon = (parseFloat(data.data.end_longitude)).toFixed(6);
						var end_lat = (parseFloat(data.data.end_latitude)).toFixed(6);
						
						// 定义一个坐标点
						var lnglatXY = new AMap.LngLat(delivery_lon, delivery_lat);
					  	var geolocation, marker;
					  	
						//加载地图
						map = new AMap.Map('container_' + idx, {
							resizeEnable: true,
							zoom: 16
						});
						
					 	// 加载缩放条
						map.plugin(["AMap.ToolBar"], function() {
							map.addControl(new AMap.ToolBar());
						});
						
						// 快递员的方位图 人朝向左/人朝向右
						var img_src = "/assets/d2eace91/images/common/map-postmen-r.png";
						if (delivery_lon > end_lon) {
							img_src = "/assets/d2eace91/images/common/map-postmen-l.png";
						}
						
						// 快递员标注marker
						marker = new AMap.Marker({
							map: map,
							position: position,
							offset: new AMap.Pixel(	-37, -83),
							icon: new AMap.Icon({	 
								size: new AMap.Size(63, 81),  //图标大小
								image: img_src,
							})	
						 }) 
						
						// 送货点
						var lnglat = new AMap.LngLat(end_lon, end_lat);
						// 地图平移到快递员的位置
						map.panTo(position);
						
						var distance;
						var unit;
						// 查看嗖嗖物流是否传递距离
						if (data.data.deliver_distance.code == 0) {
							distance = data.data.deliver_distance.distance;
							unit = 'km';
						} else {
							unit = 'm';
							distance = Math.round(lnglat.distance(position));
						}
						// 顶部tip距离提示
						openInfo(distance, unit);

						// 在指定位置打开信息窗体
						// @params distance 距离
						// @params unit 单位 m/km 
						function openInfo(distance, unit) {
							unit = unit || 'm';
							//实例化信息窗体
							content = "距离收货地址<span style='font-weight: bold; color: #d97a4a; padding-left: 3px;'>"+ distance + unit + "</span>";
							var infoWindow = new AMap.InfoWindow({
								isCustom: true,  //使用自定义窗体
								content: createInfoWindow(content),
								offset: new AMap.Pixel(0, -90)
							});
							infoWindow.open(map, marker.getPosition());
							
							 //构建自定义信息窗体
							function createInfoWindow( content) {
								var info = document.createElement("div");
								info.className = 'm-map-tip';
								info.style.backgroundColor = 'rgba(255, 255, 255, .9)';
								info.style.padding= '2px 5px';
								info.style.borderRadius= '3px';
								info.style.fontFamily = 'Microsoft Yahei';
								info.style.position = 'relative';
								info.innerHTML = content;
								return info;
							}
						}
						// 显示地图区域
						$obj.show();
					}
				}, 'JSON');
			}
			
		}
	});
	
	$("body").on("click", ".quick-delivery", function() {
		var shop_address_count = "1";
		if(shop_address_count > 0) {
			$.go("/trade/order/quick-delivery.html?order_id=5025");
		} else {
			$.msg("请先前往交易设置->发/退货地址库维护发货地址，再进行发货！");
		}
	});
	
	// 页面初始化加载一个tab下的地图
	$('#logistics .tab li:first').trigger('click');
</script>
<link rel="stylesheet" href="/static/css/highslide.css?v=20181020"/>
<script src="/static/js/pic/highslide-with-gallery.js?v=20180027"></script>

<script type="text/javascript">
	//图片弹窗
	hs.graphicsDir = '/assets/d2eace91/js/pic/graphics/';
	hs.align = 'center';
	hs.transitions = ['expand', 'crossfade'];
	hs.outlineType = 'rounded-white';
	hs.fadeInOut = true;
	hs.addSlideshow({
		interval: 5000,
		repeat: false,
		useControls: true,
		fixedControls: 'fit',
		overlayOptions: {
			opacity: .75,
			position: 'bottom center',
			hideOnMouseOut: true
		}
	});
</script>
					
				</div>
			</div>
		</div>
		<!--底部内容-->
		@include('common.footer')

</body>

<script type="text/javascript">
function toFirst(target){
	var url = $(target).parents("li").find(".sub-list").find("li:first").find("a").attr("href");
	$.go(url);
}
function to(url, target){
	
}

function clearCache(){
	// 缓载
	$.loading.start();
	$.post("/site/clear-cache", {}, function(result){
		if(result.code == 0){
			$.msg(result.message);
		}else{
			$.msg(result.message, {
				time: 5000
			});
		}
	}).always(function(){
		$.loading.stop();
	});
}
// 登录成功关闭弹出框
$.login.success = function(){
	// 关闭并销毁登录窗口
	$.login.close(true);
}
</script>

<script type="text/javascript">
	// setInterval("auto_print()",10000);
	function auto_print(order_id)
	{
		$.ajax({
			type: "GET",
			url: "/site/auto-print",
			dataType: "json",
			data: {
				order_id: order_id
			},
			success: function(result) {
				if(result.code == 0)
				{
					lodop_print_html(result.print_title, result.data,result.printer);
				}
			}
		});
	}
</script>

<!-- 加载消息监听js-->
<script src="/static/js/message/message.js?v=20180027"></script>
<script src="/static/js/message/messageWS.js?v=20180027"></script>
<script type="text/javascript">
//声音监听
WS_AddUser({
	'user_id': 'shop_1717',
	'url': "ws://push.yunmall.68mall.com:7272",
	'type': "add_user"
}); 
//右下角消息提醒弹窗js
function open_message_box(data) {
	if (!data) {    
		data = {};
    }
	
	var src = window.location.href;
	
	// 如果当前框架中的链接地址和弹框的链接地址一致则不弹框
	if(data.auto_refresh == 1 && data.link && src.indexOf(data.link) != -1){
		
		var contentWindow = window;
		
		if(contentWindow.tablelist){
			contentWindow.tablelist.load({
				page: {
					cur_page: 1
				}
			});
		}else{
			contentWindow.location.reload();
		}
		
		return;
	}
	
	$('.message-pop-box').find('#message-pop-text').html(data.content);
	
	if(data.link){
		$('.message-pop-box').find('.message-btn').attr('href', data.link).show();
	}else{
		$('.message-pop-box').find('.message-btn').hide();
	}
	
	if(data.content || data.link){
		$('.message-pop-box').removeClass('down').addClass('up');
	}
	
	try {
		if(refresh_order && typeof(refresh_order) == "function") { 
			refresh_order();
        } 
    } catch(e) {}
}
$('.message-pop-box .close').click(function() {
	$('.message-pop-box').removeClass('up').addClass('down');
});
//用户信息
$(".admin").mouseenter(function() {
	window.focus();
	$("#admin-panel").show();
}).mouseleave(function() {
	$("#admin-panel").hide();
});
</script>
<script type="text/javascript">
	var clipboard = new Clipboard('.btn-copy');
    clipboard.on('success', function(e) {
        $.msg('复制成功');
    });
    clipboard.on('error', function(e) {
    	$.msg('复制失败');
    });
 	// 更新后台主框架消息弹窗
	function update_message() {
		// 是否重新获取数据
		if ($("#message-panel").html().length > 0) {
			// if (parseInt($("#counts_all").val()) != 0) {
			var time_step = 5; // 最小刷新间隔，单位：秒
			var this_time = new Date();
			if ((parseInt($("#counts_time").val()) + parseInt(time_step)) > parseInt(this_time.getTime() / 1000)) {
				return true;
			}
			// }
		}
		$.ajax({
			type: 'GET',
			url: '/site/update-message.html',
			data: {},
			dataType: 'json',
			success: function(result) {
				if (result.code == 0) {
					$("#message-panel").html(result.data);
				} else if (result.code == 1) {
				} else {
					$.msg(result.message);
				}
			}
		});
	}
	// 消息通知
	$("#message-box").mouseenter(function() {
		update_message();
		window.focus();
		$("#message-panel").show();
	}).mouseleave(function() {
		$("#message-panel").hide();
	}).find(".close").click(function() {
		$("#message-panel").hide();
	});
</script>

</html>

