<div class="seller-left">
				<!--搜索-->
				<div class="search">
					<div class="search-bar">
						<!--这里搜索-->
						<form action="/goods/list/index.html" method="GET" target="_blank">
							<input class="search-input-text" placeholder="商城商品搜索" type="text" name="keyword" />
							<a class="search-input-btn" href="javascript:void(0);" title="点击进行搜索" onClick="$(this).parents('form').submit();")">
								<i class="fa fa-search"></i>
							</a>
						</form>
					</div>
				</div>

				<!--左侧导航-->
				<ul class="left-menu">
					<!--当首页选中的时候，这块显示添加常用功能菜单按钮，点击弹出选择常用功能菜单,最多可选择10个；选择完毕后，以下面的li标签内容显示，添加按钮则隐藏-->
					<div class="add-quickmenu" style="display: none">
						<a href="javascript:;" title="添加常用功能菜单" data-toggle="modal" data-target="#allModal">
							<i class="fa fa-plus"></i>
							添加常用功能菜单
						</a>
					</div>
										
					
					
					
										
					<!-- <li class="">
						
						<a href="/shop/config/index.html?group=trade" data-menus="trade|trade-set" onClick="to('/shop/config/index.html?group=trade', this)">交易设置</a>
						
					</li> -->
					
					
					
					
					
					
										
					<li class="selected">
						
						<a href="/store/order/list" data-menus="trade|trade-order-list" onClick="to('/store/order/list', this)">订单管理</a>
						
					</li>
					
					
					
					
										
					<!-- <li class="">
						
						<a href="/store/delivery/list" data-menus="trade|trade-delivery-list" onClick="to('/store/delivery/list', this)">发货单管理</a>
						
					</li> -->
					
					
					
					
										
					<!-- <li class="">
						
						<a href="/trade/back/list" data-menus="trade|trade-back-list" onClick="to('/trade/back/list', this)">退款/退货管理</a>
						
					</li>
					
					
					
					
										
					<li class="">
						
						<a href="/trade/back/list?is_after_sale=1" data-menus="trade|trade-after-sale-list" onClick="to('/trade/back/list?is_after_sale=1', this)">售后管理</a>
						
					</li>
					
					
					
					
										
					<li class="">
						
						<a href="/trade/complaint/list" data-menus="trade|trade-complaint-manage" onClick="to('/trade/complaint/list', this)">投诉管理</a>
						
					</li>
					
					
					
					
										
					<li class="">
						
						<a href="/trade/service/evaluate-buyer-list" data-menus="trade|trade-evaluate-buyer-list" onClick="to('/trade/service/evaluate-buyer-list', this)">评价管理</a>
						
					</li> -->
					
					
					<!--分割线-->
					<!--      <li class="line"></li> -->
				</ul>
			</div>