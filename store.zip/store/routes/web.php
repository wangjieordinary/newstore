<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/user', function () {
	//return redirect("store");
    //return view('welcome');
    for($i=0;$i<=17;$i++){
        $requestData = DB::select("select top 10 * from member where cj in(0,1,2,3,4) and id not in(select top ".(10*$i)." id from member where cj in(0,1,2,3,4))");

        // and id not in(select top 240 id from product)
        foreach($requestData as $key => $vall){
            $requestData[$key]->firstname = iconv('GBK', 'UTF-8', $vall->firstname);
            $requestData[$key]->country = iconv('GBK', 'UTF-8', $vall->country);
            $requestData[$key]->address = iconv('GBK', 'UTF-8', $vall->address);
            $requestData[$key]->company = iconv('GBK', 'UTF-8', $vall->company);
            $requestData[$key]->linkman = iconv('GBK', 'UTF-8', $vall->linkman);
            $requestData[$key]->con = iconv('GBK', 'UTF-8', $vall->con);
            if($vall->uid0 !== '0'){
                $uid0 = DB::table('member')->where('id', '=', $vall->uid0)->pluck('telephone');
                $requestData[$key]->uid0 = $uid0[0];
            }
            if($vall->uid1 !== '0'){
                $uid1 = DB::table('member')->where('id', '=', $vall->uid1)->pluck('telephone');
                $requestData[$key]->uid1 = $uid1[0];  
            }
            if($vall->uid2 !== '0'){
                $uid2 = DB::table('member')->where('id', '=', $vall->uid2)->pluck('telephone');
                $requestData[$key]->uid2 = $uid2[0]; 
            }
            if($vall->uid3 !== '0'){
                $uid3 = DB::table('member')->where('id', '=', $vall->uid3)->pluck('telephone');
                $requestData[$key]->uid3 = $uid3[0];
            }
            if($vall->uid4 !== '0'){
                $uid4 = DB::table('member')->where('id', '=', $vall->uid4)->pluck('telephone');
                $requestData[$key]->uid4 = $uid4[0];
            }
            if($vall->uid5 !== '0'){
                $uid5 = DB::table('member')->where('id', '=', $vall->uid5)->pluck('telephone');
                $requestData[$key]->uid5 = $uid5[0];
            }
            if($vall->uid6 !== '0'){
                $uid6 = DB::table('member')->where('id', '=', $vall->uid6)->pluck('telephone');
                $requestData[$key]->uid6 = $uid6[0];
            }
        }
        $url = "http://119.29.213.250/user";
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        //普通数据
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($requestData));
        $res = curl_exec($curl);
        //$info = curl_getinfo($ch);
        curl_close($curl);
        print_r($res)."\r\n";
    }
    
});
Route::get('/', function(){
    $catidstr = "893,894,897,898,899,900,901,902,903,904,906,907,915,920,924";
    /*print_r(count(DB::select("select * from product where catid in(".$catidstr.") and onsale=0")));
    exit;*/
    for($i=0;$i<=5;$i++){
        //$catidstr = "164,168,169,163,167,199,191,197,170,181,712,714,711,770,771,765,262,501,408,548,551,602,608,612,606,610,605,611,609,607,556,557,600,555,878,876,877";        
        $requestData = DB::select("select top 10 * from product where catid in(".$catidstr.") and onsale=0 and id not in(select top ".(10*$i)." id from product where catid in(".$catidstr.") and onsale=0)");
        // and id not in(select top 240 id from product)
        foreach($requestData as $key => $vall){
            $requestData[$key]->huohao = iconv('GBK', 'UTF-8', $vall->huohao);
            $requestData[$key]->name = iconv('GBK', 'UTF-8', $vall->name);
            $requestData[$key]->content = iconv('GBK', 'UTF-8', $vall->content);
            $requestData[$key]->Descriptions = iconv('GBK', 'UTF-8', $vall->Descriptions);
            $requestData[$key]->Keywords = iconv('GBK', 'UTF-8', $vall->Keywords);
            $requestData[$key]->sizes = iconv('GBK', 'UTF-8', $vall->sizes);
            switch ($vall->catid) {
                case '893':
                    $requestData[$key]->catid = '1548';
                    break;
                case '894':
                    $requestData[$key]->catid = '1549';
                    break;
                case '897':
                    $requestData[$key]->catid = '1552';
                    break;
                case '898':
                    $requestData[$key]->catid = '1553';
                    break;
                case '899':
                    $requestData[$key]->catid = '1548';
                    break;
                case '900':
                    $requestData[$key]->catid = '1557';
                    break;
                case '901':
                    $requestData[$key]->catid = '1558';
                    break;
                case '902':
                    $requestData[$key]->catid = '1560';
                    break;
                case '903':
                    $requestData[$key]->catid = '1561';
                    break;
                case '904':
                    $requestData[$key]->catid = '1562';
                    break;
                case '906':
                    $requestData[$key]->catid = '1564';
                    break;
                case '907':
                    $requestData[$key]->catid = '1565';
                    break;
                case '915':
                    $requestData[$key]->catid = '1574';
                    break;
                case '920':
                    $requestData[$key]->catid = '1580';
                    break;
                case '924':
                    $requestData[$key]->catid = '1584';
                    break;
            }
            /*switch ($vall->catid) {
                case '163':
                    $requestData[$key]->catid = '1881';
                    break;
                case '164':
                    $requestData[$key]->catid = '1882';
                    break;
                case '167':
                    $requestData[$key]->catid = '1885';
                    break;
                case '168':
                    $requestData[$key]->catid = '1887';
                    break;
                case '169':
                    $requestData[$key]->catid = '1888';
                    break;
                case '170':
                    $requestData[$key]->catid = '1890';
                    break;
                case '181':
                    $requestData[$key]->catid = '1902';
                    break;
                case '191':
                    $requestData[$key]->catid = '1913';
                    break;
                case '197':
                    $requestData[$key]->catid = '1920';
                    break;
                case '199':
                   $requestData[$key]->catid = '1922';
                    break;
                case '262':
                    $requestData[$key]->catid = '2087';
                    break;
                case '408':
                    $requestData[$key]->catid = '2177';
                    break;
                case '501':
                    $requestData[$key]->catid = '2291';
                    break;
                case '548':
                    $requestData[$key]->catid = '2338';
                    break;
                case '551':
                    $requestData[$key]->catid = '2341';
                    break;
                case '555':
                    $requestData[$key]->catid = '2419';
                    break;
                case '556':
                    $requestData[$key]->catid = '2420';
                    break;
                case '557':
                    $requestData[$key]->catid = '2421';
                    break;
                case '600':
                    $requestData[$key]->catid = '2437';
                    break;
                case '602':
                    $requestData[$key]->catid = '2447';
                    break;
                case '605':
                    $requestData[$key]->catid = '2450';
                    break;
                case '606':
                    $requestData[$key]->catid = '2449';
                    break;
                case '607':
                    $requestData[$key]->catid = '2446';
                    break;
                case '608':
                    $requestData[$key]->catid = '2447';
                    break;
                case '609':
                    $requestData[$key]->catid = '2448';
                    break;
                case '610':
                    $requestData[$key]->catid = '2449';
                    break;
                case '611':
                    $requestData[$key]->catid = '2450';
                    break;
                case '612':
                    $requestData[$key]->catid = '2451';
                    break;
                case '711':
                    $requestData[$key]->catid = '1815';
                    break;
                case '712':
                    $requestData[$key]->catid = '1816';
                    break;
                case '714':
                    $requestData[$key]->catid = '1818';
                    break;
                case '765':
                    $requestData[$key]->catid = '1961';
                    break;
                case '770':
                    $requestData[$key]->catid = '1966';
                    break;
                case '771':
                    $requestData[$key]->catid = '1967';
                    break;
                case '876':
                    $requestData[$key]->catid = '1719';
                    break;
                case '877':
                    $requestData[$key]->catid = '1720';
                    break;
                case '878':
                    $requestData[$key]->catid = '1721';
                    break;
            }*/
        }
        $url = "http://119.29.213.250/";
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        //普通数据
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($requestData));
        $res = curl_exec($curl);
        //$info = curl_getinfo($ch);
        curl_close($curl);
        print_r($res)."\r\n";
    }
});
//检测登录情况
Route::group([
    'prefix' => 'user' , 
    'namespace' => 'User',
], function () {
    Route::get('login', 'StoreController@index');
    Route::post('checklogin', 'StoreController@checklogin');
    Route::get('logout', 'StoreController@logout');
});


Route::group([
    'prefix' => 'store' , 
    'namespace' => 'Store',
    'middleware'=> 'store',
], function () {
    Route::get('/', 'IndexController@index');
    //商品
    Route::get('goods/list', 'GoodsController@index');
    Route::get('goods/add', 'GoodsController@publish');
    Route::get('goods/nextpublish', 'GoodsController@nextpublish');

    Route::get('goods/newnextpublish', 'GoodsController@newnextpublish');

    Route::post('goods/dopublish', 'GoodsController@dopublish');
    Route::get('goods/edit/{id}', 'GoodsController@edit');
    Route::post('goods/doedit', 'GoodsController@doedit');
    Route::post('goods/delete', 'GoodsController@delete');

    //商品分类
    Route::get('category/list', 'CategoryController@index');
    Route::get('category/add', 'CategoryController@publish');
    Route::post('category/doadd', 'CategoryController@dopublish');
    Route::get('category/edit/{id}', 'CategoryController@edit');
    Route::post('category/doedit', 'CategoryController@doedit');
    Route::post('category/del', 'CategoryController@del');
    Route::get('category/set-is-show', 'CategoryController@setisshow');
    //ajax路由
    Route::get('get-data', 'IndexController@ajaxcount');
    Route::get('show-message', 'IndexController@showmessage');
    Route::get('expiration-reminding', 'IndexController@expirationreminding');
    Route::get('goods/cat-list', 'GoodsController@catelist');
    //添加商品图片
    Route::get('goods/add-images', 'GoodsController@addimages');
    Route::post('goods/edit-images', 'GoodsController@editimages');
    //上传图片按钮
    Route::post('goods/image-gallery', 'GoodsController@imagegallery');
    //图片上传
    //Route::get('goods/image-selector', 'GoodsController@imageselector');
    Route::get('goods/image-selector', 'GoodsController@newimageselector');
    //添加规格
    Route::get('goods/add-spec', 'GoodsController@addspec');
    Route::post('goods/doadd-spec', 'GoodsController@doaddspec');
    Route::get('goods/success', 'GoodsController@success');
    //添加规格
    Route::get('spec/list', 'SpecController@index');
    Route::get('spec/add', 'SpecController@add');
    Route::post('spec/doadd', 'SpecController@doadd');
    Route::get('spec/edit', 'SpecController@edit');
    Route::post('spec/doedit', 'SpecController@doedit');
    Route::post('spec/delete', 'SpecController@del');

    //快递
    Route::get('freight/list', 'FreightController@index');
    Route::get('freight/add', 'FreightController@add');
    Route::post('freight/doadd', 'FreightController@doadd');
    Route::get('freight/edit', 'FreightController@edit');
    Route::post('freight/doedit', 'FreightController@doedit');
    Route::get('freight/default',  'FreightController@default');
    Route::get('freight/delete', 'FreightController@delete');
    
});

Route::group([
    'prefix' => 'store' , 
    'namespace' => 'Order',
    'middleware'=> 'store',
], function () {
    //订单部分
    Route::get('order/list','OrderController@index');
    Route::get('order/info','OrderController@info');
    //发货
    Route::get('delivery/list','DeliveryController@index');
    Route::get('order/batch-delivery','DeliveryController@batchdelivery');
    Route::get('order/toshipping','DeliveryController@toshipping');
    Route::post('order/get-order-counts','DeliveryController@getordercounts');
    Route::get('delivery/to-shipping','DeliveryController@dotoshipping');
});



//前台部分
Route::group([
    'prefix' => 'storeindex' , 
    'namespace' => 'Storeindex',    
], function () {
    Route::get('/{id}', 'IndexController@index');
});

//ajax请求
Route::group([
    'prefix' => 'site' , 
    'namespace' => 'Storeindex',    
], function () {
    Route::get('user', 'IndexController@user');
});
Route::get('cart/box-goods-list', 'Storeindex\IndexController@boxgoodslist');
Route::get('shop/index/info', 'Storeindex\IndexController@info');
Route::get('goods/list', 'Storeindex\IndexController@list');

Route::get('/shop/freight/region-picker', 'Store\FreightController@regionpicker');

Route::get('site/region-list', 'Store\FreightController@regionlist');
Route::get('site/sale-region-list', 'Store\FreightController@saleregionlist');

//新修改发布商品页面及相关路由
Route::get('shop/freight/desc', 'Newstore\FreightController@index');
Route::get('site/cat-list', 'Newstore\FreightController@catlist');
Route::get('aaa', 'Newstore\FreightController@aaa');
Route::get('site/shop-cat-list', 'Newstore\FreightController@storecate');
Route::get('goods/publish/reload-goods-unit', 'Newstore\FreightController@reloadgoodsunit');
Route::get('goods/publish/add', 'Newstore\FreightController@doadd');