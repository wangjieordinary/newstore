//demo code for radial progress
$(function () {
    //radial progress 1
    $('#indicatorContainer1').radialIndicator({
		barColor: '#5DB2FF',
		initValue: 40
	})
	//radial progress 2
    $('#indicatorContainer2').radialIndicator({
		barColor: '#FFCE55',
		initValue: 96
	})
	//radial progress 3
    $('#indicatorContainer3').radialIndicator({
		barColor: '#A0D468',
		initValue: 85
	})
	//radial progress 4
    $('#indicatorContainer4').radialIndicator({
		barColor: '#FB6E52',
		initValue: 57
	})
		//radial progress 5
    $('#indicatorContainer5').radialIndicator({
		barColor: '#5DB2FF',
		initValue: 40
	})
	//radial progress 6
    $('#indicatorContainer6').radialIndicator({
		barColor: '#FFCE55',
		initValue: 96
	})
	//radial progress 7
    $('#indicatorContainer7').radialIndicator({
		barColor: '#A0D468',
		initValue: 85
	})
	//radial progress 8
    $('#indicatorContainer8').radialIndicator({
		barColor: '#FB6E52',
		initValue: 58
	})
});